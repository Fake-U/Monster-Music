# MonsterMusic — GitHub 编译说明

## 上传到 GitHub

1. 解压本 ZIP。
2. 在 GitHub 创建一个空仓库。
3. 将**解压后的文件和文件夹内容**上传到仓库根目录（不要把 ZIP 文件本身当作源码上传）。
4. 确认仓库根目录能直接看到 `settings.gradle.kts`、`build.gradle.kts`、`gradlew`、`app/` 和 `.github/`。
5. 推送到 `main` 或 `master` 分支，或在仓库的 **Actions → Android Build → Run workflow** 手动启动编译。

## 获取 APK

编译成功后，打开 GitHub 仓库的 **Actions**，进入最新的 **Android Build** 运行记录，在 Artifacts 区域下载 `MonsterMusic-APKs`。

工作流会生成：
- Debug APK：由项目的 debug 签名配置签名，适合测试安装。
- Release APK：默认不使用个人发布密钥，适合测试；若要正式发布，需要自行配置签名密钥。

## 环境

工作流使用 JDK 21、项目自带 Gradle Wrapper（Gradle 9.5.0），并安装 Android API 37、Build Tools 37.0.0、NDK 30.0.16248370 和 CMake 3.22.1。

## 正式发布签名

不要把个人正式签名密钥提交到 GitHub 仓库。正式发布时，应在 GitHub 仓库 Settings → Secrets and variables → Actions 中配置密钥，并单独调整发布工作流。
