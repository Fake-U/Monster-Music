plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("kotlin-parcelize")
    id("com.google.devtools.ksp")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}
val isBundleTask = project.hasProperty("bundle") || gradle.startParameter.taskNames.any {
    it.contains("bundle", ignoreCase = true)
}
val supportVideo = if (project.hasProperty("supportVideo")) {
    project.property("supportVideo").toString().toBoolean()
} else {
    !isBundleTask
}
android {

    defaultConfig {
        applicationId = "com.ztftrue.music"
        minSdk = 30
        targetSdk = 37
        versionCode = 86
        versionName = "0.1.86"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
        buildConfigField("Boolean", "SUPPORT_VIDEO", "$supportVideo")
    }

    sourceSets {
        if (supportVideo) {
            getByName("debug") {
                manifest.srcFile("src/apk/AndroidManifest.xml")
            }
            getByName("release") {
                manifest.srcFile("src/apk/AndroidManifest.xml")
            }
        }
    }

    signingConfigs {
        create("release") {
            val keystorePath = System.getenv("KEYSTORE_PATH")
            if (!keystorePath.isNullOrBlank()) {
                val keystoreFile = file(keystorePath)
                if (keystoreFile.exists()) {
                    storeFile = keystoreFile
                    storePassword = System.getenv("KEY_STORE_PASSWORD")
                    keyPassword = System.getenv("KEY_PASSWORD")
                    keyAlias = System.getenv("KEY_ALIAS")
                }
            }
        }

        getByName("debug") {
            storeFile = file("../debug_keystore.jks")
            storePassword = "qazwsx"
            keyPassword = "111111"
            keyAlias = "music"
        }
    }

    namespace = "com.ztftrue.music"
    compileSdk = 37
    ndkVersion = "30.0.16248370"

    splits {
        abi {
            isEnable = !isBundleTask
            if (!isBundleTask) {
                reset()
                include(
                    "armeabi-v7a",
                    "arm64-v8a",
                    "x86",
                    "x86_64"
                )
                isUniversalApk = true
            }
        }
    }

    bundle {
        language {
            enableSplit = false // don't split language, for Google Play app bundle
        }
    }


    dependenciesInfo {
        // Disables dependency metadata when building APKs.
        includeInApk = false
        // Disables dependency metadata when building Android App Bundles.
        includeInBundle = true
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            applicationVariants.all {
                outputs.all {
                    val variantOutput = this
                    if (variantOutput is com.android.build.gradle.internal.api.ApkVariantOutputImpl) {
                        tasks.named("mergeReleaseArtProfile").configure {
                            doLast {
                                copy {
                                    from("${layout.buildDirectory}/outputs/mapping/release/mapping.txt")
                                    into(variantOutput.outputFile.parent)
                                    rename { "mapping.txt" }
                                }
                            }
                        }
                    }
                }
            }
            val releaseSigning = signingConfigs.getByName("release")
            signingConfig = if (releaseSigning.storeFile?.exists() == true) {
                releaseSigning
            } else {
                null
            }
        }
        getByName("debug") {
            applicationIdSuffix = ".debug" // Appends ".debug" to the
            isMinifyEnabled = false
            isShrinkResources = false
            isDebuggable = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        jvmToolchain(17) // Automatically sets jvmTarget to 17
    }

    buildFeatures {
        compose = true
        viewBinding = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    lint {
        abortOnError = false
        disable += setOf("MissingTranslation", "PluralsCandidate", "UseKtx", "DefaultLocale", "WrongCommentType")
    }
}
composeCompiler {
    reportsDestination = layout.buildDirectory.dir("compose_compiler")
    stabilityConfigurationFiles.add(rootProject.layout.projectDirectory.file("stability_config.conf"))
    // Set these to false or remove them entirely
}
ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}
dependencies {

    implementation("androidx.core:core-ktx:1.19.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.11.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.11.0")
    implementation("androidx.activity:activity-compose:1.13.0")

    implementation("androidx.activity:activity-ktx:1.13.0")


    implementation("androidx.appcompat:appcompat:1.8.0")

//    implementation("androidx.media:media:1.7.0")
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    implementation("androidx.media3:media3-session:1.11.1")
    implementation("androidx.media3:media3-ui:1.11.1")
    implementation("org.jellyfin.media3:media3-ffmpeg-decoder:1.9.0+1")

    val composeBom = platform("androidx.compose:compose-bom:2026.09.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.runtime:runtime")
    implementation("androidx.compose.runtime:runtime-livedata")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material3:material3-window-size-class")

    // splash
    implementation("androidx.core:core-splashscreen:1.2.0")
    implementation("androidx.constraintlayout:constraintlayout-compose:1.1.2")

    // load image
    implementation("io.coil-kt.coil3:coil-compose:3.6.3")
    implementation("io.coil-kt.coil3:coil:3.6.3")
    implementation("io.coil-kt.coil3:coil-gif:3.6.3")
    implementation("io.coil-kt.coil3:coil-svg:3.6.3")

    implementation("androidx.browser:browser:1.10.0")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.3.0")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.7.0")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")


    implementation("androidx.collection:collection-ktx:1.7.0")
    implementation("androidx.fragment:fragment-ktx:1.9.1")
    implementation("androidx.palette:palette-ktx:1.0.0")

    // https://mvnrepository.com/artifact/org.apache.commons/commons-math3
    implementation("org.apache.commons:commons-math3:3.6.1")
    implementation("com.google.code.gson:gson:2.14.0")

    val roomVersion = "2.8.5"
    implementation("androidx.room:room-runtime:$roomVersion")
    // To use Kotlin Symbol Processing (KSP)
    ksp("androidx.room:room-compiler:$roomVersion")
    // Kotlin Extensions and Coroutines support for Room
    implementation("androidx.room:room-ktx:$roomVersion")
    // Test helpers
    androidTestImplementation("androidx.room:room-testing:$roomVersion")

    implementation("com.github.skydoves:colorpicker-compose:1.3.0")


    // Core Navigation 3 libraries
    implementation("androidx.navigation3:navigation3-runtime:1.2.0")
    implementation("androidx.navigation3:navigation3-ui:1.2.0")
    // Optional add-on libraries,Navigation 3
    implementation("androidx.lifecycle:lifecycle-viewmodel-navigation3:2.11.0")
    implementation("androidx.compose.material3.adaptive:adaptive:1.3.0")
    implementation("androidx.compose.material3.adaptive:adaptive-layout:1.3.0")
    implementation("androidx.compose.material3.adaptive:adaptive-navigation:1.3.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-core:1.11.0")

//    debugImplementation ("com.squareup.leakcanary:leakcanary-android:2.14")
}

tasks.register("copyReleaseApks") {
    doLast {
        val outputDir = file("release")
        val buildApkDir = layout.buildDirectory.dir("outputs/apk/release").get().asFile
        if (buildApkDir.exists()) {
            outputDir.mkdirs()
            buildApkDir.listFiles()?.forEach { apkFile ->
                if (apkFile.extension == "apk" || apkFile.name == "output-metadata.json") {
                    apkFile.copyTo(File(outputDir, apkFile.name), overwrite = true)
                }
            }
        }
    }
}

tasks.matching { it.name == "assembleRelease" }.configureEach {
    finalizedBy("copyReleaseApks")
}
