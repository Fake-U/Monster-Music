package com.ztftrue.music.ui.other

import android.os.Bundle
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerState
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.media3.common.util.UnstableApi
import com.ztftrue.music.MainActivity
import com.ztftrue.music.MusicViewModel
import com.ztftrue.music.R
import com.ztftrue.music.Router
import com.ztftrue.music.play.manager.MediaCommands
import kotlinx.coroutines.launch

@UnstableApi
@Composable
@Suppress("UNUSED_PARAMETER")
fun DrawMenu(
    pagerState: androidx.compose.foundation.pager.PagerState,
    drawerState: DrawerState,
    navController: SnapshotStateList<Any>,
    musicViewModel: MusicViewModel,
    activity: MainActivity
) {
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    val background = MaterialTheme.colorScheme.background

    ModalDrawerSheet(
        drawerContainerColor = background,
        modifier = Modifier.width(312.dp),
        drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxHeight().background(background).padding(16.dp),
            verticalArrangement = Arrangement.Top
        ) {
            Box(
                modifier = Modifier.fillMaxWidth().height(188.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF35236F), Color(0xFF142C45), Color(0xFF101018))))
                    .padding(18.dp),
                contentAlignment = Alignment.BottomStart
            ) {
                Image(
                    painter = painterResource(R.mipmap.ic_launcher),
                    contentDescription = stringResource(R.string.app_name),
                    modifier = Modifier.align(Alignment.TopStart).size(68.dp).clip(RoundedCornerShape(20.dp)),
                    contentScale = ContentScale.Crop
                )
                Column {
                    Text(stringResource(R.string.app_name), color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("YOUR MUSIC. YOUR SPACE.", color = Color.White.copy(alpha = 0.68f), fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
            }

            Spacer(Modifier.height(24.dp))
            Text("LIBRARY", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 10.dp, bottom = 8.dp))
            DrawerAction(
                icon = Icons.Filled.Settings,
                title = stringResource(R.string.settings),
                subtitle = "Appearance and playback preferences",
                onClick = {
                    scope.launch { drawerState.close() }
                    navController.add(Router.SettingsPage)
                }
            )
            DrawerAction(
                icon = Icons.Filled.Refresh,
                loading = musicViewModel.isRefreshing.value,
                title = if (musicViewModel.isRefreshing.value) stringResource(R.string.refreshing_tracks) else stringResource(R.string.refresh_tracks),
                subtitle = "Rescan your local music library",
                enabled = !musicViewModel.isRefreshing.value,
                onClick = {
                    musicViewModel.refreshAllTracks(context)
                    scope.launch { drawerState.close() }
                }
            )
            Spacer(Modifier.weight(1f))
            Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)))
            Spacer(Modifier.height(12.dp))
            DrawerAction(
                icon = Icons.Filled.ExitToApp,
                title = stringResource(R.string.exit_app),
                subtitle = "Close Monster Music",
                destructive = true,
                onClick = {
                    musicViewModel.browser?.sendCustomCommand(MediaCommands.COMMAND_APP_EXIT, Bundle.EMPTY)
                    activity.finishAndRemoveTask()
                }
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun DrawerAction(
    icon: ImageVector,
    title: String,
    subtitle: String,
    loading: Boolean = false,
    enabled: Boolean = true,
    destructive: Boolean = false,
    onClick: () -> Unit
) {
    val tint = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                .background(if (destructive) MaterialTheme.colorScheme.error.copy(alpha = 0.10f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            if (loading) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = tint)
            } else {
                Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
            }
        }
        Column(Modifier.weight(1f).padding(start = 13.dp)) {
            Text(title, color = tint, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
    }
}
