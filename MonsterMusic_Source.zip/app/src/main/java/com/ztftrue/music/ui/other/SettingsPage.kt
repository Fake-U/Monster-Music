package com.ztftrue.music.ui.other

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.platform.SoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.ztftrue.music.BuildConfig
import com.ztftrue.music.MainActivity
import com.ztftrue.music.MusicViewModel
import com.ztftrue.music.PlayMusicWidget
import com.ztftrue.music.R
import com.ztftrue.music.sqlData.model.ARTIST_TYPE
import com.ztftrue.music.sqlData.model.FilterFolder
import com.ztftrue.music.sqlData.model.LYRICS_TYPE
import com.ztftrue.music.sqlData.model.MainTab
import com.ztftrue.music.sqlData.model.StorageFolder
import com.ztftrue.music.sqlData.model.TRACKS_TYPE
import com.ztftrue.music.ui.public.BackTopBar
import com.ztftrue.music.ui.widget.WidgetConfigContent
import com.ztftrue.music.utils.LyricsSettings.FIRST_EMBEDDED_LYRICS
import com.ztftrue.music.utils.SharedPreferencesName.LYRICS_SETTINGS
import com.ztftrue.music.utils.SharedPreferencesUtils
import com.ztftrue.music.utils.Utils
import com.ztftrue.music.utils.Utils.openBrowser
import com.ztftrue.music.utils.model.FolderList
import com.ztftrue.music.utils.model.LanguageModel
import com.ztftrue.music.utils.trackManager.FolderManger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale


/**
 * show all music of playlist
 */
@UnstableApi
@Composable
fun SettingsPage(
    musicViewModel: MusicViewModel,
    navController: SnapshotStateList<Any>,
) {
    val context = LocalContext.current
    var autoHandleAudioFocus by remember {
        mutableStateOf(SharedPreferencesUtils.getAutoHandleAudioFocus(context))
    }
    val videoPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            musicViewModel.setVideoSupportEnable(context, true)
        } else {
            Toast.makeText(context, R.string.video_support_enable, Toast.LENGTH_SHORT).show()
        }
    }
    val coverImagePickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            musicViewModel.setCustomCover(context, uri)
        }
    }
    var durationValue by remember { mutableStateOf("0") }
    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current
    var expanded by remember { mutableStateOf(false) }
    var showClearAlbumCache by remember { mutableStateOf(false) }
    var preferEmbedded by remember {
        mutableStateOf(
            context.getSharedPreferences(
                LYRICS_SETTINGS, Context.MODE_PRIVATE
            )
                .getBoolean(FIRST_EMBEDDED_LYRICS, false)
        )
    }
    var autoToTopRandom by remember {
        mutableStateOf(
            SharedPreferencesUtils.getAutoToTopRandom(context)
        )
    }
    var mergeAlbum by remember {
        mutableStateOf(
            SharedPreferencesUtils.getMergeAlbum(context)
        )
    }

    var showDialog by remember { mutableStateOf(false) }
    var showScanModeDialog by remember { mutableStateOf(false) }
    var showManageFilterFoldersDialog by remember { mutableStateOf(false) }
    var showLyricsFolderDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showSetListIndicatorDialog by remember { mutableStateOf(false) }
    var showReplaceCoverDialog by remember { mutableStateOf(false) }
    var showSetLanguageDialog by remember { mutableStateOf(false) }
    var showSetWidgetDialog by remember { mutableStateOf(false) }
    var showAutoPlaySetDialog by remember { mutableStateOf(false) }
    val openDecoderDialog = remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        durationValue = SharedPreferencesUtils.getIgnoreDuration(context).toString()
    }

    if (showDialog) {
        ManageTabDialog(musicViewModel, onDismiss = { showDialog = false })
    }
    if (showScanModeDialog) {
        ScanModeDialog(musicViewModel = musicViewModel, onDismiss = { showScanModeDialog = false })
    }
    if (showManageFilterFoldersDialog) {
        val isWhitelist =
            musicViewModel.scanMode.intValue == SharedPreferencesUtils.SCAN_MODE_WHITELIST
        ManageFilterFoldersDialog(
            musicViewModel = musicViewModel,
            isWhitelist = isWhitelist,
            onDismiss = { showManageFilterFoldersDialog = false })
    }
    if (showLyricsFolderDialog) {
        ManageLyricsFolderDialog(musicViewModel, onDismiss = { showLyricsFolderDialog = false })
    }
    if (showAboutDialog) {
        AboutDialog(onDismiss = { showAboutDialog = false })
    }
    if (showSetListIndicatorDialog) {
        SetListIndicatorDialog(onDismiss = { showSetListIndicatorDialog = false })
    }
    if (showReplaceCoverDialog) {
        ReplaceCoverDialog(
            musicViewModel = musicViewModel,
            onPickImage = {
                if (context is MainActivity) {
                    context.roseImagPicker()
                } else {
                    coverImagePickerLauncher.launch("image/*")
                }
            },
            onDismiss = { showReplaceCoverDialog = false }
        )
    }
    if (showSetLanguageDialog) {
        SwitchLanguageDialog(onDismiss = { showSetLanguageDialog = false })
    }
    if (showClearAlbumCache) {
        ClearAlbumCoverDialog(onDismiss = { showClearAlbumCache = false })
    }
    if (showSetWidgetDialog) {
        SetWidgetDialog(musicViewModel, onDismiss = { showSetWidgetDialog = false })
    }
    if (showAutoPlaySetDialog) {
        ManageAutoPlayDialog(onDismiss = { showAutoPlaySetDialog = false })
    }
    if (openDecoderDialog.value) {
        AudioDecoderModeDialog(
            musicViewModel = musicViewModel,
            onDismiss = { openDecoderDialog.value = false })
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(start = 0.dp, top = 0.dp, end = 0.dp, bottom = 10.dp),
        topBar = {
            Column {
                BackTopBar(navController, stringResource(id = R.string.settings))
                HorizontalDivider(
                    modifier = Modifier.fillMaxWidth(),
                    thickness = 0.5.dp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.2f)
                )
            }
        },
        bottomBar = { },
        floatingActionButton = {},
        content = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(it)
            ) {
                // Section 1: Appearance & Interface
                item {
                    SettingsCategoryHeader(stringResource(R.string.settings_category_appearance))
                }
                item {
                    var selectedIndex by remember { musicViewModel.themeSelected }
                    val offset = remember { mutableIntStateOf(0) }
                    val selectedText = if (selectedIndex >= 0) {
                        Utils.items[selectedIndex]
                    } else {
                        R.string.app_name
                    }
                    SettingsItem(
                        title = stringResource(R.string.select_theme),
                        subtitle = stringResource(id = selectedText),
                        onClick = { expanded = !expanded },
                        trailingContent = {
                            Box {
                                DropdownMenu(
                                    expanded = expanded,
                                    onDismissRequest = { expanded = false },
                                    modifier = Modifier
                                        .background(MaterialTheme.colorScheme.tertiaryContainer),
                                    offset = DpOffset(
                                        x = 0.dp,
                                        y = with(LocalDensity.current) { offset.intValue.toDp() }
                                    )
                                ) {
                                    Utils.items.forEachIndexed { index, item ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    stringResource(id = item),
                                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                                )
                                            },
                                            onClick = {
                                                selectedIndex = index
                                                expanded = false
                                                context.getSharedPreferences(
                                                    "SelectedTheme",
                                                    Context.MODE_PRIVATE
                                                ).edit { putInt("SelectedTheme", index) }
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    )
                }
                item {
                    SettingsItem(
                        title = stringResource(R.string.set_language),
                        onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                try {
                                    val intent = Intent(Settings.ACTION_APP_LOCALE_SETTINGS)
                                    intent.data =
                                        Uri.fromParts("package", context.packageName, null)
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Log.e("SettingsPage", "Failed to open language settings", e)
                                    Toast.makeText(
                                        context,
                                        R.string.failed_to_open_language_settings,
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } else {
                                showSetLanguageDialog = true
                            }
                        }
                    )
                }
                item {
                    SettingsItem(
                        title = stringResource(R.string.manage_tab_items),
                        onClick = { showDialog = true }
                    )
                }
                item {
                    SettingsItem(
                        title = stringResource(R.string.set_list_indicator),
                        onClick = { showSetListIndicatorDialog = true }
                    )
                }
                item {
                    SettingsItem(
                        title = stringResource(R.string.settings_set_widget_background),
                        onClick = { showSetWidgetDialog = true }
                    )
                }
                item {
                    val isCustom = musicViewModel.customMusicCover.value !is Int
                    SettingsItem(
                        title = stringResource(R.string.replace_cover_the_rose),
                        subtitle = stringResource(if (isCustom) R.string.custom_cover else R.string.default_cover),
                        onClick = { showReplaceCoverDialog = true },
                        trailingContent = {
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(musicViewModel.getCustomCoverModel())
                                    .crossfade(true)
                                    .size(100, 100)
                                    .build(),
                                contentDescription = stringResource(R.string.cover),
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .border(
                                        width = 0.5.dp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(6.dp)
                                    )
                            )
                        }
                    )
                }

                // Section 2: Library & Scanning
                item {
                    SettingsCategoryHeader(stringResource(R.string.settings_category_library))
                }
                item {
                    val isWhitelist =
                        musicViewModel.scanMode.intValue == SharedPreferencesUtils.SCAN_MODE_WHITELIST
                    SettingsItem(
                        title = stringResource(R.string.folder_scan_mode),
                        subtitle = if (isWhitelist) stringResource(R.string.scan_mode_whitelist) else stringResource(
                            R.string.scan_mode_blacklist
                        ),
                        onClick = { showScanModeDialog = true }
                    )
                }
                item {
                    val isWhitelist =
                        musicViewModel.scanMode.intValue == SharedPreferencesUtils.SCAN_MODE_WHITELIST
                    val folderSubtitle = if (isWhitelist) {
                        if (musicViewModel.whitelistFolders.isEmpty()) stringResource(R.string.no_folders_added)
                        else stringResource(
                            R.string.whitelist_mode_summary,
                            musicViewModel.whitelistFolders.size
                        )
                    } else {
                        if (musicViewModel.blacklistFolders.isEmpty()) stringResource(R.string.no_folders_added)
                        else stringResource(
                            R.string.blacklist_mode_summary,
                            musicViewModel.blacklistFolders.size
                        )
                    }
                    SettingsItem(
                        title = stringResource(
                            if (isWhitelist) R.string.manage_whitelist_folders
                            else R.string.manage_blacklist_folders
                        ),
                        subtitle = folderSubtitle,
                        onClick = { showManageFilterFoldersDialog = true }
                    )
                }
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        val saveIgnoreDurationSuccess =
                            stringResource(R.string.ignore_tracks_duration_less_than_s_set_successfully_please_restart_the_app_to_take_effect)
                        Text(
                            text = stringResource(R.string.ignore_tracks_duration_less_than),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = durationValue,
                            onValueChange = { s ->
                                if (!s.contains(".")) {
                                    durationValue = s
                                }
                            },
                            keyboardOptions = KeyboardOptions.Default.copy(
                                imeAction = ImeAction.Done,
                                keyboardType = KeyboardType.Number
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    saveIgnoreDuration(
                                        durationValue, context,
                                        String.format(saveIgnoreDurationSuccess, durationValue),
                                        focusRequester,
                                        keyboardController
                                    )
                                }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .focusRequester(focusRequester),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onBackground),
                            suffix = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        text = stringResource(R.string.s),
                                        Modifier.padding(end = 12.dp),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                    Button(
                                        onClick = {
                                            saveIgnoreDuration(
                                                durationValue, context,
                                                String.format(
                                                    saveIgnoreDurationSuccess,
                                                    durationValue
                                                ),
                                                focusRequester,
                                                keyboardController
                                            )
                                        },
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text(
                                            text = stringResource(R.string.save),
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                    }
                                }
                            }
                        )
                    }
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.08f),
                        thickness = 0.5.dp
                    )
                }
                item {
                    SettingsSwitchItem(
                        title = stringResource(R.string.merge_same_album),
                        subtitle = stringResource(R.string.merge_same_album_desc),
                        checked = mergeAlbum,
                        onCheckedChange = { value ->
                            mergeAlbum = value
                            musicViewModel.setMergeAlbum(context, value)
                        }
                    )
                }
                item {
                    SettingsItem(
                        title = stringResource(R.string.clear_album_cover_cache),
                        onClick = { showClearAlbumCache = true }
                    )
                }

                // Section 3: Playback & Audio
                item {
                    SettingsCategoryHeader(stringResource(R.string.settings_category_playback))
                }
                item {
                    SettingsSwitchItem(
                        title = stringResource(R.string.disable_audio_focus),
                        checked = !autoHandleAudioFocus,
                        onCheckedChange = { disableAudioFocus ->
                            autoHandleAudioFocus = !disableAudioFocus
                            SharedPreferencesUtils.setAutoHandleAudioFocus(context, autoHandleAudioFocus)
                            musicViewModel.browser?.setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(C.USAGE_MEDIA)
                                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                                    .build(),
                                autoHandleAudioFocus
                            )
                        }
                    )
                }
                item {
                    SettingsItem(
                        title = stringResource(R.string.settings_set_auto_play),
                        onClick = { showAutoPlaySetDialog = true }
                    )
                }
                item {
                    SettingsSwitchItem(
                        title = stringResource(R.string.auto_switch_current_track_to_top_when_random),
                        checked = autoToTopRandom,
                        onCheckedChange = { value ->
                            autoToTopRandom = value
                            SharedPreferencesUtils.setAutoToTopRandom(context, value)
                        }
                    )
                }
                item {
                    SettingsSwitchItem(
                        title = stringResource(R.string.track_sound_effect_enable),
                        subtitle = stringResource(R.string.track_sound_effect_enable_desc),
                        checked = musicViewModel.trackEffectEnabled.value,
                        onCheckedChange = { value ->
                            musicViewModel.setTrackEffectEnabled(context, value)
                        }
                    )
                }
                item {
                    val currentMode = musicViewModel.decoderMode.intValue
                    val modeText = when (currentMode) {
                        DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER -> stringResource(R.string.decoder_mode_software)
                        DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF -> stringResource(R.string.decoder_mode_hardware)
                        else -> stringResource(R.string.decoder_mode_auto)
                    }
                    SettingsItem(
                        title = stringResource(R.string.audio_decoder),
                        subtitle = modeText,
                        onClick = { openDecoderDialog.value = true }
                    )
                }
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val next = !musicViewModel.bitPerfectUsbEnable.value
                                musicViewModel.setBitPerfectUsbEnable(context, next)
                            }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 12.dp)
                            ) {
                                Text(
                                    text = stringResource(R.string.bit_perfect_usb),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = stringResource(R.string.bit_perfect_usb_desc),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                                )
                            }
                            Switch(
                                checked = musicViewModel.bitPerfectUsbEnable.value,
                                onCheckedChange = {
                                    musicViewModel.setBitPerfectUsbEnable(context, it)
                                }
                            )
                        }
                        if (musicViewModel.connectedDacName.value != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = stringResource(
                                        R.string.bit_perfect_dac_connected,
                                        musicViewModel.connectedDacName.value ?: ""
                                    ),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                if (musicViewModel.bitPerfectStatus.value.isNotEmpty()) {
                                    Text(
                                        text = musicViewModel.bitPerfectStatus.value,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (musicViewModel.connectedDacSampleRates.isNotEmpty()) {
                                    val ratesText = musicViewModel.connectedDacSampleRates
                                        .sorted()
                                        .joinToString(", ") { "${it / 1000.0}k" }
                                    Text(
                                        text = "Supported: $ratesText Hz",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(
                                            alpha = 0.7f
                                        )
                                    )
                                }
                                if (musicViewModel.bitPerfectUsbEnable.value) {
                                    Text(
                                        text = stringResource(R.string.bit_perfect_volume_notice),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(
                                            alpha = 0.7f
                                        )
                                    )
                                }
                            }
                        } else if (musicViewModel.bitPerfectUsbEnable.value) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = stringResource(R.string.bit_perfect_dac_not_connected),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                            )
                        }
                    }
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.08f),
                        thickness = 0.5.dp
                    )
                }
                if (BuildConfig.SUPPORT_VIDEO) {
                    item {
                        SettingsSwitchItem(
                            title = stringResource(R.string.video_support_enable),
                            subtitle = stringResource(R.string.video_support_enable_desc),
                            checked = musicViewModel.videoSupportEnable.value,
                            onCheckedChange = { target ->
                                if (target) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        if (ContextCompat.checkSelfPermission(
                                                context,
                                                Manifest.permission.READ_MEDIA_VIDEO
                                            ) == PackageManager.PERMISSION_GRANTED
                                        ) {
                                            musicViewModel.setVideoSupportEnable(context, true)
                                        } else {
                                            videoPermissionLauncher.launch(Manifest.permission.READ_MEDIA_VIDEO)
                                        }
                                    } else {
                                        musicViewModel.setVideoSupportEnable(context, true)
                                    }
                                } else {
                                    musicViewModel.setVideoSupportEnable(context, false)
                                }
                            }
                        )
                    }
                }

                // Section 4: Lyrics
                item {
                    SettingsCategoryHeader(stringResource(R.string.settings_category_lyrics))
                }
                item {
                    SettingsSwitchItem(
                        title = stringResource(R.string.prefer_embedded_lyrics),
                        checked = preferEmbedded,
                        onCheckedChange = { value ->
                            preferEmbedded = value
                            context.getSharedPreferences(
                                LYRICS_SETTINGS,
                                Context.MODE_PRIVATE
                            ).edit { putBoolean(FIRST_EMBEDDED_LYRICS, value) }
                        }
                    )
                }
                item {
                    SettingsItem(
                        title = stringResource(R.string.manage_lyrics_folders),
                        onClick = { showLyricsFolderDialog = true }
                    )
                }

                // Section 5: About
                item {
                    SettingsCategoryHeader(stringResource(R.string.settings_category_about))
                }
                item {
                    SettingsItem(
                        title = stringResource(R.string.about),
                        onClick = { showAboutDialog = true }
                    )
                }
            }
        }
    )
}

@Composable
fun SettingsCategoryHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 8.dp)
    )
}

@Composable
fun SettingsItem(
    title: String,
    subtitle: String? = null,
    onClick: (() -> Unit)? = null,
    trailingContent: @Composable (() -> Unit)? = null
) {
    val clickableModifier = if (onClick != null) {
        Modifier.clickable(onClick = onClick)
    } else Modifier

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .then(clickableModifier)
            .heightIn(min = 68.dp)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = if (trailingContent != null) 12.dp else 0.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (trailingContent != null) trailingContent()
    }
}

@Composable
fun SettingsSwitchItem(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    SettingsItem(
        title = title,
        subtitle = subtitle,
        onClick = { onCheckedChange(!checked) },
        trailingContent = {
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange
            )
        }
    )
}

fun saveIgnoreDuration(
    durationValue: String,
    context: Context,
    successMessage: String,
    focusRequester: FocusRequester,
    keyboardController: SoftwareKeyboardController?
) {
    if (durationValue.isEmpty()) {
        return
    }
    // -1 don't ignore any,0 ignore duration less than or equal 0s,
    SharedPreferencesUtils.setIgnoreDuration(context, durationValue.toLong())
    Toast.makeText(
        context,
        successMessage,
        Toast.LENGTH_SHORT
    ).show()
    focusRequester.freeFocus()
    keyboardController?.hide()
}

@UnstableApi
@Composable
fun ManageTabDialog(musicViewModel: MusicViewModel, onDismiss: () -> Unit) {

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val mainTabList = remember { mutableStateListOf<MainTab>() }
    var size by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        val tabs = withContext(Dispatchers.IO) {
            musicViewModel.getDb(context).MainTabDao().findAllMainTabSortByPriority()
        }
        mainTabList.addAll(tabs)
        size = mainTabList.size
    }
    fun onConfirmation() {
        musicViewModel.mainTabList.clear()
        if (mainTabList.find { it.isShow } == null) {
            Toast.makeText(context, "Must has at least one tab", Toast.LENGTH_SHORT).show()
            return
        }
        mainTabList.forEachIndexed { index, it ->
            it.priority = index
            if (it.isShow) {
                musicViewModel.mainTabList.add(it)
            }
        }
        coroutineScope.launch {
            withContext(Dispatchers.IO) {
                musicViewModel.getDb(context).MainTabDao().updateAll(mainTabList)
            }
            onDismiss()
        }
    }


    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = true, dismissOnBackPress = true,
            dismissOnClickOutside = true
        ),
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = MaterialTheme.colorScheme.background),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(color = MaterialTheme.colorScheme.onBackground)
                )
                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    item {
                        Text(
                            text = stringResource(R.string.manage_tab_items), modifier = Modifier
                                .padding(2.dp),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    items(size) {
                        val item = mainTabList[it]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    start = 10.dp, end = 10.dp
                                ),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        )
                        {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Row(
                                    modifier = Modifier.width(120.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (it != 0) {
                                        FilledIconButton(
                                            modifier = Modifier
                                                .size(50.dp)
                                                .clip(CircleShape)
                                                .semantics {
                                                    contentDescription = "Up tab priority"
                                                },
                                            onClick = {
                                                mainTabList.remove(item)
                                                mainTabList.add(it - 1, item)
                                            }) {
                                            Icon(
                                                imageVector = Icons.Default.KeyboardArrowUp,
                                                contentDescription = "Operate More, will open dialog",
                                                modifier = Modifier
                                                    .size(30.dp)
                                                    .clip(CircleShape),
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(50.dp)
                                                .clip(CircleShape),
                                        )
                                    }
                                    HorizontalDivider(
                                        color = Color.Transparent,
                                        modifier = Modifier
                                            .height(40.dp)
                                            .width(10.dp)
                                            .background(
                                                MaterialTheme.colorScheme.background
                                            )
                                    )
                                    if (it < mainTabList.size - 1) {
                                        FilledIconButton(
                                            modifier = Modifier
                                                .size(50.dp)
                                                .clip(CircleShape)
                                                .semantics {
                                                    contentDescription = "Down tab priority"
                                                },
                                            onClick = {
                                                mainTabList.remove(item)
                                                mainTabList.add(it + 1, item)
                                            }) {
                                            Icon(
                                                imageVector = Icons.Default.KeyboardArrowDown,
                                                contentDescription = "Operate More, will open dialog",
                                                modifier = Modifier
                                                    .size(30.dp)
                                                    .clip(CircleShape),
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = stringResource(
                                        id = Utils.translateMap[item.name] ?: R.string.app_name
                                    ),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                            var isChecked by remember {
                                mutableStateOf(false)
                            }
                            isChecked = item.isShow
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { v ->
                                    isChecked = v
                                    item.isShow = v
                                },
                                modifier = Modifier
                                    .padding(8.dp)
                                    .semantics {
                                        contentDescription = if (isChecked) {
                                            "Show this tab${item.name}"
                                        } else {
                                            "Hide this tab${item.name}"
                                        }
                                    }
                            )
                        }
                    }
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                        ) {
                            TextButton(
                                onClick = { onDismiss() },
                                modifier = Modifier
                                    .padding(8.dp)
                                    .fillMaxWidth(0.5f),
                            ) {
                                Text(
                                    stringResource(R.string.cancel),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                            HorizontalDivider(
                                modifier = Modifier
                                    .background(MaterialTheme.colorScheme.onBackground)
                                    .width(1.dp)
                                    .height(50.dp)
                            )
                            TextButton(
                                onClick = {
                                    onConfirmation()
                                },
                                modifier = Modifier
                                    .padding(8.dp)
                                    .fillMaxWidth(),

                                ) {
                                Text(
                                    stringResource(id = R.string.confirm),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }
                }

            }
        }
    )
}


data class AboutItem(
    val title: String,
    val subtitle: String,
    val url: String
)

@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val color = MaterialTheme.colorScheme.onBackground

    val items = listOf(
        AboutItem(
            title = stringResource(R.string.sourcecode),
            subtitle = "github.com/ZTFtrue/MonsterMusic",
            url = "https://github.com/ZTFtrue/MonsterMusic"
        ),
        AboutItem(
            title = stringResource(R.string.settings_thanks_for_translating),
            subtitle = "github.com/ZTFtrue/MonsterMusic/blob/master/readme.md#contribute-translate",
            url = "https://github.com/ZTFtrue/MonsterMusic/blob/master/readme.md#contribute-translate"
        ),
        AboutItem(
            title = stringResource(R.string.about_item_ffmpeg),
            subtitle = "ffmpeg.org",
            url = "https://ffmpeg.org/"
        ),
        AboutItem(
            title = stringResource(R.string.settings_link_media3),
            subtitle = "developer.android.com/media/media3",
            url = "https://developer.android.com/guide/topics/media/media3"
        ),
        AboutItem(
            title = stringResource(R.string.about_item_compose),
            subtitle = "developer.android.com/jetpack/compose",
            url = "https://developer.android.com/jetpack/compose"
        ),
        AboutItem(
            title = stringResource(R.string.about_item_coil),
            subtitle = "coil-kt.github.io/coil",
            url = "https://coil-kt.github.io/coil/"
        ),
        AboutItem(
            title = stringResource(R.string.about_item_room),
            subtitle = "developer.android.com/training/data-storage/room",
            url = "https://developer.android.com/training/data-storage/room"
        ),
        AboutItem(
            title = stringResource(R.string.settings_link_biquad_designer),
            subtitle = "arachnoid.com/BiQuadDesigner",
            url = "https://arachnoid.com/BiQuadDesigner/index.html"
        ),
        AboutItem(
            title = stringResource(R.string.about_item_cookbook),
            subtitle = "w3.org/TR/audio-eq-cookbook",
            url = "https://www.w3.org/TR/audio-eq-cookbook/"
        )
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = true,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp, horizontal = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stringResource(id = R.string.about_thanks),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "v${BuildConfig.VERSION_NAME} (${BuildConfig.BUILD_TYPE})",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
                )

                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .heightIn(max = 420.dp)
                ) {
                    items(items.size) { index ->
                        val item = items[index]
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 52.dp)
                                .drawBehind {
                                    drawLine(
                                        color = color.copy(alpha = 0.2f),
                                        start = Offset(0f, size.height - 1.dp.toPx()),
                                        end = Offset(size.width, size.height - 1.dp.toPx()),
                                        strokeWidth = 1.dp.toPx()
                                    )
                                }
                                .clickable {
                                    openBrowser(item.url, context)
                                }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Column {
                                Text(
                                    text = item.title,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = item.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            stringResource(id = R.string.confirm),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun AudioDecoderModeDialog(
    musicViewModel: MusicViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedMode by remember { mutableIntStateOf(musicViewModel.decoderMode.intValue) }

    val options = listOf(
        Triple(
            DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON,
            stringResource(R.string.decoder_mode_auto),
            stringResource(R.string.decoder_mode_desc)
        ),
        Triple(
            DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER,
            stringResource(R.string.decoder_mode_software),
            stringResource(R.string.decoder_mode_software)
        ),
        Triple(
            DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF,
            stringResource(R.string.decoder_mode_hardware),
            stringResource(R.string.decoder_mode_hardware)
        )
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = true,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = stringResource(R.string.audio_decoder),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(16.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                ) {
                    options.forEach { (mode, title, desc) ->
                        val isSelected = selectedMode == mode
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(
                                        alpha = 0.4f
                                    )
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                )
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedMode = mode }
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedMode = mode }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = title,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = desc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(stringResource(R.string.cancel))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            musicViewModel.setDecoderMode(context, selectedMode)
                            onDismiss()
                        }
                    ) {
                        Text(stringResource(R.string.confirm))
                    }
                }
            }
        }
    }
}

@UnstableApi
@Composable
fun ManageAutoPlayDialog(onDismiss: () -> Unit) {

    val context = LocalContext.current

    var enableAutoPlay by remember { mutableStateOf(false) }
    var waitTime by remember { mutableLongStateOf(1000) }
    var waitTimeString by remember { mutableStateOf("1") }
    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current
    LaunchedEffect(Unit) {
        enableAutoPlay = SharedPreferencesUtils.getAutoPlayEnable(context)
        waitTime = SharedPreferencesUtils.getAutoPlayWaitTime(context)
        waitTimeString = (waitTime / 1000).toString()
    }
    fun onConfirmation() {
        SharedPreferencesUtils.setAutoPlayEnable(context, enableAutoPlay)
        SharedPreferencesUtils.setAutoPlayWaitTime(context, waitTime)
        onDismiss()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = true, dismissOnBackPress = true,
            dismissOnClickOutside = true
        ),
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = MaterialTheme.colorScheme.background),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(color = MaterialTheme.colorScheme.background),
                    verticalArrangement = Arrangement.Top,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    HorizontalDivider(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(color = MaterialTheme.colorScheme.onBackground)
                    )
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                    ) {
                        item {
                            Row(
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                            ) {
                                Checkbox(
                                    checked = enableAutoPlay,
                                    onCheckedChange = { v ->
                                        enableAutoPlay = v
                                    },
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .width(60.dp)
                                        .height(60.dp)
                                        .semantics {
                                            contentDescription = if (enableAutoPlay) {
                                                "Enable auto play"
                                            } else {
                                                "Disable auto play"
                                            }
                                        }
                                )
                                Text(
                                    text = stringResource(R.string.settings_enable_auto_play_description),
                                    modifier = Modifier.padding(8.dp),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(0.dp)
                                    .drawBehind {
//                                    drawLine(
////                                        color = MaterialTheme.colorScheme.onBackground,
//                                        start = Offset(0f, size.height - 1.dp.toPx()),
//                                        end = Offset(size.width, size.height - 1.dp.toPx()),
//                                        strokeWidth = 1.dp.toPx()
//                                    )
                                    }
                                    .clickable {

                                    },
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Column {
                                    Text(
                                        text = stringResource(R.string.settings_wait_time_before_auto_play),
                                        Modifier.padding(start = 10.dp),
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    OutlinedTextField(
                                        enabled = enableAutoPlay,
                                        value = waitTimeString,
                                        onValueChange = { s ->
                                            if (!s.contains(".")) {
                                                waitTimeString = s
                                                if (s.isNotEmpty()) {
                                                    waitTime = s.toLong() * 1000
                                                }
                                            }
                                        },
                                        keyboardOptions = KeyboardOptions.Default.copy(
                                            imeAction = ImeAction.Done,
                                            keyboardType = KeyboardType.Number
                                        ),
                                        keyboardActions = KeyboardActions(
                                            onDone = {
                                                focusRequester.freeFocus()
                                                keyboardController?.hide()
                                            }
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .focusRequester(focusRequester)
                                            .background(MaterialTheme.colorScheme.primary),
                                        colors = TextFieldDefaults.colors(
                                            errorTextColor = MaterialTheme.colorScheme.primary,
                                            focusedTextColor = MaterialTheme.colorScheme.primary,
                                            disabledTextColor = MaterialTheme.colorScheme.onSurface.copy(
                                                alpha = 0.38f
                                            ),
                                            unfocusedTextColor = MaterialTheme.colorScheme.primary,
                                            focusedContainerColor = MaterialTheme.colorScheme.background,
                                            unfocusedContainerColor = MaterialTheme.colorScheme.background,
                                            cursorColor = MaterialTheme.colorScheme.primary,
                                            errorCursorColor = MaterialTheme.colorScheme.error,
                                            focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                                            unfocusedIndicatorColor = MaterialTheme.colorScheme.onSurface.copy(
                                                alpha = 0.38f
                                            ),
                                            disabledIndicatorColor = MaterialTheme.colorScheme.onSurface.copy(
                                                alpha = 0.12f
                                            ),
                                            errorIndicatorColor = MaterialTheme.colorScheme.error,
                                            disabledLeadingIconColor = MaterialTheme.colorScheme.onSurface.copy(
                                                alpha = 0.38f
                                            ),
                                            errorLeadingIconColor = MaterialTheme.colorScheme.error,
                                            disabledTrailingIconColor = MaterialTheme.colorScheme.onSurface.copy(
                                                alpha = 0.38f
                                            ),
                                            errorTrailingIconColor = MaterialTheme.colorScheme.error,
                                            focusedLabelColor = MaterialTheme.colorScheme.primary,
                                            unfocusedLabelColor = MaterialTheme.colorScheme.onSurface.copy(
                                                alpha = 0.38f
                                            ),
                                            disabledLabelColor = MaterialTheme.colorScheme.onSurface.copy(
                                                alpha = 0.38f
                                            ),
                                            errorLabelColor = MaterialTheme.colorScheme.error,
                                            disabledPlaceholderColor = MaterialTheme.colorScheme.onSurface.copy(
                                                alpha = 0.38f
                                            )
                                        ),
                                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onBackground),
                                        suffix = {
                                            Row(
                                                horizontalArrangement = Arrangement.Start,
                                                verticalAlignment = Alignment.CenterVertically,
                                            ) {
                                                Text(
                                                    text = stringResource(R.string.s),
                                                    Modifier.padding(start = 10.dp, end = 20.dp),
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                            }
                                        }
                                    )
                                }
                            }
                        }
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                            ) {
                                TextButton(
                                    onClick = {
                                        onConfirmation()
                                    },
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .fillMaxWidth(0.5f),
                                ) {
                                    Text(
                                        "Confirm",
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                                HorizontalDivider(
                                    modifier = Modifier
                                        .background(MaterialTheme.colorScheme.onBackground)
                                        .width(1.dp)
                                        .height(50.dp)
                                )
                                TextButton(
                                    onClick = {
                                        onDismiss()
                                    },
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .fillMaxWidth(),

                                    ) {
                                    Text(
                                        "Cancel",
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                            }
                        }
                    }
                }


            }
        }
    )
}


@UnstableApi
@Composable
fun ManageLyricsFolderDialog(musicViewModel: MusicViewModel, onDismiss: () -> Unit) {

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val windowInfo = LocalWindowInfo.current
    val containerHeightPx = windowInfo.containerSize.height
//    val density = LocalDensity.current
//    val screenHeightDp = with(density) { windowInfo.containerSize.height.toDp() }
    val folderList = remember { mutableStateListOf<StorageFolder>() }

    LaunchedEffect(Unit) {
        val files = withContext(Dispatchers.IO) {
            musicViewModel.getDb(context).StorageFolderDao().findAll()
        }
        folderList.addAll(files)
    }
    fun onConfirmation() {
        onDismiss()
    }


    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = true, dismissOnBackPress = true,
            dismissOnClickOutside = true
        ),
        content = {

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = MaterialTheme.colorScheme.background),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                val color = MaterialTheme.colorScheme.background
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .padding(0.dp)
                        .clickable {
                            onDismiss()
                            Utils.setTracksFolder(context)
                        }
                        .drawBehind {
                            drawLine(
                                color = color,
                                start = Offset(0f, size.height - 1.dp.toPx()),
                                end = Offset(size.width, size.height - 1.dp.toPx()),
                                strokeWidth = 1.dp.toPx()
                            )
                        },
                ) {
                    Text(
                        text = stringResource(R.string.add_tracks_folder),
                        Modifier.padding(start = 10.dp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(color = MaterialTheme.colorScheme.onBackground)
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .padding(0.dp)
                        .clickable {
                            onConfirmation()
                            Utils.setLyricsFolder(context)
                        }
                        .drawBehind {
                            drawLine(
                                color = color,
                                start = Offset(0f, size.height - 1.dp.toPx()),
                                end = Offset(size.width, size.height - 1.dp.toPx()),
                                strokeWidth = 1.dp.toPx()
                            )
                        },
                ) {
                    Text(
                        text = stringResource(R.string.add_lyrics_folders),
                        Modifier.padding(start = 10.dp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(color = MaterialTheme.colorScheme.onBackground)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .padding(0.dp)
                        .clickable {
                            onConfirmation()
                            Utils.setArtistFolder(context)
                        }
                        .drawBehind {
                            drawLine(
                                color = color,
                                start = Offset(0f, size.height - 1.dp.toPx()),
                                end = Offset(size.width, size.height - 1.dp.toPx()),
                                strokeWidth = 1.dp.toPx()
                            )
                        },
                ) {
                    Text(
                        text = stringResource(R.string.set_artist_folder_artist_name_jpg_jpeg_png),
                        Modifier.padding(start = 10.dp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(color = MaterialTheme.colorScheme.onBackground)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .padding(0.dp)
                        .clickable {
                            onConfirmation()
                            Utils.setGenreFolder(context)
                        }
                        .drawBehind {
                            drawLine(
                                color = color,
                                start = Offset(0f, size.height - 1.dp.toPx()),
                                end = Offset(size.width, size.height - 1.dp.toPx()),
                                strokeWidth = 1.dp.toPx()
                            )
                        },
                ) {
                    Text(
                        text = stringResource(R.string.set_genre_folder_genre_name_jpg_jpeg_png),
                        Modifier.padding(start = 10.dp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(color = MaterialTheme.colorScheme.onBackground)
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                ) {
                    items(folderList.size) {
                        val item = folderList[it]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    start = 10.dp, end = 10.dp
                                ),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        )
                        {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = if (item.type == LYRICS_TYPE) stringResource(R.string.text_prefix_lyrics) else if (item.type == ARTIST_TYPE) stringResource(
                                        R.string.text_prefix_artist
                                    ) else if (item.type == TRACKS_TYPE) stringResource(R.string.text_tracks_folder) else stringResource(
                                        R.string.text_prefix_genre
                                    ),
                                    color = MaterialTheme.colorScheme.onBackground,
                                    modifier = Modifier.horizontalScroll(rememberScrollState(0))
                                )
                                HorizontalDivider(
                                    modifier = Modifier
                                        .width(1.dp)
                                        .fillMaxWidth(0.1f)
                                        .height(50.dp)
                                )
                                Text(
                                    text = item.uri,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    modifier = Modifier.horizontalScroll(rememberScrollState(0))
                                )
                            }
                            IconButton(
                                modifier = Modifier.width(50.dp),
                                onClick = {
                                    coroutineScope.launch {
                                        item.id?.let { it1 ->
                                            withContext(Dispatchers.IO) {
                                                musicViewModel.getDb(context).StorageFolderDao()
                                                    .deleteById(it1)
                                            }
                                        }
                                        folderList.removeAt(it)
                                    }
                                }) {
                                Icon(
                                    imageVector = Icons.Outlined.Delete,
                                    contentDescription = stringResource(R.string.content_description_remove_folder),
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(CircleShape),
                                    tint = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                ) {
                    TextButton(
                        onClick = {
                            onConfirmation()
                        },
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(),

                        ) {
                        Text(
                            "Close",
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }
        }
    )
}

@Composable
fun ScanModeDialog(
    musicViewModel: MusicViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val switchToBlacklistToast = stringResource(R.string.switch_to_blacklist_toast)
    val switchToWhitelistToast = stringResource(R.string.switch_to_whitelist_toast)
    var selectedMode by remember { mutableIntStateOf(SharedPreferencesUtils.getScanMode(context)) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = true,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surface)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.folder_scan_mode),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(16.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Option 1: Blacklist mode
                val isModeBlacklist = selectedMode == SharedPreferencesUtils.SCAN_MODE_BLACKLIST
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isModeBlacklist) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        )
                        .border(
                            width = if (isModeBlacklist) 2.dp else 1.dp,
                            color = if (isModeBlacklist) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { selectedMode = SharedPreferencesUtils.SCAN_MODE_BLACKLIST }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isModeBlacklist,
                        onClick = { selectedMode = SharedPreferencesUtils.SCAN_MODE_BLACKLIST }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.scan_mode_blacklist),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stringResource(R.string.scan_mode_blacklist_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Option 2: Whitelist mode
                val isModeWhitelist = selectedMode == SharedPreferencesUtils.SCAN_MODE_WHITELIST
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isModeWhitelist) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        )
                        .border(
                            width = if (isModeWhitelist) 2.dp else 1.dp,
                            color = if (isModeWhitelist) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { selectedMode = SharedPreferencesUtils.SCAN_MODE_WHITELIST }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isModeWhitelist,
                        onClick = { selectedMode = SharedPreferencesUtils.SCAN_MODE_WHITELIST }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.scan_mode_whitelist),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stringResource(R.string.scan_mode_whitelist_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.cancel))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        val currentMode = SharedPreferencesUtils.getScanMode(context)
                        if (selectedMode == SharedPreferencesUtils.SCAN_MODE_BLACKLIST) {
                            if (currentMode != SharedPreferencesUtils.SCAN_MODE_BLACKLIST) {
                                musicViewModel.setScanMode(
                                    context,
                                    SharedPreferencesUtils.SCAN_MODE_BLACKLIST
                                )
                                Toast.makeText(
                                    context,
                                    switchToBlacklistToast,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                            onDismiss()
                        } else {
                            val whitelist = SharedPreferencesUtils.getWhitelistFolders(context)
                            if (whitelist.isEmpty()) {
                                onDismiss()
                                Utils.addWhitelistFolder(context)
                            } else {
                                if (currentMode != SharedPreferencesUtils.SCAN_MODE_WHITELIST) {
                                    musicViewModel.setScanMode(
                                        context,
                                        SharedPreferencesUtils.SCAN_MODE_WHITELIST
                                    )
                                    Toast.makeText(
                                        context,
                                        switchToWhitelistToast,
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                                onDismiss()
                            }
                        }
                    }
                ) {
                    Text(stringResource(R.string.confirm))
                }
            }
        }
    }
}

@UnstableApi
@Composable
fun ManageFolderDialog(
    musicViewModel: MusicViewModel,
    onDismiss: () -> Unit
) {

    val context = LocalContext.current

    val folderList = remember { mutableStateListOf<FolderList>() }

    LaunchedEffect(Unit) {
        val folderMap: HashMap<Long, FolderList> = withContext(Dispatchers.IO) {
            val map = FolderManger.getMusicFolders(context)
            val currentBlacklist = SharedPreferencesUtils.getBlacklistFolders(context)
            val blacklistBucketIds = currentBlacklist.mapNotNull { it.bucketId }.toSet()
            val blacklistPaths =
                currentBlacklist.map { it.path.trimEnd('/') }.filter { it.isNotEmpty() }.toSet()
            map.values.forEach { folderItem ->
                val normalizedFolderPath = folderItem.path.trimEnd('/')
                if (blacklistBucketIds.contains(folderItem.id) ||
                    blacklistPaths.contains(normalizedFolderPath) ||
                    blacklistPaths.any { normalizedFolderPath.startsWith("$it/") || normalizedFolderPath == it }
                ) {
                    folderItem.isShow = false
                }
            }
            map
        }
        folderList.clear()
        folderList.addAll(folderMap.values)
    }
    fun onConfirmation() {
        val currentBlacklist = SharedPreferencesUtils.getBlacklistFolders(context).toMutableList()
        folderList.forEach { item ->
            val normalizedItemPath = item.path.trimEnd('/')
            if (!item.isShow) {
                val alreadyExists = currentBlacklist.any {
                    (it.bucketId != null && it.bucketId == item.id) ||
                            (normalizedItemPath.isNotEmpty() && it.path.trimEnd('/')
                                .equals(normalizedItemPath, ignoreCase = true))
                }
                if (!alreadyExists) {
                    currentBlacklist.add(
                        FilterFolder(
                            path = item.path,
                            name = item.name.ifBlank { item.path.substringAfterLast('/') },
                            bucketId = item.id
                        )
                    )
                }
            } else {
                currentBlacklist.removeAll {
                    (it.bucketId != null && it.bucketId == item.id) ||
                            (normalizedItemPath.isNotEmpty() && it.path.trimEnd('/')
                                .equals(normalizedItemPath, ignoreCase = true))
                }
            }
        }
        SharedPreferencesUtils.saveBlacklistFolders(context, currentBlacklist)
        musicViewModel.blacklistFolders.clear()
        musicViewModel.blacklistFolders.addAll(currentBlacklist)
        musicViewModel.refreshAllTracks(context)
        onDismiss()
    }


    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = true, dismissOnBackPress = true,
            dismissOnClickOutside = true
        ),
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.75f)
                    .background(color = MaterialTheme.colorScheme.background),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(color = MaterialTheme.colorScheme.background),
                    verticalArrangement = Arrangement.Top,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    HorizontalDivider(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(color = MaterialTheme.colorScheme.onBackground)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    )
                    {
                        Text(
                            text = stringResource(R.string.uncheck_folders_to_ignore),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                    ) {
                        items(folderList.size) {
                            val item = folderList[it]
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(
                                        start = 10.dp, end = 10.dp
                                    ),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            )
                            {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = item.name,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                                var isChecked by remember {
                                    mutableStateOf(false)
                                }
                                isChecked = item.isShow
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { v ->
                                        isChecked = v
                                        item.isShow = v
                                    },
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .semantics {
                                            contentDescription = if (isChecked) {
                                                "Show this tab${item.name}"
                                            } else {
                                                "Hide this tab${item.name}"
                                            }
                                        }
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                ) {
                    TextButton(
                        onClick = { onDismiss() },
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(0.5f),
                    ) {
                        Text(
                            stringResource(R.string.cancel),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    HorizontalDivider(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.onBackground)
                            .width(1.dp)
                            .height(50.dp)
                    )
                    TextButton(
                        onClick = {
                            onConfirmation()
                        },
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(),

                        ) {
                        Text(
                            stringResource(id = R.string.confirm),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }
        }
    )
}


@OptIn(ExperimentalStdlibApi::class)
@Composable
fun SetWidgetDialog(musicViewModel: MusicViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val initialColor = SharedPreferencesUtils.getWidgetBackground(context)
    val initialContrast = SharedPreferencesUtils.getWidgetTextContrast(context)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.88f)
                .clip(RoundedCornerShape(16.dp)),
            color = MaterialTheme.colorScheme.background,
            shape = RoundedCornerShape(16.dp)
        ) {
            WidgetConfigContent(
                initialColorHex = initialColor,
                initialContrast = initialContrast,
                canPinWidget = true,
                currentTrackName = musicViewModel.currentPlay.value?.name,
                currentArtistName = musicViewModel.currentPlay.value?.artist,
                currentCoverPath = musicViewModel.currentPlay.value?.path,
                isPlaying = musicViewModel.browser?.isPlaying ?: false,
                onSave = { colorHex, contrast ->
                    SharedPreferencesUtils.setWidgetBackground(context, colorHex)
                    SharedPreferencesUtils.setWidgetTextContrast(context, contrast)
                    SharedPreferencesUtils.setWidgetEnable(context, true)

                    val appWidgetManager = AppWidgetManager.getInstance(context)
                    val ids = appWidgetManager.getAppWidgetIds(
                        ComponentName(context, PlayMusicWidget::class.java)
                    )
                    for (id in ids) {
                        PlayMusicWidget.updateAppWidget(context, appWidgetManager, id)
                    }
                    onDismiss()
                },
                onDismiss = onDismiss
            )
        }
    }
}

@UnstableApi
@Composable
fun ClearAlbumCoverDialog(onDismiss: () -> Unit) {

    val context = LocalContext.current

    fun onConfirmation() {
        Utils.clearAlbumCoverCache(context)
        onDismiss()
    }


    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = true, dismissOnBackPress = true,
            dismissOnClickOutside = true
        ),
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = MaterialTheme.colorScheme.background),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = stringResource(R.string.are_you_sure_you_want_to_clear_album_cover_cache_this_will_take_some_time_when_next_open_album_list),
                    modifier = Modifier
                        .padding(2.dp),
                    color = MaterialTheme.colorScheme.onBackground
                )

                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(color = MaterialTheme.colorScheme.onBackground)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                ) {
                    TextButton(
                        onClick = { onDismiss() },
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(0.5f),
                    ) {
                        Text(
                            stringResource(R.string.cancel),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    HorizontalDivider(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.onBackground)
                            .width(1.dp)
                            .height(50.dp)
                    )
                    TextButton(
                        onClick = {
                            onConfirmation()
                        },
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(),

                        ) {
                        Text(
                            stringResource(id = R.string.confirm),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }
        }
    )
}

@UnstableApi
@Composable
fun SetListIndicatorDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var showSlideIndicator by remember { mutableStateOf(false) }
    var showTopIndicator by remember { mutableStateOf(false) }
    var showQueueIndicator by remember { mutableStateOf(false) }
    var showAlbumIndicator by remember { mutableStateOf(false) }
    var showArtistIndicator by remember { mutableStateOf(false) }
    val sharedPreferences =
        context.getSharedPreferences("list_indicator_config", Context.MODE_PRIVATE)
    LaunchedEffect(Unit) {
        showSlideIndicator = sharedPreferences.getBoolean("show_slide_indicator", false)
        showTopIndicator = sharedPreferences.getBoolean("show_top_indicator", false)
        showQueueIndicator = sharedPreferences.getBoolean("show_queue_indicator", false)
        showAlbumIndicator = sharedPreferences.getBoolean("show_album_indicator", false)
        showArtistIndicator = sharedPreferences.getBoolean("show_artist_indicator", false)
    }
    @SuppressLint("ApplySharedPref")
    fun onConfirmation() {
        sharedPreferences.edit {
            putBoolean("show_slide_indicator", showSlideIndicator)
                .putBoolean("show_top_indicator", showTopIndicator)
                .putBoolean("show_queue_indicator", showQueueIndicator)
                .putBoolean("show_album_indicator", showAlbumIndicator)
                .putBoolean("show_artist_indicator", showArtistIndicator)
        }
        onDismiss()
    }


    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = true, dismissOnBackPress = true,
            dismissOnClickOutside = true
        ),
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = MaterialTheme.colorScheme.background),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .background(color = MaterialTheme.colorScheme.background),
                    verticalArrangement = Arrangement.Top,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    HorizontalDivider(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(color = MaterialTheme.colorScheme.onBackground)
                    )
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        item {
                            val showSlideDesc =
                                stringResource(R.string.content_description_show_slide_indicator)
                            val hideSlideDesc =
                                stringResource(R.string.content_description_hide_slide_indicator)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(
                                        start = 10.dp, end = 10.dp
                                    ),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            )
                            {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = stringResource(R.string.show_slide_indicator),
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                                Checkbox(
                                    checked = showSlideIndicator,
                                    onCheckedChange = { v ->
                                        showSlideIndicator = v
                                    },
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .semantics {
                                            contentDescription = if (showSlideIndicator) {
                                                showSlideDesc
                                            } else {
                                                hideSlideDesc
                                            }
                                        }
                                )
                            }
                        }
                        item {
                            val showTopDesc =
                                stringResource(R.string.content_description_show_top_indicator)
                            val hideTopDesc =
                                stringResource(R.string.content_description_hide_top_indicator)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(
                                        start = 10.dp, end = 10.dp
                                    ),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            )
                            {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = stringResource(R.string.show_top_indicator),
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                                Checkbox(
                                    checked = showTopIndicator,
                                    onCheckedChange = { v ->
                                        showTopIndicator = v
                                    },
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .semantics {
                                            contentDescription = if (showTopIndicator) {
                                                showTopDesc
                                            } else {
                                                hideTopDesc
                                            }
                                        }
                                )
                            }
                        }
                        item {
                            val showQueueDesc =
                                stringResource(R.string.content_description_show_indicator_in_queue)
                            val hideQueueDesc =
                                stringResource(R.string.content_description_hide_indicator_in_queue)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(
                                        start = 10.dp, end = 10.dp
                                    ),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            )
                            {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = stringResource(R.string.show_indicator_in_queue),
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                                Checkbox(
                                    checked = showQueueIndicator,
                                    onCheckedChange = { v ->
                                        showQueueIndicator = v
                                    },
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .semantics {
                                            contentDescription = if (showQueueIndicator) {
                                                showQueueDesc
                                            } else {
                                                hideQueueDesc
                                            }
                                        }
                                )
                            }
                        }
                        item {
                            val showAlbumDesc =
                                stringResource(R.string.content_description_show_indicator_in_albums)
                            val hideAlbumDesc =
                                stringResource(R.string.content_description_hide_indicator_in_albums)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(
                                        start = 10.dp, end = 10.dp
                                    ),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            )
                            {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = stringResource(R.string.show_indicator_in_albums),
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                                Checkbox(
                                    checked = showAlbumIndicator,
                                    onCheckedChange = { v ->
                                        showAlbumIndicator = v
                                    },
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .semantics {
                                            contentDescription = if (showAlbumIndicator) {
                                                showAlbumDesc
                                            } else {
                                                hideAlbumDesc
                                            }
                                        }
                                )
                            }
                        }
                        item {
                            val showArtistDesc =
                                stringResource(R.string.content_description_show_indicator_in_artists)
                            val hideArtistDesc =
                                stringResource(R.string.content_description_hide_indicator_in_artists)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(
                                        start = 10.dp, end = 10.dp
                                    ),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            )
                            {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = stringResource(R.string.show_indicator_in_artists),
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                                Checkbox(
                                    checked = showArtistIndicator,
                                    onCheckedChange = { v ->
                                        showArtistIndicator = v
                                    },
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .semantics {
                                            contentDescription = if (showArtistIndicator) {
                                                showArtistDesc
                                            } else {
                                                hideArtistDesc
                                            }
                                        }
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                ) {
                    TextButton(
                        onClick = { onDismiss() },
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(0.5f),
                    ) {
                        Text(
                            stringResource(R.string.cancel),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    HorizontalDivider(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.onBackground)
                            .width(1.dp)
                            .height(50.dp)
                    )
                    TextButton(
                        onClick = {
                            onConfirmation()
                        },
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(),

                        ) {
                        Text(
                            stringResource(id = R.string.confirm),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }
        }
    )
}

@UnstableApi
@Composable
fun SwitchLanguageDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current

    val language = remember { mutableStateListOf<LanguageModel>() }
    var size by remember { mutableIntStateOf(0) }
    var selectIndex by remember { mutableIntStateOf(0) }
    var locale by remember { mutableStateOf(Locale.getDefault().language) }
    val supportedLanguages = listOf(
        "en",
        "zh",
        "zh-TW",
        "ja",
        "fr",
        "ar",
        "de",
        "eo",
        "hu",
        "ru",
        "tr"
    ) // App-supported languages
    val currentLocale = LocalConfiguration.current.locales[0]
    val systemLanguage = if (currentLocale.country.equals(
            "TW",
            ignoreCase = true
        ) || currentLocale.script.equals("Hant", ignoreCase = true)
    ) {
        "zh-TW"
    } else {
        currentLocale.language
    }
    val followSystemText = stringResource(R.string.language_follow_system)

    LaunchedEffect(Unit) {
        locale = if (systemLanguage in supportedLanguages) {
            systemLanguage // Use system language if supported
        } else {
            "en" // Fallback to English
        }
        language.add(LanguageModel("English", "en"))
        language.add(LanguageModel("中文", "zh"))
        language.add(LanguageModel("繁體中文 (台灣)", "zh-TW"))
        language.add(LanguageModel("日本語", "ja"))
        language.add(LanguageModel("Français", "fr"))
        language.add(LanguageModel("العربية", "ar"))
        language.add(LanguageModel("Deutsch", "de"))
        language.add(LanguageModel("Esperanto", "eo"))
        language.add(LanguageModel("Magyar", "hu"))
        language.add(LanguageModel("Русский", "ru"))
        language.add(LanguageModel("Türkçe", "tr"))
        language.add(LanguageModel(followSystemText, ""))
        val savedLang = SharedPreferencesUtils.getCurrentLanguage(context)
        locale = if (savedLang.isNullOrEmpty()) {
            ""
        } else {
            savedLang
        }
        val foundIndex = language.indexOfFirst { it.code == locale }
        selectIndex = if (foundIndex != -1) foundIndex else language.indexOfFirst { it.code == "" }
            .coerceAtLeast(0)
        size = language.size
    }
    fun onConfirmation() {
        val activity = context as? Activity
        SharedPreferencesUtils.setCurrentLanguage(context, language[selectIndex].code)
        activity?.runOnUiThread {
            activity.recreate()
        }
//      Locale(language[selectIndex].code)
//        val localeList = LocaleListCompat.forLanguageTags("en-US")
//        AppCompatDelegate.setApplicationLocales(localeList)
//        val currentLocale = AppCompatDelegate.getApplicationLocales()[0]
//        Log.d("LanguageChange", "Current Language: $currentLocale")
        onDismiss()
    }


    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = true, dismissOnBackPress = true,
            dismissOnClickOutside = true
        ),
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = MaterialTheme.colorScheme.background),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(color = MaterialTheme.colorScheme.onBackground)
                )
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                ) {
                    item {
                        Text(
                            text = stringResource(R.string.set_language), modifier = Modifier
                                .padding(2.dp),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    items(size) {
                        val item = language[it]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    start = 10.dp, end = 10.dp
                                ),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        )
                        {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Row(
                                    modifier = Modifier.width(120.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.name,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                                var isChecked by remember {
                                    mutableStateOf(false)
                                }
                                isChecked = it == selectIndex
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { v ->
                                        isChecked = v
                                        selectIndex = it
                                    },
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .semantics {
                                            contentDescription = if (isChecked) {
                                                "Show this language ${item.name}"
                                            } else {
                                                "Hide this language ${item.name}"
                                            }
                                        }
                                )
                            }
                        }
                    }
                }
                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(color = MaterialTheme.colorScheme.onBackground)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                ) {
                    TextButton(
                        onClick = { onDismiss() },
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(0.5f),
                    ) {
                        Text(
                            stringResource(R.string.cancel),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    HorizontalDivider(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.onBackground)
                            .width(1.dp)
                            .height(50.dp)
                    )
                    TextButton(
                        onClick = {
                            onConfirmation()
                        },
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(),

                        ) {
                        Text(
                            stringResource(id = R.string.confirm),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }

            }
        }
    )
}


@UnstableApi
@Composable
fun ReplaceCoverDialog(
    musicViewModel: MusicViewModel,
    onPickImage: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val isCustom = musicViewModel.customMusicCover.value !is Int

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = true,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        ),
        content = {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stringResource(R.string.replace_cover_the_rose),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Clickable image preview to select another image
                    Box(
                        modifier = Modifier
                            .size(150.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.outlineVariant,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable(onClick = onPickImage),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(musicViewModel.getCustomCoverModel())
                                .crossfade(true)
                                .size(300, 300)
                                .build(),
                            contentDescription = stringResource(R.string.cover),
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Edit icon badge in the bottom-right corner
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                                .size(28.dp)
                                .background(
                                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Edit,
                                contentDescription = "Edit cover",
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = stringResource(if (isCustom) R.string.custom_cover else R.string.default_cover),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = onPickImage,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = stringResource(R.string.select_image),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    if (isCustom) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                musicViewModel.resetCustomCover(context)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = stringResource(R.string.restore_default_cover),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = stringResource(R.string.cancel),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    )
}