package com.ztftrue.music.ui.public

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.util.UnstableApi
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.ztftrue.music.ImageSource
import com.ztftrue.music.MusicViewModel
import com.ztftrue.music.R
import com.ztftrue.music.Router
import com.ztftrue.music.sqlData.model.MusicItem

@UnstableApi
@Composable
fun Bottom(musicViewModel: MusicViewModel, navController: SnapshotStateList<Any>) {
    var currentMusic by remember { mutableStateOf<MusicItem?>(null) }
    LaunchedEffect(musicViewModel.currentPlay.value) {
        currentMusic = musicViewModel.currentPlay.value
    }
    val imageModel: ImageSource by musicViewModel.currentMusicCover
    val context = LocalContext.current
    val foreground = MaterialTheme.colorScheme.onSurface

    if (currentMusic == null) return

    Surface(
        modifier = Modifier.fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(start = 12.dp, end = 12.dp, bottom = 8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 2.dp,
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(72.dp).clickable {
                navController.remove(Router.MusicPlayerView)
                navController.add(Router.MusicPlayerView)
            }.padding(start = 8.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            key(musicViewModel.currentPlay.value) {
                AsyncImage(
                    model = ImageRequest.Builder(context).data(imageModel.asModel()).crossfade(true).size(112, 112).build(),
                    contentDescription = stringResource(R.string.album_cover),
                    modifier = Modifier.size(52.dp).aspectRatio(1f).clip(RoundedCornerShape(14.dp)),
                    contentScale = ContentScale.Crop
                )
                Column(
                    modifier = Modifier.weight(1f).padding(horizontal = 11.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = currentMusic?.name.orEmpty(),
                        color = foreground,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = currentMusic?.artist.orEmpty(),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            IconButton(onClick = { musicViewModel.browser?.seekToPreviousMediaItem() }, modifier = Modifier.size(40.dp)) {
                Image(painterResource(R.drawable.play_previous_song), "Previous", Modifier.size(21.dp), colorFilter = ColorFilter.tint(foreground))
            }
            IconButton(onClick = {
                if (musicViewModel.browser?.isPlaying == true) musicViewModel.browser?.pause() else musicViewModel.browser?.play()
            }, modifier = Modifier.size(44.dp)) {
                Image(
                    painterResource(if (musicViewModel.playStatus.value) R.drawable.pause else R.drawable.play),
                    if (musicViewModel.playStatus.value) "Pause" else "Play",
                    Modifier.size(26.dp),
                    colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.primary)
                )
            }
            IconButton(onClick = { musicViewModel.browser?.seekToNextMediaItem() }, modifier = Modifier.size(40.dp)) {
                Image(painterResource(R.drawable.play_next_song), "Next", Modifier.size(21.dp), colorFilter = ColorFilter.tint(foreground))
            }
        }
    }
}
