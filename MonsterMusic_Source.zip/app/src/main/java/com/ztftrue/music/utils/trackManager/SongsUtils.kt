package com.ztftrue.music.utils.trackManager

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.ztftrue.music.MainActivity
import com.ztftrue.music.MusicViewModel
import com.ztftrue.music.R
import com.ztftrue.music.play.manager.MediaCommands
import com.ztftrue.music.sqlData.model.MusicItem
import com.ztftrue.music.utils.SortUtils
import com.ztftrue.music.utils.model.MusicPlayList
import java.io.File
import java.io.FileOutputStream
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
object SongsUtils {
    fun sortSongs(
        list: ArrayList<MusicItem>,
        field: String?,
        order: String?
    ): ArrayList<MusicItem> {
        val comparator: Comparator<MusicItem> = when (field?.lowercase()) {
            MediaStore.Audio.Media.TITLE.lowercase() -> Comparator { a, b -> SortUtils.compareStrings(a.name, b.name) }
            MediaStore.Audio.Media.ALBUM.lowercase() -> Comparator { a, b -> SortUtils.compareStrings(a.album, b.album) }
            MediaStore.Audio.Media.ARTIST.lowercase() -> Comparator { a, b -> SortUtils.compareStrings(a.artist, b.artist) }
            MediaStore.Audio.Media.DURATION.lowercase() -> compareBy { it.duration }
            MediaStore.Audio.Media.YEAR.lowercase() -> compareBy { it.year }
            MediaStore.Audio.Media.TRACK.lowercase(), "track" -> Comparator { a, b ->
                val c = a.songNumber.compareTo(b.songNumber)
                if (c != 0) c else SortUtils.compareStrings(a.name, b.name)
            }
            else -> {
                return list
            }
        }
        val sortedList = when (order?.uppercase()) {
            "ASC" -> list.sortedWith(comparator)
            "DESC" -> list.sortedWith(comparator.reversed())
            else -> return list
        }
        return ArrayList(sortedList)
    }

    @Suppress("DEPRECATION")
    fun sortPlayList(
        list: ArrayList<MusicPlayList>,
        field: String?,
        order: String?
    ): ArrayList<MusicPlayList> {
        val comparator: Comparator<MusicPlayList> = when (field) {
            MediaStore.Audio.Playlists.NAME -> Comparator { a, b -> SortUtils.compareStrings(a.name, b.name) }
            else -> {
                return list
            }
        }
        val sortedList = when (order?.uppercase()) {
            "ASC" -> list.sortedWith(comparator)
            "DESC" -> list.sortedWith(comparator.reversed())
            else -> return list
        }
        return ArrayList(sortedList)
    }

    fun sendRequest(uri: Uri, context: MainActivity) {
        try {
            val arrayList = ArrayList<Uri>()
            arrayList.add(uri)
            val editPendingIntent =
                MediaStore.createWriteRequest(context.contentResolver, arrayList)
            val intentSenderRequest =
                IntentSenderRequest.Builder(editPendingIntent.intentSender)
                    .setFlags(
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                    .build()
            context.modifyMediaLauncher.launch(intentSenderRequest)
        } catch (e: Exception) {
            e.printStackTrace()
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(context, R.string.file_not_found_please_rescan, Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun resortOrRemoveTrackFromM3U(
        context: Context, uri: Uri, m3uPath: String,
        arrayList: ArrayList<MusicItem>,
    ) {
        val file = (File(m3uPath).parent ?: "") + "/"
        val stringBu = StringBuilder("#EXTM3U").append("\n")
        arrayList.forEach {
            val p = it.path.replace(file, "")
            stringBu.append(p).append("\n")
        }
        try {
            val pfd: ParcelFileDescriptor? = context.contentResolver.openFileDescriptor(uri, "r")
            pfd?.use {
                val pfdWT = context.contentResolver.openFileDescriptor(uri, "wt")
                pfdWT?.use { wt ->
                    FileOutputStream(wt.fileDescriptor).use { fileOutputStream ->
                        val a = stringBu.toString().toByteArray()
                        fileOutputStream.write(a)
                        fileOutputStream.flush()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("SongsUtils", "Error writing M3U file", e)
        }
    }

    fun refreshPlaylist(musicViewModel: MusicViewModel) {
        val futureResult: ListenableFuture<SessionResult>? =
            musicViewModel.browser?.sendCustomCommand(
                MediaCommands.COMMAND_PlAY_LIST_CHANGE,
                Bundle().apply {

                },
            )
        futureResult?.addListener({
            try {
                val sessionResult = futureResult.get()
                if (sessionResult.resultCode == SessionResult.RESULT_SUCCESS) {
                    musicViewModel.viewModelScope.launch(Dispatchers.Main) {
                        musicViewModel.refreshPlayList.value =
                            !musicViewModel.refreshPlayList.value
                    }
                }
            } catch (e: Exception) {
                Log.e("Client", "Failed to toggle favorite status", e)
            }
        }, MoreExecutors.directExecutor())
    }
}