package com.ztftrue.music

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.util.Log
import android.widget.Toast
import androidx.annotation.DrawableRes
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.text.style.TextAlign
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaBrowser
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.ListenableFuture
import com.ztftrue.music.play.AudioDataRepository
import com.ztftrue.music.play.CustomMetadataKeys
import com.ztftrue.music.play.MediaItemUtils
import com.ztftrue.music.play.manager.MediaCommands
import com.ztftrue.music.sqlData.MusicDatabase
import com.ztftrue.music.sqlData.model.Auxr
import com.ztftrue.music.sqlData.model.ARTIST_TYPE
import com.ztftrue.music.sqlData.model.DictionaryApp
import com.ztftrue.music.sqlData.model.FilterFolder
import com.ztftrue.music.sqlData.model.GENRE_TYPE
import com.ztftrue.music.sqlData.model.LYRICS_TYPE
import com.ztftrue.music.sqlData.model.MainTab
import com.ztftrue.music.sqlData.model.MusicItem
import com.ztftrue.music.sqlData.model.StorageFolder
import com.ztftrue.music.sqlData.model.TRACKS_TYPE
import com.ztftrue.music.ui.play.Lyrics
import com.ztftrue.music.utils.CaptionUtils
import com.ztftrue.music.utils.CaptionUtils.getLyricsTypeFromExtension
import com.ztftrue.music.utils.CaptionUtils.splitStringIntoWordsAndSymbols
import com.ztftrue.music.utils.LyricsLoadResult
import com.ztftrue.music.utils.LyricsSettings.FIRST_EMBEDDED_LYRICS
import com.ztftrue.music.utils.LyricsType
import com.ztftrue.music.utils.PlayListType
import com.ztftrue.music.utils.SharedPreferencesName.LYRICS_SETTINGS
import com.ztftrue.music.utils.SharedPreferencesUtils
import com.ztftrue.music.utils.model.FolderList
import com.ztftrue.music.utils.Utils
import com.ztftrue.music.utils.Utils.detectCharset
import com.ztftrue.music.utils.Utils.getCover
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import com.ztftrue.music.utils.model.AnyListBase
import com.ztftrue.music.utils.model.Caption
import com.ztftrue.music.utils.model.EqualizerBand
import com.ztftrue.music.utils.model.ListStringCaption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Duration.Companion.milliseconds


var SongsPlayList = AnyListBase(-1, PlayListType.Songs)
var QueuePlayList = AnyListBase(-1, PlayListType.Queue)

sealed class ImageSource {
    data class Resource(@param:DrawableRes val id: Int) : ImageSource()
    data class FilePath(val path: String) : ImageSource()
    data class BitmapFile(val bitmap: Bitmap) : ImageSource()

    fun asModel(): Any = when (this) {
        is Resource -> id
        is FilePath -> File(path)
        is BitmapFile -> bitmap
    }
}

class MusicViewModel : ViewModel() {

    var db: MusicDatabase? = null
    val refreshPlayList = mutableStateOf(false)
    val refreshAlbum = mutableStateOf(false)
    val refreshArtist = mutableStateOf(false)
    val refreshGenre = mutableStateOf(false)
    val refreshFolder = mutableStateOf(false)
    lateinit var navController: SnapshotStateList<Any>
    var themeSelected = mutableIntStateOf(0)
    var editTrackEnable = mutableStateOf(false)
    private val _visualizationData = MutableLiveData<List<Float>>()
    var loadingTracks = mutableStateOf(false)


    val folderViewTree = mutableStateOf(false)
    val folderViewShowPath = mutableStateOf(false)

    //    val albumItemsCount = mutableIntStateOf(2)
//    val genreItemsCount = mutableIntStateOf(2)
    @Volatile
    var isVisualizationActive: Boolean = false
        private set

    private val activeVisualizationTokens = mutableSetOf<String>()

    val dismissLyricsTrigger = mutableIntStateOf(0)

    var browser: MediaBrowser? = null
        set(value) {
            field = value
            if (value != null && isVisualizationActive) {
                value.sendCustomCommand(
                    MediaCommands.COMMAND_VISUALIZATION_CONNECTED,
                    Bundle()
                )
            }
        }

    fun setVisualizationActive(token: String, active: Boolean) {
        val wasActive: Boolean
        val isNowActive: Boolean
        synchronized(activeVisualizationTokens) {
            wasActive = activeVisualizationTokens.isNotEmpty()
            if (active) {
                activeVisualizationTokens.add(token)
            } else {
                activeVisualizationTokens.remove(token)
            }
            isNowActive = activeVisualizationTokens.isNotEmpty()
            isVisualizationActive = isNowActive
        }
        val b = browser
        if (b != null && b.isConnected) {
            if (active) {
                b.sendCustomCommand(MediaCommands.COMMAND_VISUALIZATION_CONNECTED, Bundle())
            } else if (wasActive && !isNowActive) {
                b.sendCustomCommand(MediaCommands.COMMAND_VISUALIZATION_DISCONNECTED, Bundle())
            }
        }
    }

    fun setVisualizationActive(active: Boolean) {
        if (!active) {
            val wasActive: Boolean
            synchronized(activeVisualizationTokens) {
                wasActive = activeVisualizationTokens.isNotEmpty()
                activeVisualizationTokens.clear()
                isVisualizationActive = false
            }
            if (wasActive) {
                val b = browser
                if (b != null && b.isConnected) {
                    b.sendCustomCommand(MediaCommands.COMMAND_VISUALIZATION_DISCONNECTED, Bundle())
                }
            }
        } else {
            setVisualizationActive("default", true)
        }
    }

    fun setVisualizationEnabled(context: Context, enabled: Boolean) {
        musicVisualizationEnable.value = enabled
        SharedPreferencesUtils.saveEnableMusicVisualization(context, enabled)
        val bundle = Bundle().apply { putBoolean(MediaCommands.KEY_ENABLE, enabled) }
        browser?.sendCustomCommand(MediaCommands.COMMAND_VISUALIZATION_ENABLE, bundle)
    }

    var currentInputFormat =
        mutableStateMapOf<String, String>()

    //    val albumScrollDirection = mutableStateOf(ScrollDirectionType.GRID_VERTICAL)
//    val artistScrollDirection = mutableStateOf(ScrollDirectionType.GRID_VERTICAL)
//    val genreScrollDirection = mutableStateOf(ScrollDirectionType.GRID_VERTICAL)
    var musicVisualizationEnable = mutableStateOf(false)
    var visualizationMode = mutableStateOf("Matrix")
    var showMusicCover = mutableStateOf(false)
    var customMusicCover = mutableStateOf<Any>(R.drawable.songs_thumbnail_cover)

    // 当前播放的列表，应该换数据结构存储，每个列表设置变量 播放状态，album和 genres 也是，艺术家跳转到 album， 然后在下一步处理
    // 每次播放仅设置当前列表的状态
    var musicQueue = mutableStateListOf<MusicItem>()

    var currentMusicCover =
        mutableStateOf<ImageSource>(ImageSource.Resource(R.drawable.songs_thumbnail_cover))
    var currentPlay = mutableStateOf<MusicItem?>(null)
    var needRefreshTheme = mutableStateOf(false)

    //    var currentPlayQueueIndex = mutableIntStateOf(-1)
    var songsList = mutableStateListOf<MusicItem>()
    var playListCurrent = mutableStateOf<AnyListBase?>(null)

    var delayTime = mutableFloatStateOf(0.5f)
    var decay = mutableFloatStateOf(1f)
    var echoFeedBack = mutableStateOf(false)
    var enableShuffleModel = mutableStateOf(false)
    var pitch = mutableFloatStateOf(1f)
    var equalizerQ = mutableFloatStateOf(Utils.Q)
    var speed = mutableFloatStateOf(1f)
    var showPitchFine = mutableStateOf(false)
    var showSpeedFine = mutableStateOf(false)

    var enableBassBoost = mutableStateOf(false)
    var bassBoostStrength = mutableIntStateOf(0)

    var virtualStrength = mutableIntStateOf(0)
    var enableVirtual = mutableStateOf(false)

    // Reverb
    var enableReverb = mutableStateOf(false)
    var reverbRoomSize = mutableFloatStateOf(0.5f)
    var reverbDamping = mutableFloatStateOf(0.5f)
    var reverbMix = mutableFloatStateOf(0.3f)

    // Chorus
    var enableChorus = mutableStateOf(false)
    var chorusRate = mutableFloatStateOf(1.5f)
    var chorusDepth = mutableFloatStateOf(0.5f)
    var chorusMix = mutableFloatStateOf(0.5f)

    // Flanger
    var enableFlanger = mutableStateOf(false)
    var flangerRate = mutableFloatStateOf(0.5f)
    var flangerDepth = mutableFloatStateOf(0.7f)
    var flangerFeedback = mutableFloatStateOf(0.5f)
    var flangerMix = mutableFloatStateOf(0.5f)

    // Polyphony
    var enablePolyphony = mutableStateOf(false)
    var polyphonySemitones = mutableIntStateOf(0)
    var polyphonyDetune = mutableFloatStateOf(0.0f)
    var polyphonyMix = mutableFloatStateOf(0.5f)

    // Delay Effect
    var enableDelay = mutableStateOf(false)
    var delayEffectTime = mutableFloatStateOf(0.35f)
    var delayEffectFeedback = mutableFloatStateOf(0.4f)
    var delayEffectMix = mutableFloatStateOf(0.4f)

    var mainTabList = mutableStateListOf<MainTab>()

    var sliderPosition = mutableFloatStateOf(0F)
    var sliderTouching = false
    var autoScroll = mutableStateOf(true)
    var autoHighLight = mutableStateOf(true)

    var dictionaryAppList = mutableStateListOf<DictionaryApp>()

    var enableEqualizer = mutableStateOf(false)
    var equalizerType = mutableIntStateOf(0)
    var selectedPreset = mutableStateOf(Utils.custom)
    var trackEffectEnabled = mutableStateOf(false)
    var effectConfigVersion = mutableIntStateOf(0)
    var enableEcho = mutableStateOf(false)
    var scanMode = mutableIntStateOf(SharedPreferencesUtils.SCAN_MODE_BLACKLIST)
    val whitelistFolders = mutableStateListOf<FilterFolder>()
    val blacklistFolders = mutableStateListOf<FilterFolder>()
    var exclusiveFolderPath = mutableStateOf<String?>(null)
    var isRefreshing = mutableStateOf(false)
    var showFirstScanSetupDialog = mutableStateOf(false)
    var videoSupportEnable = mutableStateOf(false)
    var decoderMode = mutableIntStateOf(1)
    var bitPerfectUsbEnable = mutableStateOf(false)
    var bitPerfectActive = mutableStateOf(false)
    var bitPerfectStatus = mutableStateOf("")
    var connectedDacName = mutableStateOf<String?>(null)
    var connectedDacSampleRates = mutableStateListOf<Int>()

    var playStatus = mutableStateOf(false)
    var equalizerBands = mutableStateListOf<EqualizerBand>()
    var showIndicatorMap = mutableStateMapOf<String, Boolean>()

    var artistCover = mutableStateMapOf<String, Uri>()
    var genreCover = mutableStateMapOf<String, Uri>()

    // lyrics
    var itemDuration: Long = 1
    var lyricsType: LyricsType = LyricsType.TEXT
    var currentCaptionList = mutableStateListOf<ListStringCaption>()
    var currentCaptionListLoading = mutableStateOf(false)
    var isEmbeddedLyrics = mutableStateOf(false)
    var fontSize = mutableIntStateOf(18)
    var textAlign = mutableStateOf(TextAlign.Center)

    var showSlideIndicators = mutableStateOf(false)
    var showRightIndicator = mutableStateOf(true)

    // sleep time
    var sleepTime = mutableLongStateOf(0L)
    var remainTime = mutableLongStateOf(0L)
    var playCompleted = mutableStateOf(false)
    var autoDismissDicPop = mutableStateOf(false)
    var volume = mutableIntStateOf(100)
    var repeatModel = mutableIntStateOf(Player.REPEAT_MODE_ALL)

    fun reset() {
        if (currentPlay.value != null) {
            currentCaptionList.clear()
        }
        currentMusicCover.value = ImageSource.Resource(R.drawable.songs_thumbnail_cover)
        currentPlay.value = null
        playListCurrent.value = null
        musicQueue.clear()
        songsList.clear()
        mainTabList.clear()
        sliderPosition.floatValue = 0f
        sleepTime.longValue = 0
        remainTime.longValue = 0
        playCompleted.value = false
        repeatModel.intValue = Player.REPEAT_MODE_ALL
    }

    private fun subscribeToVisualizationData() {
        viewModelScope.launch {
            var lastPostTime = 0L
            AudioDataRepository.visualizationDataFlow
                .collectLatest { fftArray ->
                    // Only allocate and post if an observer is actually listening to LiveData,
                    // and throttle to ~30 FPS to avoid flooding the Android Main Looper MessageQueue
                    if (_visualizationData.hasActiveObservers()) {
                        val now = System.currentTimeMillis()
                        if (now - lastPostTime >= 33L) {
                            lastPostTime = now
                            _visualizationData.postValue(fftArray.toList())
                        }
                    }
                }
        }
    }


    init {
        subscribeToVisualizationData()
        val band = ArrayList<EqualizerBand>()
        for ((index, element) in Utils.bandsCenter.withIndex()) {
            val hz = if (element < 1000) {
                "$element"
            } else {
                "${element / 1000}k"
            }
            band.add(EqualizerBand(index, hz, 0))
        }
        equalizerBands.addAll(band)
    }

    fun resetAudioEffectsToDefault() {
        pitch.floatValue = 1f
        speed.floatValue = 1f
        equalizerQ.floatValue = Utils.Q
        enableEqualizer.value = false
        equalizerType.intValue = 0
        selectedPreset.value = Utils.custom
        showPitchFine.value = false
        showSpeedFine.value = false
        equalizerBands.forEach { it.value = 0 }

        delayTime.floatValue = 0.2f
        decay.floatValue = 0.5f
        enableEcho.value = false
        echoFeedBack.value = false

        enableBassBoost.value = false
        bassBoostStrength.intValue = 0

        enableVirtual.value = false
        virtualStrength.intValue = 0

        enableReverb.value = false
        reverbRoomSize.floatValue = 0.5f
        reverbDamping.floatValue = 0.5f
        reverbMix.floatValue = 0.3f

        enableChorus.value = false
        chorusRate.floatValue = 1.5f
        chorusDepth.floatValue = 0.5f
        chorusMix.floatValue = 0.5f

        enableFlanger.value = false
        flangerRate.floatValue = 0.5f
        flangerDepth.floatValue = 0.7f
        flangerFeedback.floatValue = 0.5f
        flangerMix.floatValue = 0.5f

        enablePolyphony.value = false
        polyphonySemitones.intValue = 0
        polyphonyDetune.floatValue = 0.0f
        polyphonyMix.floatValue = 0.5f

        enableDelay.value = false
        delayEffectTime.floatValue = 0.35f
        delayEffectFeedback.floatValue = 0.4f
        delayEffectMix.floatValue = 0.4f

        effectConfigVersion.intValue++
    }

    fun applyAuxr(auxr: Auxr) {
        pitch.floatValue = auxr.pitch
        speed.floatValue = auxr.speed
        equalizerQ.floatValue = auxr.equalizerQ
        enableEqualizer.value = auxr.equalizer
        equalizerType.intValue = auxr.equalizerType
        selectedPreset.value = auxr.selectedPreset
        showPitchFine.value = auxr.showPitchFine
        showSpeedFine.value = auxr.showSpeedFine

        val bandLevels = auxr.equalizerBand
        equalizerBands.forEachIndexed { index, _ ->
            if (index < bandLevels.size) {
                equalizerBands[index].value = bandLevels[index]
            } else {
                equalizerBands[index].value = 0
            }
        }

        delayTime.floatValue = auxr.echoDelay
        decay.floatValue = auxr.echoDecay
        enableEcho.value = auxr.echo
        echoFeedBack.value = auxr.echoRevert

        enableBassBoost.value = auxr.bassBoostEnabled
        bassBoostStrength.intValue = auxr.bassBoostStrength

        enableVirtual.value = auxr.virtualizerEnabled
        virtualStrength.intValue = auxr.virtualizerStrength

        enableReverb.value = auxr.reverbEnabled
        reverbRoomSize.floatValue = auxr.reverbRoomSize
        reverbDamping.floatValue = auxr.reverbDamping
        reverbMix.floatValue = auxr.reverbMix

        enableChorus.value = auxr.chorusEnabled
        chorusRate.floatValue = auxr.chorusRate
        chorusDepth.floatValue = auxr.chorusDepth
        chorusMix.floatValue = auxr.chorusMix

        enableFlanger.value = auxr.flangerEnabled
        flangerRate.floatValue = auxr.flangerRate
        flangerDepth.floatValue = auxr.flangerDepth
        flangerFeedback.floatValue = auxr.flangerFeedback
        flangerMix.floatValue = auxr.flangerMix

        enablePolyphony.value = auxr.polyphonyEnabled
        polyphonySemitones.intValue = auxr.polyphonySemitones
        polyphonyDetune.floatValue = auxr.polyphonyDetune
        polyphonyMix.floatValue = auxr.polyphonyMix

        enableDelay.value = auxr.delayEnabled
        delayEffectTime.floatValue = auxr.delayTime
        delayEffectFeedback.floatValue = auxr.delayFeedback
        delayEffectMix.floatValue = auxr.delayMix

        effectConfigVersion.intValue++
    }

    fun getCurrentActiveAuxr(trackId: Long = currentPlay.value?.id ?: 0L): Auxr {
        return Auxr(
            id = trackId,
            speed = speed.floatValue,
            pitch = pitch.floatValue,
            echo = enableEcho.value,
            echoDelay = delayTime.floatValue,
            echoDecay = decay.floatValue,
            echoRevert = echoFeedBack.value,
            equalizer = enableEqualizer.value,
            equalizerQ = equalizerQ.floatValue,
            equalizerBand = equalizerBands.map { it.value }.toIntArray(),
            virtualizerEnabled = enableVirtual.value,
            virtualizerStrength = virtualStrength.intValue,
            bassBoostEnabled = enableBassBoost.value,
            bassBoostStrength = bassBoostStrength.intValue,
            equalizerType = equalizerType.intValue,
            selectedPreset = selectedPreset.value,
            showPitchFine = showPitchFine.value,
            showSpeedFine = showSpeedFine.value,
            delayEnabled = enableDelay.value,
            delayTime = delayEffectTime.floatValue,
            delayFeedback = delayEffectFeedback.floatValue,
            delayMix = delayEffectMix.floatValue,
            reverbEnabled = enableReverb.value,
            reverbRoomSize = reverbRoomSize.floatValue,
            reverbDamping = reverbDamping.floatValue,
            reverbMix = reverbMix.floatValue,
            chorusEnabled = enableChorus.value,
            chorusRate = chorusRate.floatValue,
            chorusDepth = chorusDepth.floatValue,
            chorusMix = chorusMix.floatValue,
            flangerEnabled = enableFlanger.value,
            flangerRate = flangerRate.floatValue,
            flangerDepth = flangerDepth.floatValue,
            flangerFeedback = flangerFeedback.floatValue,
            flangerMix = flangerMix.floatValue,
            polyphonyEnabled = enablePolyphony.value,
            polyphonySemitones = polyphonySemitones.intValue,
            polyphonyDetune = polyphonyDetune.floatValue,
            polyphonyMix = polyphonyMix.floatValue
        )
    }

    suspend fun getAuxrForTrack(context: Context, trackId: Long): Auxr = withContext(Dispatchers.IO) {
        if (trackEffectEnabled.value) {
            val dbInstance = getDb(context)
            val trackAux = dbInstance.AuxDao().findAuxById(trackId)
            if (trackAux != null) {
                return@withContext trackAux
            }
        }
        return@withContext getCurrentActiveAuxr(trackId)
    }

    fun applyAudioEffectBundle(resultData: Bundle) {
        if (resultData.containsKey("trackEffectEnabled")) {
            trackEffectEnabled.value = resultData.getBoolean("trackEffectEnabled", false)
        }
        val pitchVal = resultData.getFloat("pitch", 1f)
        val speedVal = resultData.getFloat("speed", 1f)
        val q = resultData.getFloat("Q", Utils.Q)
        equalizerQ.floatValue = q
        pitch.floatValue = pitchVal
        speed.floatValue = speedVal
        enableEqualizer.value = resultData.getBoolean("equalizerEnable")
        equalizerType.intValue = resultData.getInt("equalizerType", 0)
        selectedPreset.value = resultData.getString("selectedPreset", Utils.custom)
        showPitchFine.value = resultData.getBoolean("showPitchFine", false)
        showSpeedFine.value = resultData.getBoolean("showSpeedFine", false)
        val equalizerValue = resultData.getIntArray("equalizerValue") ?: intArrayOf(
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0
        )
        equalizerBands.forEachIndexed { index1, _ ->
            if (index1 < equalizerValue.size) {
                equalizerBands[index1].value = equalizerValue[index1]
            }
        }
        delayTime.floatValue = resultData.getFloat("delayTime")
        decay.floatValue = resultData.getFloat("decay")
        enableEcho.value = resultData.getBoolean("echoActive")
        bassBoostStrength.intValue = resultData.getInt("bassBoostStrength", 0)
        enableBassBoost.value = resultData.getBoolean("enableBassBoost", false)
        virtualStrength.intValue = resultData.getInt("virtualStrength")
        enableVirtual.value = resultData.getBoolean("enableVirtual")
        echoFeedBack.value = resultData.getBoolean("echoFeedBack")

        enableReverb.value = resultData.getBoolean("enableReverb", false)
        reverbRoomSize.floatValue = resultData.getFloat("reverbRoomSize", 0.5f)
        reverbDamping.floatValue = resultData.getFloat("reverbDamping", 0.5f)
        reverbMix.floatValue = resultData.getFloat("reverbMix", 0.3f)

        enableChorus.value = resultData.getBoolean("enableChorus", false)
        chorusRate.floatValue = resultData.getFloat("chorusRate", 1.5f)
        chorusDepth.floatValue = resultData.getFloat("chorusDepth", 0.5f)
        chorusMix.floatValue = resultData.getFloat("chorusMix", 0.5f)

        enableFlanger.value = resultData.getBoolean("enableFlanger", false)
        flangerRate.floatValue = resultData.getFloat("flangerRate", 0.5f)
        flangerDepth.floatValue = resultData.getFloat("flangerDepth", 0.7f)
        flangerFeedback.floatValue = resultData.getFloat("flangerFeedback", 0.5f)
        flangerMix.floatValue = resultData.getFloat("flangerMix", 0.5f)

        enablePolyphony.value = resultData.getBoolean("enablePolyphony", false)
        polyphonySemitones.intValue = resultData.getInt("polyphonySemitones", 0)
        polyphonyDetune.floatValue = resultData.getFloat("polyphonyDetune", 0.0f)
        polyphonyMix.floatValue = resultData.getFloat("polyphonyMix", 0.5f)

        enableDelay.value = resultData.getBoolean("enableDelay", false)
        delayEffectTime.floatValue = resultData.getFloat("delayEffectTime", 0.35f)
        delayEffectFeedback.floatValue = resultData.getFloat("delayEffectFeedback", 0.4f)
        delayEffectMix.floatValue = resultData.getFloat("delayEffectMix", 0.4f)

        effectConfigVersion.intValue++
    }

    fun setTrackEffectEnabled(context: Context, enabled: Boolean) {
        trackEffectEnabled.value = enabled
        val bundle = Bundle().apply {
            putBoolean(MediaCommands.KEY_ENABLE, enabled)
        }
        browser?.sendCustomCommand(
            MediaCommands.COMMAND_SET_TRACK_EFFECT_ENABLE,
            bundle
        )
    }

    fun getDb(context: Context): MusicDatabase {
        if (db == null) {
            db = MusicDatabase.getDatabase(context)
        }
        return db!!
    }

    val tags = mutableStateMapOf<String, String>()
    private var lyricsJob: Job? = null
    private var dealCurrentPlayJob: Job? = null

    fun scheduleDealCurrentPlay(context: Context, index: Int, mediaItem: MediaItem?, reason: Int) {
        currentCaptionListLoading.value = true
        dealCurrentPlayJob?.cancel()
        dealCurrentPlayJob = viewModelScope.launch {
            // when reason is Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED
            // sometimes index is 0 but this is not the real index, because User click the item is not 0
            if (index == 0 && reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) {
                delay(100.milliseconds)
            }
            sliderPosition.floatValue = 0f
            currentCaptionList.clear()
            if (mediaItem != null) {
                val music = MediaItemUtils.mediaItemToMusicItem(mediaItem)
                currentPlay.value = music
                if (music != null) {
                    dealLyrics(context, music)
                    getCurrentMusicCover(context)
                }
            }
        }
    }

    fun getDocumentFileFromPath(
        context: Context,
        treeUri: Uri,
        relativePath: String
    ): DocumentFile? {
        val treeDocumentId = DocumentsContract.getTreeDocumentId(treeUri)
        val targetDocumentId = "$treeDocumentId/$relativePath"
        val targetFileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, targetDocumentId)
        return DocumentFile.fromSingleUri(context, targetFileUri)
    }

    fun matchedExtension(fileName: String, musicName: String, ext: String): String? {
        val lowerName = fileName.lowercase()
        val lowerMusic = musicName.lowercase()
        val lowerExt = ext.lowercase()

        // 必须以扩展名结尾
        if (!lowerName.endsWith(lowerExt)) return null

        val baseName = lowerName.removeSuffix(lowerExt)

        // 完全匹配
        if (baseName == lowerMusic) return lowerExt

        // 带语言标记
        val regex = Regex("^${Regex.escape(lowerMusic)}\\.[a-z0-9]{2,8}(-[a-z0-9]{2,8})?$")
        return if (regex.matches(baseName)) lowerExt else null
    }

    fun loadLyrics(
        context: Context,
        storageFolder: StorageFolder,
        musicName: String,
        fileLyrics: MutableList<ListStringCaption>
    ): Boolean {
        val treeUri = storageFolder.uri.toUri()

        try {
            context.contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
            e.printStackTrace()
            if (e is SecurityException) {
                storageFolder.id?.let { getDb(context).StorageFolderDao().deleteById(it) }
            }
        }

        // 这里假设 pickedDir 是 musicName 所在的目录
        // 我们直接构造出可能的歌词文件名并尝试匹配
        val extensions = listOf(".lrc", ".srt", ".vtt", ".txt")
        for (ext in extensions) {
            val relativePath = "$musicName$ext"
            val targetFile = getDocumentFileFromPath(context, treeUri, relativePath)
            if (targetFile != null && targetFile.isFile && targetFile.canRead()) {
                val type = getLyricsTypeFromExtension(ext)
                fileLyrics.addAll(
                    fileRead(targetFile.uri, context, type)
                )
                return true
            }
        }
        // for vtt any language
        val pickedDir = DocumentFile.fromTreeUri(context, treeUri)
        pickedDir?.listFiles()?.forEach { file ->
            if (!file.isFile || !file.canRead()) return@forEach
            val name = file.name ?: return@forEach
            val match = matchedExtension(name, musicName, ".vtt")
            if (match != null) {
                fileLyrics.addAll(fileRead(file.uri, context, LyricsType.VTT))
                return true
            }
        }
        return false
    }


    fun dealLyrics(
        context: Context,
        currentPlay: MusicItem
    ) {
        // ---------------------------------------------------------
        // 取消上一首歌曲的歌词任务
        // ---------------------------------------------------------
        lyricsJob?.cancel()

        /*
         * 保存当前歌曲路径。
         *
         * 除了 Job cancellation 之外，
         * 再增加一层歌曲身份检查。
         *
         * 因为 detectCharset / readCaptions /
         * getEmbeddedLyrics 等可能包含普通阻塞 IO，
         * cancel() 不一定能够让它们立即停止。
         */
        val requestMusicPath = currentPlay.path

        val newJob = viewModelScope.launch {

            currentCaptionListLoading.value = true

            // 切歌以后立即清除上一首歌词
            currentCaptionList.clear()

            try {

                // =================================================
                // 真正的文件读取全部放到 IO 线程
                // =================================================

                val result = withContext(Dispatchers.IO) {
                    loadLyricsData(
                        context = context,
                        currentPlay = currentPlay
                    )
                }

                // 如果协程已经取消，这里直接停止
                currentCoroutineContext().ensureActive()


                // =================================================
                // 再次检查这是不是当前最新歌词任务
                // =================================================

                if (lyricsJob !== coroutineContext[Job]) {
                    return@launch
                }

                /*
                 * 这里可以继续使用 path 作为额外保护。
                 *
                 * 当前任务创建时对应的就是 requestMusicPath。
                 */
                if (currentPlay.path != requestMusicPath) {
                    return@launch
                }


                // =================================================
                // 回到 Main 后统一修改 UI / Compose State
                // =================================================

                currentCaptionList.clear()
                currentCaptionList.addAll(result.lyrics)

                tags.clear()
                tags.putAll(result.tags)

                lyricsType = result.lyricsType

                isEmbeddedLyrics.value =
                    result.isEmbedded


                // =================================================
                // 每行歌词持续时间
                // =================================================

                itemDuration =
                    currentPlay.duration /
                            currentCaptionList
                                .size
                                .coerceAtLeast(1)

            } catch (e: CancellationException) {

                // 协程取消不能吞掉
                throw e

            } catch (e: Exception) {

                e.printStackTrace()

                /*
                 * 只有当前任务发生错误，
                 * 才允许清除当前 UI。
                 *
                 * 避免已经过期的任务影响新任务。
                 */
                if (lyricsJob === coroutineContext[Job]) {

                    currentCaptionList.clear()

                    tags.clear()

                    isEmbeddedLyrics.value = false

                    lyricsType = LyricsType.TEXT
                }

            } finally {

                /*
                 * 非常重要：
                 *
                 * 只有最新任务才能关闭 loading。
                 *
                 * 否则：
                 *
                 * A 开始
                 * B 开始并取消 A
                 * A finally
                 * A 把 loading=false
                 *
                 * 此时 B 明明还在加载。
                 */
                if (lyricsJob === coroutineContext[Job]) {
                    currentCaptionListLoading.value = false
                }
            }
        }

        lyricsJob = newJob
    }


    /**
     * 在 Dispatchers.IO 中执行真正的歌词读取。
     *
     * 这里尽可能只操作局部变量。
     *
     * 不直接修改：
     *
     * currentCaptionList
     * tags
     * lyricsType
     * isEmbeddedLyrics
     * currentCaptionListLoading
     */
    private suspend fun loadLyricsData(
        context: Context,
        currentPlay: MusicItem
    ): LyricsLoadResult {

        // =========================================================
        // 文件名非法字符处理
        // =========================================================

        val regexPattern =
            Regex("[<>\"/~'{}?,+=)(^&*%!@#$]")


        // =========================================================
        // App 自己的歌词目录
        // Lyrics/歌手/歌曲
        // =========================================================

        val artistsFolder =
            currentPlay.artist.replace(
                regexPattern,
                "_"
            )

        val folderPath =
            "$Lyrics/$artistsFolder"

        val folder =
            context.getExternalFilesDir(
                folderPath
            )

        folder?.mkdirs()

        val lyricsId =
            currentPlay.name.replace(
                regexPattern,
                "_"
            )

        val internalLyricsPath =
            folder?.let {
                File(
                    it,
                    lyricsId
                ).absolutePath
            }


        // =========================================================
        // 是否优先读取内嵌歌词
        // =========================================================

        val firstEmbeddedLyrics =
            context
                .getSharedPreferences(
                    LYRICS_SETTINGS,
                    Context.MODE_PRIVATE
                )
                .getBoolean(
                    FIRST_EMBEDDED_LYRICS,
                    false
                )


        // =========================================================
        // 所有临时状态均为局部变量
        // =========================================================

        val embeddedLyrics =
            ArrayList<ListStringCaption>()

        val fileLyrics =
            ArrayList<ListStringCaption>()

        /*
         * 后台线程不要直接操作：
         *
         * mutableStateMapOf<String, String>()
         *
         * 使用普通 MutableMap。
         */
        val localTags =
            mutableMapOf<String, String>()


        var resultLyricsType =
            LyricsType.TEXT


        // =========================================================
        // 第一阶段：
        //
        // 如果设置成 Embedded Lyrics 优先，
        // 首先读取音乐文件中的内嵌歌词。
        // =========================================================

        if (firstEmbeddedLyrics) {

            currentCoroutineContext()
                .ensureActive()

            try {

                embeddedLyrics.addAll(
                    CaptionUtils.getEmbeddedLyrics(
                        currentPlay.path,
                        context,
                        localTags
                    )
                )

            } catch (e: CancellationException) {

                throw e

            } catch (e: Exception) {

                e.printStackTrace()
            }
        }


        // =========================================================
        // 如果 Embedded Lyrics 已经找到，
        // 就不继续寻找外部歌词。
        // =========================================================

        if (embeddedLyrics.isNotEmpty()) {

            resultLyricsType =
                LyricsType.TEXT

        } else {

            // =====================================================
            // 第二阶段：
            //
            // 查找 App 自己保存的歌词文件
            // =====================================================

            currentCoroutineContext()
                .ensureActive()

            if (internalLyricsPath != null) {

                val fileInternal =
                    try {

                        Utils.checkLyrics(
                            internalLyricsPath
                        )

                    } catch (e: Exception) {

                        e.printStackTrace()
                        null
                    }


                if (fileInternal != null) {

                    resultLyricsType =
                        fileInternal.type

                    val file =
                        File(fileInternal.path)

                    try {

                        // -----------------------------------------
                        // 检测编码
                        // -----------------------------------------

                        val charset =
                            file.inputStream().use { input ->

                                detectCharset(
                                    input
                                )
                            }


                        currentCoroutineContext()
                            .ensureActive()


                        // -----------------------------------------
                        // 读取歌词
                        // -----------------------------------------

                        file
                            .bufferedReader(charset)
                            .use { reader ->

                                fileLyrics.addAll(
                                    readCaptions(
                                        reader,
                                        fileInternal.type,
                                        context
                                    )
                                )
                            }


                        /*
                         * 如果这是你需要保存的歌词实际路径，
                         * 就记录到 tags。
                         */
                        localTags["lyricsPath"] =
                            fileInternal.path

                    } catch (e: CancellationException) {

                        throw e

                    } catch (e: Exception) {

                        e.printStackTrace()
                    }
                }
            }


            // =====================================================
            // 第三阶段：
            //
            // 查找歌曲同目录歌词：
            //
            // abc.mp3
            // abc.lrc
            //
            // 不再使用 substring + lastIndexOf(".")
            // =====================================================

            if (fileLyrics.isEmpty()) {

                currentCoroutineContext()
                    .ensureActive()


                val musicFile =
                    File(currentPlay.path)

                val parentFolder =
                    musicFile.parentFile


                if (parentFolder != null) {

                    val musicPathWithoutExtension =
                        File(
                            parentFolder,
                            musicFile.nameWithoutExtension
                        ).absolutePath


                    val fileR =
                        try {

                            Utils.checkLyrics(
                                musicPathWithoutExtension
                            )

                        } catch (e: Exception) {

                            e.printStackTrace()
                            null
                        }


                    if (fileR != null) {

                        resultLyricsType =
                            fileR.type

                        val file =
                            File(fileR.path)


                        try {

                            val charset =
                                file
                                    .inputStream()
                                    .use { input ->

                                        detectCharset(
                                            input
                                        )
                                    }


                            currentCoroutineContext()
                                .ensureActive()


                            file
                                .bufferedReader(charset)
                                .use { reader ->

                                    fileLyrics.addAll(
                                        readCaptions(
                                            reader,
                                            fileR.type,
                                            context
                                        )
                                    )
                                }


                            localTags["lyricsPath"] =
                                fileR.path

                        } catch (e: CancellationException) {

                            throw e

                        } catch (e: Exception) {

                            e.printStackTrace()
                        }
                    }
                }
            }


            // =====================================================
            // 第四阶段：
            //
            // 查找用户配置的歌词目录
            // =====================================================

            if (fileLyrics.isEmpty()) {

                currentCoroutineContext()
                    .ensureActive()


                val musicName =
                    File(
                        currentPlay.path
                    ).nameWithoutExtension


                val storageFolders =
                    try {

                        getDb(context)
                            .StorageFolderDao()
                            .findAllByType(
                                LYRICS_TYPE
                            )

                    } catch (e: Exception) {

                        e.printStackTrace()

                        emptyList()
                    }


                for (storageFolder in storageFolders) {

                    currentCoroutineContext()
                        .ensureActive()

                    try {

                        val loaded =
                            loadLyrics(
                                context,
                                storageFolder,
                                musicName,
                                fileLyrics
                            )


                        if (loaded) {

                            /*
                             * 这里没有直接得到实际歌词文件 path，
                             * 因此暂时不写 lyricsPath。
                             *
                             * 如果你的 loadLyrics() 能返回路径，
                             * 后面可以进一步优化。
                             */

                            break
                        }

                    } catch (e: CancellationException) {

                        throw e

                    } catch (e: Exception) {

                        e.printStackTrace()


                        // -----------------------------------------
                        // 原来的逻辑：
                        //
                        // 读取失效目录后删除数据库记录
                        // -----------------------------------------

                        try {

                            storageFolder.id?.let { id ->

                                getDb(context)
                                    .StorageFolderDao()
                                    .deleteById(id)
                            }

                        } catch (dbException: Exception) {

                            dbException.printStackTrace()
                        }


                        // Toast 必须在 Main
                        withContext(Dispatchers.Main) {

                            Toast.makeText(
                                context,
                                "There has error, can't read some lyrics. " +
                                        "Most of times, this occur after you reinstall app.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            }
        }


        // =========================================================
        // 第五阶段：
        //
        // 如果：
        //
        // 1. 没找到文件歌词
        // 2. Embedded Lyrics 不是第一优先级
        //
        // 最后尝试 Embedded Lyrics
        // =========================================================

        if (
            fileLyrics.isEmpty() &&
            !firstEmbeddedLyrics
        ) {

            currentCoroutineContext()
                .ensureActive()

            try {

                embeddedLyrics.addAll(
                    CaptionUtils.getEmbeddedLyrics(
                        currentPlay.path,
                        context,
                        localTags
                    )
                )

            } catch (e: CancellationException) {

                throw e

            } catch (e: Exception) {

                e.printStackTrace()
            }
        }


        // =========================================================
        // 确定最终歌词
        // =========================================================

        val finalLyrics: List<ListStringCaption>

        val isEmbedded: Boolean


        if (fileLyrics.isNotEmpty()) {

            // 文件歌词
            finalLyrics =
                fileLyrics

            isEmbedded =
                false

        } else if (embeddedLyrics.isNotEmpty()) {

            // 内嵌歌词
            finalLyrics =
                embeddedLyrics

            isEmbedded =
                true

            resultLyricsType =
                LyricsType.TEXT

        } else {

            // 完全没有歌词
            finalLyrics =
                emptyList()

            isEmbedded =
                false
        }


        if (!localTags.containsKey("bitsPerSample")) {
            CaptionUtils.readAudioTagsAndHeader(currentPlay.path, localTags)
        }

        // =========================================================
        // 基本歌曲信息
        //
        // 如果 Embedded Lyrics 自己已经解析出了：
        //
        // artist
        // title
        //
        // putIfAbsent 不会覆盖它们。
        // =========================================================

        localTags.putIfAbsent(
            "artist",
            currentPlay.artist
        )

        localTags.putIfAbsent(
            "title",
            currentPlay.name
        )

        localTags.putIfAbsent(
            "musicPath",
            currentPlay.path
        )


        currentCoroutineContext()
            .ensureActive()


        // =========================================================
        // 返回结果
        // =========================================================

        return LyricsLoadResult(
            lyrics = finalLyrics,
            lyricsType = resultLyricsType,
            isEmbedded = isEmbedded,
            tags = localTags
        )
    }


    private fun fileRead(
        uri: Uri,
        context: Context,
        captionType: LyricsType
    ): ArrayList<ListStringCaption> {
        lyricsType = captionType
        val inputStream =
            context.contentResolver.openInputStream(uri)
        val charset = detectCharset(inputStream)
        val i = InputStreamReader(inputStream, charset)
        val reader =
            BufferedReader(i)
        val r = readCaptions(reader, lyricsType, context)
        reader.close()
        i.close()
        inputStream?.close()
        return r
    }

    private fun readCaptions(
        bufferedReader: BufferedReader,
        captionType: LyricsType,
        context: Context
    ): ArrayList<ListStringCaption> {
        val captions = arrayListOf<Caption>()
        when (captionType) {
            LyricsType.SRT -> {
                captions.addAll(CaptionUtils.parseSrtFile(bufferedReader))
            }

            LyricsType.VTT -> {
                captions.addAll(CaptionUtils.parseVttFile(bufferedReader))
            }

            LyricsType.LRC -> {
                captions.addAll(CaptionUtils.parseLrcFile(bufferedReader, context))
            }

            LyricsType.TEXT -> {
                captions.addAll(CaptionUtils.parseTextFile(bufferedReader, context))
            }
        }
        val arrayList = arrayListOf<ListStringCaption>()
        captions.forEach {
            val an = ListStringCaption(
                text = splitStringIntoWordsAndSymbols(it.text), //ArrayList(it.text.split(Regex("[\\n\\r\\s]+"))),
                timeStart = it.timeStart,
                timeEnd = it.timeEnd
            )
            arrayList.add(an)
        }
        bufferedReader.close()
        return arrayList
    }


    fun getCurrentMusicCover(context: Context): ImageSource {
        val v = currentPlay.value
        if (v != null) {
            currentMusicCover.value = getCover(this@MusicViewModel, context, v.id, v.path)
        }
        if (themeSelected.intValue == 3) {
            needRefreshTheme.value = !needRefreshTheme.value
        }
        return currentMusicCover.value
    }

    fun getCustomCoverModel(): Any {
        return when (val c = customMusicCover.value) {
            is String -> File(c)
            else -> c
        }
    }

    suspend fun getVideoCover(context: Context, id: Long, path: String): Any {
        val cacheFile = Utils.getVideoCoverCacheFile(context, path)
        if (cacheFile.exists() && cacheFile.length() > 0) {
            return cacheFile
        }
        val bitmap = withContext(Dispatchers.IO) {
            Utils.extractVideoFrame(context, id, path)
        }
        if (bitmap != null && cacheFile.exists() && cacheFile.length() > 0) {
            return cacheFile
        }
        return getCustomCoverModel()
    }

    fun setCustomCover(context: Context, uri: Uri) {
        val appContext = context.applicationContext
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val mimeType = try {
                    context.contentResolver.getType(uri)
                } catch (_: Exception) {
                    try {
                        appContext.contentResolver.getType(uri)
                    } catch (_: Exception) {
                        null
                    }
                }
                val fileExtension = when (mimeType?.lowercase()) {
                    "image/png" -> "png"
                    "image/webp" -> "webp"
                    "image/gif" -> "gif"
                    "image/jpeg", "image/jpg" -> "jpg"
                    "image/svg+xml" -> "svg"
                    "image/bmp" -> "bmp"
                    else -> {
                        val fileName = try {
                            Utils.getFileNameFromUri(context, uri)
                        } catch (_: Exception) {
                            null
                        } ?: "cover.jpg"
                        if (fileName.contains('.')) {
                            fileName.substringAfterLast('.').lowercase()
                        } else {
                            "jpg"
                        }
                    }
                }
                val folder = context.getExternalFilesDir("cover")
                    ?: appContext.getExternalFilesDir("cover")
                    ?: File(context.filesDir, "cover")
                if (!folder.exists()) {
                    folder.mkdirs()
                }

                // Delete old track covers
                listOfNotNull(
                    context.getExternalFilesDir("cover"),
                    File(context.filesDir, "cover")
                ).forEach { f ->
                    f.listFiles()?.forEach { file ->
                        if (file.isFile && file.name.startsWith("track_cover")) {
                            file.delete()
                        }
                    }
                }

                val targetFile = File(folder, "track_cover_${System.currentTimeMillis()}.$fileExtension")
                val inputStream = try {
                    context.contentResolver.openInputStream(uri)
                } catch (e: Exception) {
                    Log.w("MusicViewModel", "context.contentResolver failed for $uri, trying appContext", e)
                    appContext.contentResolver.openInputStream(uri)
                } ?: throw IllegalStateException("Cannot open input stream for $uri")

                inputStream.use { input ->
                    FileOutputStream(targetFile).use { output ->
                        input.copyTo(output)
                    }
                }

                if (!targetFile.exists() || targetFile.length() <= 0L) {
                    throw IllegalStateException("Failed to write cover image file")
                }

                withContext(Dispatchers.Main) {
                    customMusicCover.value = targetFile.absolutePath
                    SharedPreferencesUtils.setTrackCoverData(appContext, targetFile.absolutePath)
                    getCurrentMusicCover(appContext)
                    if (Utils.hasAppWidget(appContext, PlayMusicWidget::class.java)) {
                        val appWidgetManager = AppWidgetManager.getInstance(appContext)
                        val ids = appWidgetManager.getAppWidgetIds(
                            ComponentName(appContext, PlayMusicWidget::class.java)
                        )
                        for (id in ids) {
                            PlayMusicWidget.updateAppWidget(appContext, appWidgetManager, id)
                        }
                    }
                    Toast.makeText(appContext, R.string.save, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("MusicViewModel", "Failed to set custom cover", e)
                withContext(Dispatchers.Main) {
                    Toast.makeText(appContext, "Failed: ${e.message ?: "Unknown error"}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun resetCustomCover(context: Context) {
        val appContext = context.applicationContext
        viewModelScope.launch(Dispatchers.IO) {
            try {
                listOfNotNull(
                    context.getExternalFilesDir("cover"),
                    File(context.filesDir, "cover")
                ).forEach { f ->
                    f.listFiles()?.forEach { file ->
                        if (file.isFile && file.name.startsWith("track_cover")) {
                            file.delete()
                        }
                    }
                }
                withContext(Dispatchers.Main) {
                    customMusicCover.value = R.drawable.songs_thumbnail_cover
                    SharedPreferencesUtils.setTrackCoverData(appContext, "")
                    getCurrentMusicCover(appContext)
                    if (Utils.hasAppWidget(appContext, PlayMusicWidget::class.java)) {
                        val appWidgetManager = AppWidgetManager.getInstance(appContext)
                        val ids = appWidgetManager.getAppWidgetIds(
                            ComponentName(appContext, PlayMusicWidget::class.java)
                        )
                        for (id in ids) {
                            PlayMusicWidget.updateAppWidget(appContext, appWidgetManager, id)
                        }
                    }
                    Toast.makeText(appContext, R.string.default_cover_restored, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("MusicViewModel", "Failed to reset custom cover", e)
            }
        }
    }

    suspend fun getAlbumCover(id: Long, context: Context): Any {
        return withContext(Dispatchers.IO) {
            try {
                val folder = File(context.externalCacheDir, "album_cover")
                // 优化：只有当文件夹不存在时才调用 mkdirs
                if (!folder.exists()) {
                    folder.mkdirs()
                }
                val coverPath = File(folder, "$id.jpg")
                if (coverPath.exists()) {
                    Log.d("AlbumCover", "Loaded from cache: ${coverPath.path}")
                    return@withContext coverPath.path
                }
                try {
                    val albumUri = ContentUris.withAppendedId(
                        "content://media/external/audio/albumart".toUri(),
                        id
                    )
                    context.contentResolver.openInputStream(albumUri)?.use { s ->
                        Files.copy(s, coverPath.toPath(), StandardCopyOption.REPLACE_EXISTING)
                        Log.d("AlbumCover", "Loaded from MediaStore: ${coverPath.path}")
                        return@withContext coverPath.path
                    }
                } catch (e: Exception) {
                    Log.e(
                        "AlbumCover",
                        "Error getting album art from MediaStore for ID $id: ${e.message}",
                        e
                    )
                }
                val defaultCoverResId = customMusicCover.value
                if (defaultCoverResId is Int) {
//                    val bm = BitmapFactory.decodeResource(context.resources, defaultCoverResId)
//                    FileOutputStream(coverPath).use { outStream ->
//                        bm.compress(Bitmap.CompressFormat.JPEG, 100, outStream)
//                    }
//                    bm.recycle()
                    return@withContext defaultCoverResId
                } else if (defaultCoverResId is String) {
                    val sourceFile = File(defaultCoverResId)
                    if (sourceFile.exists()) {
//                        sourceFile.copyTo(coverPath, true)
                        return@withContext defaultCoverResId
                    }
//                    Files.copy(sourceFile.toPath(), coverPath.toPath(), StandardCopyOption.REPLACE_EXISTING)
                }
                return@withContext R.drawable.songs_thumbnail_cover
            } catch (e: Exception) {
                Log.e("AlbumCover", "Unexpected error in getAlbumCover for ID $id: ${e.message}", e)
                return@withContext R.drawable.songs_thumbnail_cover // 替换为你的默认封面资源
            }
        }
    }

    fun prepareArtistAndGenreCover(context: Context) {
        if (genreCover.isEmpty()) {
            viewModelScope.launch(Dispatchers.IO) {
                val files = getDb(context).StorageFolderDao().findAllByType(GENRE_TYPE)
                outer@ for ((_, uri) in files) {
                    try {
                        val treeUri = uri.toUri()
                        context.contentResolver.takePersistableUriPermission(
                            treeUri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        )
                        val pickedDir = DocumentFile.fromTreeUri(context, treeUri)
                        val d = pickedDir?.listFiles()
                        if (d != null) {
                            for (it in d) {
                                if (it != null && it.isFile && it.canRead() && it.name != null
                                    && (it.name?.endsWith(".jpg") == true
                                            || it.name?.endsWith(".jpeg") == true
                                            || it.name?.endsWith(".png") == true)
                                ) {

                                    genreCover[it.name!!.lowercase().replace(".jpg", "")
                                        .replace(".jpeg", "")
                                        .replace(".png", "")
                                        .trimIndent().trimEnd()] = it.uri
                                }
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

        if (artistCover.isEmpty()) {
            viewModelScope.launch(Dispatchers.IO) {
                val files = getDb(context).StorageFolderDao().findAllByType(ARTIST_TYPE)
                outer@ for ((_, uri) in files) {
                    try {
                        val treeUri = uri.toUri()
                        context.contentResolver.takePersistableUriPermission(
                            treeUri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        )
                        val pickedDir = DocumentFile.fromTreeUri(context, treeUri)
                        val d = pickedDir?.listFiles()
                        if (d != null) {
                            for (it in d) {
                                if (it != null && it.isFile && it.canRead() && it.name != null
                                    && (it.name?.endsWith(".jpg") == true
                                            || it.name?.endsWith(".jpeg") == true
                                            || it.name?.endsWith(".png") == true)
                                ) {
                                    artistCover[it.name!!.lowercase().replace(".jpg", "")
                                        .replace(".jpeg", "")
                                        .replace(".png", "")
                                        .trimIndent().trimEnd()] = it.uri
                                }
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    fun scanAndRefreshPlaylist(context: Context, playListPath: String) {
        viewModelScope.launch {
            MediaScannerConnection.scanFile(
                context,
                arrayOf(playListPath),
                arrayOf("*/*"),
                object : MediaScannerConnection.MediaScannerConnectionClient {
                    override fun onMediaScannerConnected() {}
                    override fun onScanCompleted(path: String, uri: Uri) {
                        viewModelScope.launch(Dispatchers.Main) {
                            val futureResult: ListenableFuture<SessionResult>? =
                                browser?.sendCustomCommand(
                                    MediaCommands.COMMAND_PlAY_LIST_CHANGE,
                                    Bundle().apply {
                                        putString(
                                            CustomMetadataKeys.KEY_PATH,
                                            playListPath
                                        )
                                    },
                                )
                            futureResult?.addListener({
                                try {
                                    val sessionResult = futureResult.get()
                                    if (sessionResult.resultCode == SessionResult.RESULT_SUCCESS) {
                                        refreshPlayList.value =
                                            !refreshPlayList.value
                                    }
                                } catch (e: Exception) {
                                    Log.e("Client", "Failed to toggle favorite status", e)
                                }
                            }, ContextCompat.getMainExecutor(context))
                        }

                    }
                })
        }

    }


    fun isMusicFile(fileName: String?): Boolean {
        if (fileName == null) return false
        val extensions = listOf("mp3", "flac", "m4a", "wav", "ogg", "aac")
        if (extensions.any { fileName.endsWith(it, ignoreCase = true) }) return true
        if (videoSupportEnable.value && Utils.isVideoPath(fileName)) return true
        return false
    }

    fun getPathFromTreeUri(context: Context, uri: Uri): String? {
        return resolvePhysicalPath(context, uri)
    }

    fun resolvePhysicalPath(context: Context, uri: Uri): String? {
        val docId = when {
            DocumentsContract.isTreeUri(uri) -> {
                DocumentsContract.getTreeDocumentId(uri)
            }

            DocumentsContract.isDocumentUri(context, uri) -> {
                DocumentsContract.getDocumentId(uri)
            }

            else -> {
                uri.path
            }
        } ?: return null

        val split = docId.split(":")
        val type = split[0]
        val relativePath = if (split.size > 1) split[1] else ""
        if ("primary".equals(type, ignoreCase = true)) {
            return if (relativePath.isNotEmpty()) {
                "${Environment.getExternalStorageDirectory()}/$relativePath"
            } else {
                Environment.getExternalStorageDirectory().absolutePath
            }
        } else {
            // 处理 SD 卡路径
            val storageManager =
                context.getSystemService(Context.STORAGE_SERVICE) as android.os.storage.StorageManager
            val volumes = storageManager.storageVolumes
            for (volume in volumes) {
                val uuid = volume.uuid
                if (uuid != null && uuid.equals(type, ignoreCase = true)) {
                    return if (relativePath.isNotEmpty()) {
                        "/storage/$uuid/$relativePath"
                    } else {
                        "/storage/$uuid"
                    }
                }
            }
            return if (relativePath.isNotEmpty()) "/storage/$type/$relativePath" else "/storage/$type"
        }
    }

    fun setScanMode(context: Context, mode: Int) {
        scanMode.intValue = mode
        SharedPreferencesUtils.setScanMode(context, mode)
        refreshAllTracks(context)
    }

    fun addWhitelistFolder(context: Context, folder: FilterFolder) {
        if (SharedPreferencesUtils.addWhitelistFolder(context, folder)) {
            if (!whitelistFolders.any { it.id == folder.id }) {
                whitelistFolders.add(folder)
            }
            exclusiveFolderPath.value = folder.path
            refreshAllTracks(context)
        }
    }

    fun removeWhitelistFolder(context: Context, folderId: String) {
        SharedPreferencesUtils.removeWhitelistFolder(context, folderId)
        whitelistFolders.removeAll { it.id == folderId }
        exclusiveFolderPath.value = whitelistFolders.firstOrNull()?.path
        refreshAllTracks(context)
    }

    fun addBlacklistFolder(context: Context, folder: FilterFolder) {
        if (SharedPreferencesUtils.addBlacklistFolder(context, folder)) {
            if (!blacklistFolders.any { it.id == folder.id || (folder.bucketId != null && it.bucketId == folder.bucketId) }) {
                blacklistFolders.add(folder)
            }
            refreshAllTracks(context)
        }
    }

    fun ignoreFolder(context: Context, folderList: FolderList) {
        val folder = FilterFolder(
            path = folderList.path,
            name = folderList.name.ifBlank { folderList.path.substringAfterLast('/') },
            bucketId = folderList.id
        )
        if (SharedPreferencesUtils.addBlacklistFolder(context, folder)) {
            if (!blacklistFolders.any { it.id == folder.id || (folder.bucketId != null && it.bucketId == folder.bucketId) }) {
                blacklistFolders.add(folder)
            }
            refreshAllTracks(context)
            Toast.makeText(
                context,
                context.getString(R.string.folder_added_to_blacklist, folder.name),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            Toast.makeText(
                context,
                context.getString(R.string.folder_already_added),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun removeBlacklistFolder(context: Context, folderId: String) {
        val target = blacklistFolders.firstOrNull { it.id == folderId }
        SharedPreferencesUtils.removeBlacklistFolder(context, folderId)
        if (target?.bucketId != null) {
            SharedPreferencesUtils.removeBlacklistFolderByBucketId(context, target.bucketId)
        }
        blacklistFolders.removeAll { it.id == folderId || (target?.bucketId != null && it.bucketId == target.bucketId) }
        refreshAllTracks(context)
    }

    fun setVideoSupportEnable(context: Context, enable: Boolean) {
        if (!BuildConfig.SUPPORT_VIDEO) return
        videoSupportEnable.value = enable
        SharedPreferencesUtils.saveVideoSupportEnable(context, enable)
        refreshAllTracks(context)
    }

    fun setDecoderMode(context: Context, mode: Int) {
        decoderMode.intValue = mode
        SharedPreferencesUtils.saveDecoderMode(context, mode)
    }

    fun setBitPerfectUsbEnable(context: Context, enable: Boolean) {
        bitPerfectUsbEnable.value = enable
        SharedPreferencesUtils.saveBitPerfectUsbEnabled(context, enable)
        val bundle = Bundle().apply {
            putBoolean(MediaCommands.KEY_BIT_PERFECT_ENABLE, enable)
        }
        browser?.sendCustomCommand(MediaCommands.COMMAND_SET_BIT_PERFECT_ENABLE, bundle)
    }

    fun applyBitPerfectBundle(resultData: Bundle) {
        if (resultData.containsKey(MediaCommands.KEY_BIT_PERFECT_ENABLE)) {
            bitPerfectUsbEnable.value = resultData.getBoolean(MediaCommands.KEY_BIT_PERFECT_ENABLE, false)
        }
        if (resultData.containsKey(MediaCommands.KEY_BIT_PERFECT_ACTIVE)) {
            bitPerfectActive.value = resultData.getBoolean(MediaCommands.KEY_BIT_PERFECT_ACTIVE, false)
        }
        if (resultData.containsKey(MediaCommands.KEY_DAC_NAME)) {
            connectedDacName.value = resultData.getString(MediaCommands.KEY_DAC_NAME)
        }
        if (resultData.containsKey(MediaCommands.KEY_BIT_PERFECT_STATUS)) {
            bitPerfectStatus.value = resultData.getString(MediaCommands.KEY_BIT_PERFECT_STATUS, "")
        }
        if (resultData.containsKey(MediaCommands.KEY_DAC_SAMPLE_RATES)) {
            val rates = resultData.getIntArray(MediaCommands.KEY_DAC_SAMPLE_RATES)
            connectedDacSampleRates.clear()
            if (rates != null) {
                connectedDacSampleRates.addAll(rates.toList())
            }
        }
    }

    fun setMergeAlbum(context: Context, enable: Boolean) {
        SharedPreferencesUtils.setMergeAlbum(context, enable)
        browser?.sendCustomCommand(MediaCommands.COMMAND_CLEAR_ALBUM_CACHE, Bundle())
        refreshAlbum.value = !refreshAlbum.value
        refreshArtist.value = !refreshArtist.value
        refreshGenre.value = !refreshGenre.value
    }

    fun refreshAllTracks(context: Context) {
        if (isRefreshing.value) return
        isRefreshing.value = true
        Toast.makeText(context, context.getString(R.string.refreshing_tracks), Toast.LENGTH_SHORT).show()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val pathsToScan = mutableListOf<String>()
                val scanMode = SharedPreferencesUtils.getScanMode(context)
                if (scanMode == SharedPreferencesUtils.SCAN_MODE_WHITELIST) {
                    val whitelist = SharedPreferencesUtils.getWhitelistFolders(context)
                    whitelist.forEach { filterFolder ->
                        val folderPath = filterFolder.path
                        val folderUri = filterFolder.uri
                        var foundFiles = false
                        if (folderPath.isNotEmpty()) {
                            val dir = File(folderPath)
                            if (dir.exists() && dir.canRead() && dir.listFiles() != null) {
                                dir.walk().maxDepth(15)
                                    .filter { it.isFile && isMusicFile(it.name) }
                                    .forEach { pathsToScan.add(it.absolutePath) }
                                foundFiles = true
                            }
                        }
                        if (!foundFiles && !folderUri.isNullOrEmpty()) {
                            fun walkDoc(docFile: DocumentFile, depth: Int = 0) {
                                if (depth > 15) return
                                docFile.listFiles().forEach { child ->
                                    if (child.isDirectory) {
                                        walkDoc(child, depth + 1)
                                    } else if (child.isFile && isMusicFile(child.name.orEmpty())) {
                                        val p = resolvePhysicalPath(context, child.uri)
                                        if (p != null) pathsToScan.add(p)
                                    }
                                }
                            }
                            val rootDoc = DocumentFile.fromTreeUri(context, folderUri.toUri())
                            if (rootDoc != null) {
                                walkDoc(rootDoc)
                            }
                        }
                    }
                } else {
                    val blacklist = SharedPreferencesUtils.getBlacklistFolders(context)
                    val blacklistPaths = blacklist.map { it.path.trimEnd('/') }.filter { it.isNotEmpty() }
                    fun isPathBlacklisted(p: String): Boolean {
                        return blacklistPaths.any { bp ->
                            p.startsWith("$bp/", ignoreCase = true) || p.equals(bp, ignoreCase = true)
                        }
                    }

                    val publicDirs = listOf(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PODCASTS),
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_AUDIOBOOKS)
                    )
                    publicDirs.forEach { dir ->
                        if (dir.exists() && !isPathBlacklisted(dir.absolutePath)) {
                            dir.walk().maxDepth(5)
                                .filter { file ->
                                    !isPathBlacklisted(file.absolutePath) && file.isFile && isMusicFile(file.name)
                                }
                                .forEach { pathsToScan.add(it.absolutePath) }
                        }
                    }

                    val folderList = getDb(context).StorageFolderDao().findAllByType(TRACKS_TYPE)
                    folderList.forEach { storageFolder ->
                        val treeUri = storageFolder.uri.toUri()
                        val rootDoc = DocumentFile.fromTreeUri(context, treeUri)
                        fun walkDoc(docFile: DocumentFile, depth: Int = 0) {
                            if (depth > 10) return
                            docFile.listFiles().forEach { child ->
                                val p = resolvePhysicalPath(context, child.uri)
                                if (p != null && isPathBlacklisted(p)) {
                                    return@forEach
                                }
                                if (child.isDirectory) {
                                    walkDoc(child, depth + 1)
                                } else if (child.isFile && isMusicFile(child.name.orEmpty())) {
                                    if (p != null) pathsToScan.add(p)
                                }
                            }
                        }
                        if (rootDoc != null) {
                            walkDoc(rootDoc)
                        }
                    }
                }

                // 3. 执行强制系统扫描并等待完成
                if (pathsToScan.isNotEmpty()) {
                    for (chunk in pathsToScan.chunked(200)) {
                        val latch = CountDownLatch(chunk.size)
                        MediaScannerConnection.scanFile(
                            context,
                            chunk.toTypedArray(),
                            null
                        ) { _, _ ->
                            latch.countDown()
                        }
                        try {
                            latch.await(5, TimeUnit.SECONDS)
                        } catch (_: InterruptedException) {
                        }
                    }
                }

                withContext(Dispatchers.Main) {
                    val futureResult: ListenableFuture<SessionResult>? =
                        browser?.sendCustomCommand(
                            MediaCommands.COMMAND_REFRESH_ALL,
                            Bundle().apply { },
                        )
                    if (futureResult == null) {
                        isRefreshing.value = false
                        return@withContext
                    }
                    futureResult.addListener({
                        try {
                            val sessionResult = futureResult.get()
                            if (sessionResult.resultCode == SessionResult.RESULT_SUCCESS) {
                                refreshPlayList.value = !refreshPlayList.value
                                refreshAlbum.value = !refreshAlbum.value
                                refreshArtist.value = !refreshArtist.value
                                refreshGenre.value = !refreshGenre.value
                                refreshFolder.value = !refreshFolder.value
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    sessionResult.extras.getParcelableArrayList(
                                        "songsList", MusicItem::class.java
                                    )?.also {
                                        songsList.clear()
                                        songsList.addAll(it)
                                    }
                                } else {
                                    @Suppress("DEPRECATION")
                                    sessionResult.extras.getParcelableArrayList<MusicItem>(
                                        "songsList"
                                    )?.also {
                                        songsList.clear()
                                        songsList.addAll(it)
                                    }
                                }
                                Toast.makeText(
                                    context,
                                    context.getString(R.string.refresh_completed, songsList.size),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } catch (e: Exception) {
                            Log.e("Client", "Failed to refresh tracks", e)
                        } finally {
                            isRefreshing.value = false
                        }
                    }, ContextCompat.getMainExecutor(context))
                }
            } catch (e: Exception) {
                Log.e("Client", "Error during refreshAllTracks", e)
                withContext(Dispatchers.Main) {
                    isRefreshing.value = false
                }
            }
        }
    }

    fun playShuffled(playListType: PlayListType, playListId: Long) {
        val browser = this.browser ?: return
        val args = Bundle().apply {
            putBoolean("queue", false)
            putBoolean("enable", true)
            putBoolean("autoPlay", true)
            putString("playListType", playListType.name)
            putLong("playListId", playListId)
        }
        browser.sendCustomCommand(MediaCommands.COMMAND_SMART_SHUFFLE, args)
    }
}
