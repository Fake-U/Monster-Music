package com.ztftrue.music.play.manager

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.util.UnstableApi
import com.ztftrue.music.play.PlayUtils
import com.ztftrue.music.sqlData.MusicDatabase
import com.ztftrue.music.sqlData.model.MainTab
import com.ztftrue.music.sqlData.model.MusicItem
import com.ztftrue.music.sqlData.model.SortFiledData
import com.ztftrue.music.utils.PlayListType
import com.ztftrue.music.utils.SharedPreferencesUtils
import com.ztftrue.music.utils.SortUtils
import com.ztftrue.music.utils.model.*
import com.ztftrue.music.utils.trackManager.*
import kotlinx.coroutines.*
import java.io.File
import java.util.LinkedHashMap
import kotlin.collections.ArrayList

/**
 * 负责音乐库数据的加载、缓存、检索和搜索。
 * 将原 PlayService 中的数据管理职责剥离至此。
 */
class MusicLibraryRepository(private val context: Context) {

    private val db: MusicDatabase = MusicDatabase.getDatabase(context)

    // ==========================================
    // 核心数据缓存 (原 PlayService 的成员变量)
    // ==========================================

    // 基础实体缓存
    val tracksLinkedHashMap = LinkedHashMap<Long, MusicItem>()
    val allTracksLinkedHashMap = LinkedHashMap<Long, MusicItem>() // 包含被过滤掉的文件夹中的歌曲
    val albumsLinkedHashMap = LinkedHashMap<Long, AlbumList>()
    val playListLinkedHashMap = LinkedHashMap<Long, MusicPlayList>()
    val artistsLinkedHashMap = LinkedHashMap<Long, ArtistList>()
    val genresLinkedHashMap = LinkedHashMap<Long, GenresList>()
    val foldersLinkedHashMap = LinkedHashMap<Long, FolderList>()

    // 关系/子列表缓存 (ID -> List)
    val playListTracksHashMap = HashMap<Long, ArrayList<MusicItem>>()
    val albumsListTracksHashMap = HashMap<Long, ArrayList<MusicItem>>()
    val artistsListTracksHashMap = HashMap<Long, ArrayList<MusicItem>>()
    val genresListTracksHashMap = HashMap<Long, ArrayList<MusicItem>>()
    val foldersListTracksHashMap = HashMap<Long, LinkedHashMap<Long, MusicItem>>()

    // 关联关系缓存
    val artistHasAlbumMap = HashMap<Long, ArrayList<AlbumList>>()
    val genreHasAlbumMap = HashMap<Long, ArrayList<AlbumList>>()
    val mergedAlbumIdsMap = HashMap<Long, HashSet<Long>>()

    // UI 显示相关的排序指示器 (部分逻辑依赖它)
    val showIndicatorList = ArrayList<SortFiledData>()

    // ==========================================
    // 初始化与加载
    // ==========================================
    val mainTabList = ArrayList<MainTab>()

    /**
     * 启动时加载所有基础数据
     */
    suspend fun loadAllData() = coroutineScope {
        // 并行加载各项数据
        awaitAll(
            async(Dispatchers.IO) { loadSongsAndFolders() }, // 最核心的歌曲数据
            async(Dispatchers.IO) { loadShowIndicatorList() },
            async(Dispatchers.IO) { loadMainTabs() }
            // 可以在这里添加其他需要预加载的项目，
            // 但原逻辑中 Albums/Artists 等似乎是懒加载或在 UI 层请求时加载的，
            // 或者是在 refreshAction 中全量加载的。
            // 依据原 loadAllTracksAndFolders() 逻辑，这里主要加载 Songs 和 Folders。
        )
    }

    /**
     * 对应原 refreshAction()，强制刷新所有数据
     */
    suspend fun refreshAll() = withContext(Dispatchers.IO) {
        clearCache()
        loadSongsAndFolders()
        loadShowIndicatorList()
        // 可以在这里根据需求预加载 Albums, Artists 等
    }

    private fun loadMainTabs() {
        val list = db.MainTabDao().findAllIsShowMainTabSortByPriority()
        mainTabList.clear()
        if (list.isEmpty()) {
            // 如果数据库为空，使用工具类添加默认标签并保存
            PlayUtils.addDefaultMainTab(mainTabList)
            db.MainTabDao().insertAll(mainTabList)
        } else {
            mainTabList.addAll(list)
        }
    }

    fun clearAlbumCache() {
        albumsLinkedHashMap.clear()
        albumsListTracksHashMap.clear()
        artistHasAlbumMap.clear()
        genreHasAlbumMap.clear()
        mergedAlbumIdsMap.clear()
    }

    private fun clearCache() {
        playListLinkedHashMap.clear()
        albumsLinkedHashMap.clear()
        artistsLinkedHashMap.clear()
        genresLinkedHashMap.clear()
        tracksLinkedHashMap.clear()
        playListTracksHashMap.clear()
        albumsListTracksHashMap.clear()
        artistsListTracksHashMap.clear()
        genresListTracksHashMap.clear()
        foldersListTracksHashMap.clear()
        allTracksLinkedHashMap.clear()
        artistHasAlbumMap.clear()
        genreHasAlbumMap.clear()
        mergedAlbumIdsMap.clear()
    }

    private fun loadSongsAndFolders() {
        val sortData = db.SortFiledDao().findSortByType(PlayListType.Songs.name)
//        val folders: List<StorageFolder> = db.StorageFolderDao().findAllByType(TRACKS_TYPE)
//        folders.forEach { it.uri }
        // 调用工具类填充 foldersLinkedHashMap, tracksLinkedHashMap, allTracksLinkedHashMap
        TracksManager.getFolderList(
            context,
            foldersLinkedHashMap,
            tracksLinkedHashMap,
            "${sortData?.filed ?: ""} ${sortData?.method ?: ""}".trim(),
            allTracksLinkedHashMap,
            foldersListTracksHashMap
        )
        val folderSortData = db.SortFiledDao().findSortByType(PlayUtils.ListTypeTracks.FoldersTracks)
        val folderSortOrder = "${folderSortData?.filed ?: ""} ${folderSortData?.method ?: ""}".trim()
        foldersListTracksHashMap.forEach { (_, fTracks) ->
            SortUtils.sortTracksMap(fTracks, folderSortOrder)
        }
    }

    private fun loadShowIndicatorList() {
        val sortData1 = db.SortFiledDao().findSortAll()
        showIndicatorList.clear()
        sortData1.forEach {
            if (it.type == PlayListType.Songs.name ||
                it.type == PlayListType.Albums.name ||
                it.type == PlayListType.Artists.name ||
                it.type == PlayListType.Folders.name ||
                it.type == PlayListType.PlayLists.name ||
                it.type == PlayListType.Genres.name ||
                it.type.endsWith("@Tracks")
            ) {
                showIndicatorList.add(it)
            }
        }
    }

    /**
     * 重新加载指定 ID 的歌曲信息（用于标签修改后的刷新）
     * @return 返回更新后的 MusicItem，如果找不到则返回 null
     */
    @UnstableApi
    suspend fun reloadTrack(id: Long): MusicItem? = withContext(Dispatchers.IO) {
        // 1. 从系统 MediaStore 或数据库获取最新信息
        // 假设 TracksManager 有这个静态方法 (根据原代码推断)
        val newItem = TracksManager.getMusicById(context, id)

        if (newItem != null) {
            // 2. 更新内存缓存
            tracksLinkedHashMap[id] = newItem
            allTracksLinkedHashMap[id] = newItem

            // 3. 尝试更新其他关联缓存 (可选，视性能要求而定，这里简单处理)
            // 如果该歌曲属于某个专辑/播放列表缓存，最稳妥的方式是清除那些缓存
            // 或者在这里进行精细化的查找替换
        } else {
            // 如果查不到了（可能被删除了），则移除缓存
            tracksLinkedHashMap.remove(id)
            allTracksLinkedHashMap.remove(id)
        }

        return@withContext newItem
    }
    // ==========================================
    // 数据获取 (Getter with Lazy Loading)
    // 对应原 onGetChildren 中的逻辑
    // ==========================================

    fun getPlayLists(): List<MusicPlayList> {
        if (playListLinkedHashMap.isNotEmpty()) {
            return ArrayList(playListLinkedHashMap.values)
        }
        val sortData = db.SortFiledDao().findSortByType(PlayListType.PlayLists.name)
        val result = PlaylistManager.getPlaylists(
            context,
            playListLinkedHashMap,
            tracksLinkedHashMap,
            sortData?.filed,
            sortData?.method
        )
        // 缓存已被 Manager 填充
        return result
    }

    fun getAlbums(): List<AlbumList> {
        if (albumsLinkedHashMap.isNotEmpty()) {
            return ArrayList(albumsLinkedHashMap.values)
        }
        if (allTracksLinkedHashMap.isEmpty()) {
            loadSongsAndFolders()
        }
        val sortDataP = db.SortFiledDao().findSortByType(PlayListType.Albums.name)
        val needMerge = SharedPreferencesUtils.getMergeAlbum(context)
        mergedAlbumIdsMap.clear()
        AlbumManager.getAlbumList(
            context,
            albumsLinkedHashMap,
            "${sortDataP?.filed ?: ""} ${sortDataP?.method ?: ""}",
            needMerge,
            mergedAlbumIdsMap
        )
        val scanMode = SharedPreferencesUtils.getScanMode(context)
        val hasFolderFilter = scanMode == SharedPreferencesUtils.SCAN_MODE_WHITELIST ||
                (scanMode == SharedPreferencesUtils.SCAN_MODE_BLACKLIST &&
                        (SharedPreferencesUtils.getBlacklistFolders(context).isNotEmpty() ||
                                !context.getSharedPreferences("scan_config", Context.MODE_PRIVATE).getString("ignore_folders", "").isNullOrEmpty()))
        if (hasFolderFilter) {
            val validAlbumIds = allTracksLinkedHashMap.values.map { it.albumId }.toSet()
            val validAlbumNames = if (needMerge) allTracksLinkedHashMap.values.map { it.album.trim().lowercase() }.toSet() else emptySet()
            val iterator = albumsLinkedHashMap.iterator()
            while (iterator.hasNext()) {
                val entry = iterator.next()
                val mergedIds = mergedAlbumIdsMap[entry.key] ?: setOf(entry.key)
                val hasTrack = mergedIds.any { validAlbumIds.contains(it) } || (needMerge && validAlbumNames.contains(entry.value.name.trim().lowercase()))
                if (!hasTrack) {
                    iterator.remove()
                } else {
                    val count = allTracksLinkedHashMap.values.count {
                        mergedIds.contains(it.albumId) || (needMerge && it.album.trim().equals(entry.value.name.trim(), ignoreCase = true) && (entry.value.artist.isBlank() || entry.value.artist.equals("Unknown", ignoreCase = true) || it.artist.trim().equals(entry.value.artist.trim(), ignoreCase = true)))
                    }
                    entry.value.trackNumber = count
                }
            }
        }
        return ArrayList(albumsLinkedHashMap.values)
    }

    fun getArtists(): List<ArtistList> {
        if (artistsLinkedHashMap.isNotEmpty()) {
            return ArrayList(artistsLinkedHashMap.values)
        }
        val sortDataP = db.SortFiledDao().findSortByType(PlayListType.Artists.name)
        ArtistManager.getArtistList(
            context,
            artistsLinkedHashMap,
            "${sortDataP?.filed ?: ""} ${sortDataP?.method ?: ""}"
        )
        val scanMode = SharedPreferencesUtils.getScanMode(context)
        val hasFolderFilter = scanMode == SharedPreferencesUtils.SCAN_MODE_WHITELIST ||
                (scanMode == SharedPreferencesUtils.SCAN_MODE_BLACKLIST &&
                        (SharedPreferencesUtils.getBlacklistFolders(context).isNotEmpty() ||
                                !context.getSharedPreferences("scan_config", Context.MODE_PRIVATE).getString("ignore_folders", "").isNullOrEmpty()))
        if (hasFolderFilter) {
            val validArtistIds = allTracksLinkedHashMap.values.map { it.artistId }.toSet()
            val iterator = artistsLinkedHashMap.iterator()
            while (iterator.hasNext()) {
                val entry = iterator.next()
                if (!validArtistIds.contains(entry.key)) {
                    iterator.remove()
                } else {
                    val count = allTracksLinkedHashMap.values.count { it.artistId == entry.key }
                    entry.value.trackNumber = count
                }
            }
        }
        return ArrayList(artistsLinkedHashMap.values)
    }

    fun getGenres(): List<GenresList> {
        if (genresLinkedHashMap.isNotEmpty()) {
            return ArrayList(genresLinkedHashMap.values)
        }
        if (tracksLinkedHashMap.isEmpty()) {
            loadSongsAndFolders()
        }
        val sortDataP = db.SortFiledDao().findSortByType(PlayListType.Genres.name)
        GenreManager.getGenresList(
            context,
            genresLinkedHashMap,
            if (tracksLinkedHashMap.isNotEmpty()) tracksLinkedHashMap else allTracksLinkedHashMap,
            "${sortDataP?.filed ?: ""} ${sortDataP?.method ?: ""}"
        )
        return ArrayList(genresLinkedHashMap.values)
    }

    fun getFolders(): List<FolderList> {
        if (foldersLinkedHashMap.isNotEmpty()) {
            return ArrayList(foldersLinkedHashMap.values)
        }
        // 如果为空，重新加载一次基础数据
        loadSongsAndFolders()
        return ArrayList(foldersLinkedHashMap.values)
    }

    fun getSongs(): List<MusicItem> {
        if (tracksLinkedHashMap.isNotEmpty()) {
            return ArrayList(tracksLinkedHashMap.values)
        }
        loadSongsAndFolders()
        return ArrayList(tracksLinkedHashMap.values)
    }

    fun getTrackById(id: Long): MusicItem? {
        return allTracksLinkedHashMap[id] ?: tracksLinkedHashMap[id]
    }

    // ==========================================
    // 子列表获取 (Tracks by Parent)
    // ==========================================

    fun getTracksByPlayListId(id: Long): List<MusicItem> {
        playListTracksHashMap[id]?.let { return it }

        if (playListLinkedHashMap.isEmpty()) {
            getPlayLists()
        }
        val sortData = db.SortFiledDao().findSortByType(PlayUtils.ListTypeTracks.PlayListsTracks)
        val playList = playListLinkedHashMap[id] ?: return emptyList()

        val file = File(playList.path)
        // 容错处理：如果文件路径有问题，可能无法获取 parent
        val parentPath = file.parent ?: return emptyList()

        val contentUri: Uri = ContentUris.withAppendedId(
            MediaStore.Files.getContentUri("external"), id
        )
        val tracks = PlaylistManager.getTracksByPlayListId(
            context,
            contentUri,
            parentPath,
            allTracksLinkedHashMap,
            sortData?.filed,
            sortData?.method
        )
        playListTracksHashMap[id] = tracks
        return tracks
    }

    fun getTracksByAlbumId(id: Long): List<MusicItem> {
        albumsListTracksHashMap[id]?.let { return it }

        val needMerge = SharedPreferencesUtils.getMergeAlbum(context)
        val tracks: ArrayList<MusicItem>
        val sortData = db.SortFiledDao().findSortByType(PlayUtils.ListTypeTracks.AlbumsTracks)
        val sortOrder = if (sortData == null || sortData.filed.isNullOrBlank()) {
            "${MediaStore.Audio.Media.TRACK} ASC"
        } else {
            "${sortData.filed} ${sortData.method}".trim()
        }
        val trackUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        if (needMerge) {
            val albumList = getAlbumById(id) ?: AlbumManager.getAlbumById(context, id)
            val mergedIds = mergedAlbumIdsMap[id] ?: setOf(id)
            val selection: String
            val selectionArgs: Array<String>
            if (mergedIds.isNotEmpty()) {
                val placeholders = mergedIds.joinToString(",") { "?" }
                selection = "${MediaStore.Audio.Media.ALBUM_ID} IN ($placeholders)"
                selectionArgs = mergedIds.map { it.toString() }.toTypedArray()
            } else if (albumList != null && albumList.name.isNotBlank()) {
                selection = "${MediaStore.Audio.Media.ALBUM} = ?"
                selectionArgs = arrayOf(albumList.name)
            } else {
                selection = "${MediaStore.Audio.Media.ALBUM_ID} = ?"
                selectionArgs = arrayOf(id.toString())
            }
            tracks = TracksManager.getTracksById(
                context, trackUri, allTracksLinkedHashMap, selection, selectionArgs, sortOrder
            )
        } else {
            tracks = TracksManager.getTracksById(
                context, trackUri, allTracksLinkedHashMap,
                MediaStore.Audio.Media.ALBUM_ID + "=?",
                arrayOf(id.toString()),
                sortOrder
            )
        }
        albumsListTracksHashMap[id] = tracks
        return tracks
    }

    suspend fun getTracksByArtistId(id: Long): List<MusicItem> = coroutineScope {
        artistsListTracksHashMap[id]?.let { return@coroutineScope it }

        if (artistsLinkedHashMap.isEmpty()) {
            getArtists()
        }
        val artist = artistsLinkedHashMap[id]
        if (artist != null) {
            val sortData = db.SortFiledDao().findSortByType(PlayUtils.ListTypeTracks.ArtistsTracks)
            val sortOrder = "${sortData?.filed ?: ""} ${sortData?.method ?: ""}"
            val trackUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

            // 并行加载：该艺术家的专辑列表（用于UI显示）和 歌曲列表
            val albumsDeferred = async(Dispatchers.IO) {
                // 确保专辑数据已加载
                if (albumsLinkedHashMap.isEmpty()) {
                    val sortDataP = db.SortFiledDao().findSortByType(PlayListType.Albums.name)
                    val needMerge = SharedPreferencesUtils.getMergeAlbum(context)
                    mergedAlbumIdsMap.clear()
                    AlbumManager.getAlbumList(
                        context, albumsLinkedHashMap,
                        "${sortDataP?.filed ?: ""} ${sortDataP?.method ?: ""}", needMerge,
                        mergedAlbumIdsMap
                    )
                }
                AlbumManager.getAlbumsByArtist(
                    context, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    albumsLinkedHashMap, MediaStore.Audio.Media.ARTIST_ID + "=?",
                    arrayOf(id.toString()), null,
                    mergedAlbumIdsMap
                )
            }

            val tracksDeferred = async(Dispatchers.IO) {
                TracksManager.getTracksById(
                    context, trackUri, allTracksLinkedHashMap,
                    MediaStore.Audio.Media.ARTIST_ID + "=?",
                    arrayOf(id.toString()), sortOrder
                )
            }

            val albums = albumsDeferred.await()
            val tracks = tracksDeferred.await()

            artistHasAlbumMap[id] = albums
            artistsListTracksHashMap[id] = tracks
            return@coroutineScope tracks
        }
        return@coroutineScope emptyList()
    }

    suspend fun getTracksByGenreId(id: Long): List<MusicItem> = coroutineScope {
        genresListTracksHashMap[id]?.let { return@coroutineScope it }

        if (genresLinkedHashMap.isEmpty()) {
            getGenres()
        }
        val genre = genresLinkedHashMap[id]
        if (genre != null) {
            val sortData = db.SortFiledDao().findSortByType(PlayUtils.ListTypeTracks.GenresTracks)
            val sortOrder = "${sortData?.filed ?: ""} ${sortData?.method ?: ""}"
            val uri = MediaStore.Audio.Genres.Members.getContentUri("external", id)

            // 并行加载：该流派的专辑列表 和 歌曲列表
            val albumsDeferred = async(Dispatchers.IO) {
                if (albumsLinkedHashMap.isEmpty()) {
                    val sortDataP = db.SortFiledDao().findSortByType(PlayListType.Albums.name)
                    val needMerge = SharedPreferencesUtils.getMergeAlbum(context)
                    mergedAlbumIdsMap.clear()
                    AlbumManager.getAlbumList(
                        context, albumsLinkedHashMap,
                        "${sortDataP?.filed ?: ""} ${sortDataP?.method ?: ""}", needMerge,
                        mergedAlbumIdsMap
                    )
                }
                AlbumManager.getAlbumsByGenre(
                    context, uri, albumsLinkedHashMap, null, null, null,
                    mergedAlbumIdsMap
                )
            }

            val tracksDeferred = async(Dispatchers.IO) {
                var tracksList = TracksManager.getTracksById(
                    context, uri, allTracksLinkedHashMap, null, null, sortOrder
                )
                if (tracksList.isEmpty()) {
                    val tracksPool = if (tracksLinkedHashMap.isNotEmpty()) tracksLinkedHashMap.values else allTracksLinkedHashMap.values
                    tracksList = ArrayList(
                        tracksPool.filter { it.genreId == id || it.genre.equals(genre.name, ignoreCase = true) }
                    )
                    SortUtils.sortTracks(tracksList, sortOrder)
                }
                tracksList
            }

            var albums = albumsDeferred.await()
            val tracks = tracksDeferred.await()

            if (albums.isEmpty() && tracks.isNotEmpty()) {
                val albumIds = tracks.map { it.albumId }.toSet()
                albums = ArrayList(albumsLinkedHashMap.values.filter { albumIds.contains(it.id) })
            }

            genreHasAlbumMap[id] = albums
            genresListTracksHashMap[id] = tracks
            return@coroutineScope tracks
        }
        return@coroutineScope emptyList()
    }

    fun getTracksByFolderId(id: Long): List<MusicItem> {
        val sortData = db.SortFiledDao().findSortByType(PlayUtils.ListTypeTracks.FoldersTracks)
        val sortOrder = "${sortData?.filed ?: ""} ${sortData?.method ?: ""}".trim()

        foldersListTracksHashMap[id]?.let { tracksMap ->
            val list = ArrayList(tracksMap.values)
            SortUtils.sortTracks(list, sortOrder)
            return list
        }

        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val selection = MediaStore.Audio.Media.BUCKET_ID + "=?"

        val listT = TracksManager.getTracksById(
            context,
            uri,
            allTracksLinkedHashMap,
            selection,
            arrayOf(id.toString()),
            sortOrder
        )

        if (SharedPreferencesUtils.getVideoSupportEnable(context)) {
            try {
                context.contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Video.Media._ID),
                    MediaStore.Video.Media.BUCKET_ID + "=?",
                    arrayOf(id.toString()),
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idCol = cursor.getColumnIndex(MediaStore.Video.Media._ID)
                        do {
                            val rawVideoId = cursor.getLong(idCol)
                            val musicId = -(rawVideoId + 1L)
                            allTracksLinkedHashMap[musicId]?.let { listT.add(it) }
                        } while (cursor.moveToNext())
                    }
                }
            } catch (_: Exception) {}
        }
        SortUtils.sortTracks(listT, sortOrder)

        val tracksMap = LinkedHashMap<Long, MusicItem>()
        listT.forEach { tracksMap[it.id] = it }
        foldersListTracksHashMap[id] = tracksMap

        return listT
    }

    // ==========================================
    // 搜索功能
    // ==========================================

    data class SearchResult(
        val tracks: ArrayList<MusicItem>,
        val albums: ArrayList<AlbumList>,
        val artists: ArrayList<ArtistList>
    )

    suspend fun search(query: String): SearchResult = coroutineScope {
        if (query.isEmpty() || query.length <= 1) {
            return@coroutineScope SearchResult(ArrayList(), ArrayList(), ArrayList())
        }

        val tracksDeferred = async(Dispatchers.IO) {
            TracksManager.searchTracks(context, tracksLinkedHashMap, query)
        }
        val albumsDeferred = async(Dispatchers.IO) {
            val needMerge = SharedPreferencesUtils.getMergeAlbum(context)
            AlbumManager.searchAlbumByName(context, query, needMerge)
        }
        val artistsDeferred = async(Dispatchers.IO) {
            ArtistManager.searchArtistByName(context, query)
        }

        val scanMode = SharedPreferencesUtils.getScanMode(context)
        val hasFolderFilter = scanMode == SharedPreferencesUtils.SCAN_MODE_WHITELIST ||
                (scanMode == SharedPreferencesUtils.SCAN_MODE_BLACKLIST &&
                        (SharedPreferencesUtils.getBlacklistFolders(context).isNotEmpty() ||
                                !context.getSharedPreferences("scan_config", Context.MODE_PRIVATE).getString("ignore_folders", "").isNullOrEmpty()))
        val albumsResult = albumsDeferred.await()
        val artistsResult = artistsDeferred.await()

        val finalAlbums = if (hasFolderFilter) {
            val validAlbumIds = allTracksLinkedHashMap.values.map { it.albumId }.toSet()
            val validAlbumNames = allTracksLinkedHashMap.values.map { it.album.trim().lowercase() }.toSet()
            ArrayList(albumsResult.filter {
                validAlbumIds.contains(it.id) || validAlbumNames.contains(it.name.trim().lowercase())
            })
        } else {
            albumsResult
        }

        val finalArtists = if (hasFolderFilter) {
            val validArtistIds = allTracksLinkedHashMap.values.map { it.artistId }.toSet()
            ArrayList(artistsResult.filter {
                validArtistIds.contains(it.id)
            })
        } else {
            artistsResult
        }

        SearchResult(
            tracks = tracksDeferred.await(),
            albums = finalAlbums,
            artists = finalArtists
        )
    }

    // ==========================================
    // 数据操作 (删除/更新)
    // ==========================================

    /**
     * 删除歌曲
     * @return 返回被删除歌曲的ID，如果未找到则返回-1
     */
    fun deleteTrack(idsToDelete: Long, musicQueue: ArrayList<MusicItem>): Long {
        val deletedId = PlayUtils.trackDelete(
            idsToDelete,
            musicQueue,
            tracksLinkedHashMap
        )
        // 删除后清理缓存，以迫使下次重新加载正确的数据
        if (deletedId > -1) {
            clearCache()
            // 注意：这里简单粗暴地清理了缓存，实际优化可以只移除特定的条目，
            // 但考虑到关联关系复杂（专辑、歌手、播放列表都可能包含此歌），全清是最安全的。
            // 重新加载会在下次获取数据时自动触发。
        }
        return deletedId
    }

    fun updateTrackInfo(id: Long, updatedTrack: MusicItem?) {
        if (updatedTrack != null) {
            tracksLinkedHashMap[id] = updatedTrack
        } else {
            tracksLinkedHashMap.remove(id)
        }
        // 更新后也建议清理相关缓存
        clearCache()
    }

    // ==========================================
    // 单项获取 (ById)
    // ==========================================

    fun getGenreById(id: Long): GenresList? {
        if (genresLinkedHashMap.isEmpty()) {
            getGenres()
        }
        return genresLinkedHashMap[id]
    }

    fun getArtistById(id: Long): ArtistList? {
        if (artistsLinkedHashMap.isEmpty()) {
            getArtists()
        }
        return artistsLinkedHashMap[id]
    }

    fun getAlbumById(id: Long): AlbumList? {
        if (albumsLinkedHashMap.isEmpty()) {
            getAlbums()
        }
        return albumsLinkedHashMap[id]
    }

    fun getFolderById(id: Long): FolderList? {
        if (foldersLinkedHashMap.isEmpty()) {
            getFolders()
        }
        return foldersLinkedHashMap[id]
    }

    fun getPlaylistById(id: Long): MusicPlayList? {
        if (playListLinkedHashMap.isEmpty()) {
            getPlayLists()
        }
        return playListLinkedHashMap[id]
    }


    suspend fun handleSort(
        type: String,
        filed: String? = null,
        filedName: String? = null,
        method: String? = null,
        methodName: String? = null
    ) = withContext(Dispatchers.IO) {
        if (filed != null && method != null) {
            val sortDao = db.SortFiledDao()
            val sortData = sortDao.findSortByType(type)
            if (sortData != null) {
                sortData.filed = filed
                sortData.filedName = filedName ?: ""
                sortData.method = method
                sortData.methodName = methodName ?: ""
                sortDao.update(sortData)
            } else {
                sortDao.insert(SortFiledData(type, filed, method, methodName ?: "", filedName ?: ""))
            }
        }
        // 1. 无论哪种类型排序，指示器列表可能都变了，重新加载
        loadShowIndicatorList()

        when (type) {
            // --- 主列表排序：只需清空，下次 getXXX() 会自动重新加载 ---
            PlayListType.PlayLists.name -> {
                playListLinkedHashMap.clear()
            }

            PlayListType.Albums.name -> {
                albumsLinkedHashMap.clear()
            }

            PlayListType.Artists.name -> {
                artistsLinkedHashMap.clear()
            }

            PlayListType.Genres.name -> {
                genresLinkedHashMap.clear()
            }

            PlayListType.Folders.name -> {
                val isDesc = method?.equals("DESC", ignoreCase = true) == true
                SortUtils.sortFolders(foldersLinkedHashMap, ascending = !isDesc)
            }

            // --- 所有歌曲排序：立即重新加载 ---
            PlayListType.Songs.name -> {
                tracksLinkedHashMap.clear()
                // Folders 和 Songs 是强关联的（TracksManager.getFolderList 同时加载了两者）
                // 所以需要一起刷新
                foldersLinkedHashMap.clear()
                allTracksLinkedHashMap.clear()
                loadSongsAndFolders()
            }

            // --- 子列表排序：清空缓存，下次点击进入某专辑/列表时重新加载 ---
            // 这些常量来自 PlayUtils.ListTypeTracks
            PlayUtils.ListTypeTracks.PlayListsTracks -> {
                playListTracksHashMap.clear()
            }

            PlayUtils.ListTypeTracks.AlbumsTracks -> {
                albumsListTracksHashMap.clear()
            }

            PlayUtils.ListTypeTracks.ArtistsTracks -> {
                artistsListTracksHashMap.clear()
            }

            PlayUtils.ListTypeTracks.GenresTracks -> {
                genresListTracksHashMap.clear()
            }

            PlayUtils.ListTypeTracks.FoldersTracks -> {
                val sortData = db.SortFiledDao().findSortByType(PlayUtils.ListTypeTracks.FoldersTracks)
                val sortOrder = "${sortData?.filed ?: ""} ${sortData?.method ?: ""}".trim()
                foldersListTracksHashMap.forEach { (_, tracksMap) ->
                    SortUtils.sortTracksMap(tracksMap, sortOrder)
                }
            }
        }
    }
}