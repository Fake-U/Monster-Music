package com.ztftrue.music.utils

import android.annotation.SuppressLint
import android.appwidget.AppWidgetManager
import android.content.Context
import androidx.compose.ui.text.style.TextAlign
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.ztftrue.music.BuildConfig
import com.ztftrue.music.R
import com.ztftrue.music.sqlData.model.FilterFolder
import com.ztftrue.music.sqlData.model.MusicItem
import com.ztftrue.music.utils.model.FolderList
import com.ztftrue.music.utils.trackManager.FolderManger

object SharedPreferencesUtils {
    fun saveFontSize(context: Context, fontSize: Int) {
        context.getSharedPreferences("display", Context.MODE_PRIVATE).edit {
            putInt("fontSize", fontSize)
        }
    }

    fun getFontSize(context: Context): Int {
        return context.getSharedPreferences("display", Context.MODE_PRIVATE).getInt("fontSize", 16)
    }

    fun saveShowFolderPath(context: Context, value: Boolean) {
        context.getSharedPreferences("display", Context.MODE_PRIVATE).edit {
            putBoolean("show_folder_path", value)
        }
    }

    fun getShowFolderPath(context: Context): Boolean {
        return context.getSharedPreferences("display", Context.MODE_PRIVATE)
            .getBoolean("show_folder_path", false)
    }

    fun saveShowFolderTree(context: Context, value: Boolean) {
        context.getSharedPreferences("display", Context.MODE_PRIVATE).edit {
            putBoolean("show_folder_tree", value)
        }
    }

    fun getShowFolderTree(context: Context): Boolean {
        return context.getSharedPreferences("display", Context.MODE_PRIVATE)
            .getBoolean("show_folder_tree", false)
    }

    fun saveDisplayAlign(context: Context, textAlign: TextAlign) {
        context.getSharedPreferences("display", Context.MODE_PRIVATE).edit {
            putString("displayAlign", textAlign.toString())
        }
    }

    fun getDisplayAlign(context: Context): TextAlign {
        val t = context.getSharedPreferences("display", Context.MODE_PRIVATE)
            .getString("displayAlign", TextAlign.Center.toString())
        return TextAlign.values().firstOrNull { it.toString() == t.toString() }
            ?: TextAlign.Center
    }

    fun saveAutoScroll(context: Context, autoScroll: Boolean) {
        context.getSharedPreferences("display", Context.MODE_PRIVATE).edit {
            putBoolean("AutoScroll", autoScroll)
        }
    }

    fun getAutoScroll(context: Context): Boolean {
        return context.getSharedPreferences("display", Context.MODE_PRIVATE)
            .getBoolean("AutoScroll", true)
    }

    fun saveAutoHighLight(context: Context, autoHighLight: Boolean) {
        context.getSharedPreferences("display", Context.MODE_PRIVATE).edit {
            putBoolean("AutoHighLight", autoHighLight)
        }
    }

    fun getAutoHighLight(context: Context): Boolean {
        return context.getSharedPreferences("display", Context.MODE_PRIVATE)
            .getBoolean("AutoHighLight", true)
    }

    fun enableShuffle(context: Context, enable: Boolean) {
        context.getSharedPreferences("queue", Context.MODE_PRIVATE).edit {
            putBoolean("EnableShuffle", enable)
        }
    }

    fun getEnableShuffle(context: Context): Boolean {
        return context.getSharedPreferences("queue", Context.MODE_PRIVATE)
            .getBoolean("EnableShuffle", false)
    }

    fun getEnableMusicVisualization(context: Context): Boolean {
        return context.getSharedPreferences("Visualization", Context.MODE_PRIVATE)
            .getBoolean("Enable", false)
    }

    fun saveEnableMusicVisualization(context: Context, enable: Boolean) {
        context.getSharedPreferences("Visualization", Context.MODE_PRIVATE).edit {
            putBoolean("Enable", enable)
        }
    }

    fun getVisualizationMode(context: Context): String {
        return context.getSharedPreferences("Visualization", Context.MODE_PRIVATE)
            .getString("mode", "Matrix") ?: "Matrix"
    }

    fun saveVisualizationMode(context: Context, mode: String) {
        context.getSharedPreferences("Visualization", Context.MODE_PRIVATE).edit {
            putString("mode", mode)
        }
    }



    fun getShowMusicCover(context: Context): Boolean {
        return context.getSharedPreferences("Visualization", Context.MODE_PRIVATE)
            .getBoolean("Cover", true)
    }

    fun saveShowMusicCover(context: Context, enable: Boolean) {
        context.getSharedPreferences("Visualization", Context.MODE_PRIVATE).edit {
            putBoolean("Cover", enable)
        }
    }

    fun saveCurrentPlayMusicId(context: Context, id: Long) {
        context.getSharedPreferences(
            "SelectedPlayTrack",
            Context.MODE_PRIVATE
        ).edit { putLong("SelectedPlayTrack", id) }
    }

    fun getCurrentPlayId(context: Context): Long {
        return context.getSharedPreferences(
            "SelectedPlayTrack",
            Context.MODE_PRIVATE
        ).getLong("SelectedPlayTrack", -1)
    }

    @SuppressLint("ApplySharedPref")
    fun saveCurrentDuration(context: Context, duration: Long) {
        context.getSharedPreferences(
            "SelectedPlayTrack",
            Context.MODE_PRIVATE
        ).edit(commit = true) { putLong("CurrentPosition", duration) }
    }

    @SuppressLint("ApplySharedPref")
    fun saveVolume(context: Context, volume: Int) {
        context.getSharedPreferences(
            "volume",
            Context.MODE_PRIVATE
        ).edit(commit = true) { putInt("volume", volume) }
    }

    fun getVolume(context: Context): Int {
        return context.getSharedPreferences(
            "volume",
            Context.MODE_PRIVATE
        ).getInt("volume", 100)
    }

    fun getCurrentPosition(context: Context): Long {
        return context.getSharedPreferences(
            "SelectedPlayTrack",
            Context.MODE_PRIVATE
        ).getLong("CurrentPosition", 0)
    }

    fun setWidgetData(context: Context, isPlaying: Boolean, currentPlayTrack: MusicItem?) {
        context.getSharedPreferences("Widgets", Context.MODE_PRIVATE).edit {
            putBoolean("playingStatus", isPlaying)
                .putString("title", currentPlayTrack?.name ?: "")
                .putLong("id", currentPlayTrack?.id ?: 0L)
                .putString("author", currentPlayTrack?.artist ?: "")
                .putString("path", currentPlayTrack?.path ?: "")
        }
    }

    fun setWidgetEnable(context: Context, enable: Boolean) {
        context.getSharedPreferences("Widgets", Context.MODE_PRIVATE).edit(commit = true) {
            putBoolean(
                "enable",
                enable
            )
        }
    }

    fun getWidgetEnable(context: Context): Boolean {
        return context.getSharedPreferences("Widgets", Context.MODE_PRIVATE).getBoolean(
            "enable",
            false
        )
    }

    fun getAutoPlayWaitTime(context: Context): Long {
        return context.getSharedPreferences("AutoPlay", Context.MODE_PRIVATE)
            .getLong("waitTime", 1000)
    }

    fun getAutoPlayEnable(context: Context): Boolean {
        return context.getSharedPreferences("AutoPlay", Context.MODE_PRIVATE)
            .getBoolean("enable", false)
    }

    fun setAutoPlayWaitTime(context: Context, waitTime: Long) {
        context.getSharedPreferences("AutoPlay", Context.MODE_PRIVATE).edit {
            putLong("waitTime", waitTime)
        }
    }

    fun setAutoPlayEnable(context: Context, enable: Boolean) {
        context.getSharedPreferences("AutoPlay", Context.MODE_PRIVATE).edit {
            putBoolean("enable", enable)
        }
    }

    fun getShowSlideIndicators(context: Context): Boolean {
        return context.getSharedPreferences("display", Context.MODE_PRIVATE)
            .getBoolean("lyrics_slider_indicators", false)
    }

    fun setShowSlideIndicators(context: Context, enable: Boolean) {
        context.getSharedPreferences("display", Context.MODE_PRIVATE).edit {
            putBoolean("lyrics_slider_indicators", enable)
        }
    }

    fun getShowRightIndicator(context: Context): Boolean {
        return context.getSharedPreferences("display", Context.MODE_PRIVATE)
            .getBoolean("lyrics_right_indicator", true)
    }

    fun setShowRightIndicator(context: Context, enable: Boolean) {
        context.getSharedPreferences("display", Context.MODE_PRIVATE).edit {
            putBoolean("lyrics_right_indicator", enable)
        }
    }

    fun getAutoToTopRandom(context: Context): Boolean {
        return context.getSharedPreferences("config", Context.MODE_PRIVATE)
            .getBoolean("auto_to_top_when_random", false)
    }

    fun setAutoToTopRandom(context: Context, enable: Boolean) {
        context.getSharedPreferences("config", Context.MODE_PRIVATE).edit {
            putBoolean("auto_to_top_when_random", enable)
        }
    }

    fun getMergeAlbum(context: Context): Boolean {
        return context.getSharedPreferences("config", Context.MODE_PRIVATE)
            .getBoolean("merge_album", false)
    }

    fun setMergeAlbum(context: Context, enable: Boolean) {
        context.getSharedPreferences("config", Context.MODE_PRIVATE).edit {
            putBoolean("merge_album", enable)
        }
    }

    fun getIgnoreDuration(context: Context): Long {
        return context.getSharedPreferences("scan_config", Context.MODE_PRIVATE)
            .getLong("ignore_duration", 0L)
    }

    fun setIgnoreDuration(context: Context, durationValue: Long) {
        context.getSharedPreferences("scan_config", Context.MODE_PRIVATE).edit {
            putLong("ignore_duration", durationValue)
        }
    }

    const val SCAN_MODE_BLACKLIST = 0
    const val SCAN_MODE_WHITELIST = 1
    const val SCAN_MODE_ALL = SCAN_MODE_BLACKLIST
    const val SCAN_MODE_FOLDER = SCAN_MODE_WHITELIST

    private val gson = Gson()
    private val filterFolderListType = object : TypeToken<List<FilterFolder>>() {}.type

    fun getScanMode(context: Context): Int {
        return context.getSharedPreferences("scan_config", Context.MODE_PRIVATE)
            .getInt("scan_mode", SCAN_MODE_BLACKLIST)
    }

    fun setScanMode(context: Context, mode: Int) {
        context.getSharedPreferences("scan_config", Context.MODE_PRIVATE).edit {
            putInt("scan_mode", mode)
        }
    }

    fun getWhitelistFolders(context: Context): List<FilterFolder> {
        val prefs = context.getSharedPreferences("scan_config", Context.MODE_PRIVATE)
        val json = prefs.getString("whitelist_folders", null)
        if (!json.isNullOrEmpty()) {
            try {
                val list: List<FilterFolder>? = gson.fromJson(json, filterFolderListType)
                if (list != null) return list
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        val legacyPath = prefs.getString("exclusive_folder_path", null)
        if (!legacyPath.isNullOrEmpty()) {
            val legacyUri = prefs.getString("exclusive_folder_uri", null)
            val name = legacyPath.trimEnd('/').substringAfterLast('/', legacyPath)
            val migrated = listOf(FilterFolder(uri = legacyUri, path = legacyPath, name = name))
            saveWhitelistFolders(context, migrated)
            return migrated
        }
        return emptyList()
    }

    fun saveWhitelistFolders(context: Context, folders: List<FilterFolder>) {
        val json = gson.toJson(folders)
        context.getSharedPreferences("scan_config", Context.MODE_PRIVATE).edit {
            putString("whitelist_folders", json)
        }
    }

    fun addWhitelistFolder(context: Context, folder: FilterFolder): Boolean {
        val current = getWhitelistFolders(context).toMutableList()
        val normalizedPath = folder.path.trimEnd('/')
        if (current.any { it.path.trimEnd('/').equals(normalizedPath, ignoreCase = true) }) {
            return false
        }
        current.add(folder)
        saveWhitelistFolders(context, current)
        return true
    }

    fun removeWhitelistFolder(context: Context, folderId: String) {
        val current = getWhitelistFolders(context).toMutableList()
        current.removeAll { it.id == folderId }
        saveWhitelistFolders(context, current)
    }

    fun getBlacklistFolders(context: Context): List<FilterFolder> {
        val prefs = context.getSharedPreferences("scan_config", Context.MODE_PRIVATE)
        val json = prefs.getString("blacklist_folders", null)
        val list = mutableListOf<FilterFolder>()
        if (!json.isNullOrEmpty()) {
            try {
                val parsed: List<FilterFolder>? = gson.fromJson(json, filterFolderListType)
                if (parsed != null) {
                    list.addAll(parsed)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        val legacyIgnore = prefs.getString("ignore_folders", null)
        if (!legacyIgnore.isNullOrEmpty()) {
            var modified = false
            val legacyIds = legacyIgnore.split(",").mapNotNull { it.trim().toLongOrNull() }
            val currentBucketIds = list.mapNotNull { it.bucketId }.toSet()
            val missingBucketIds = legacyIds.filter { !currentBucketIds.contains(it) }
            if (missingBucketIds.isNotEmpty()) {
                val folderMap: HashMap<Long, FolderList> = try {
                    FolderManger.getMusicFolders(context)
                } catch (e: Exception) {
                    HashMap()
                }
                missingBucketIds.forEach { id ->
                    val detected = folderMap[id]
                    val name = detected?.name?.ifBlank { null } ?: "Folder $id"
                    val path = detected?.path ?: ""
                    list.add(FilterFolder(bucketId = id, path = path, name = name))
                    modified = true
                }
                if (modified) {
                    saveBlacklistFolders(context, list)
                }
            }
        }
        return list
    }

    fun saveBlacklistFolders(context: Context, folders: List<FilterFolder>) {
        val json = gson.toJson(folders)
        val bucketIds = folders.mapNotNull { it.bucketId }.distinct()
        val ignoreFoldersString = bucketIds.joinToString(",")
        context.getSharedPreferences("scan_config", Context.MODE_PRIVATE).edit {
            putString("blacklist_folders", json)
            putString("ignore_folders", ignoreFoldersString)
        }
    }

    fun addBlacklistFolder(context: Context, folder: FilterFolder): Boolean {
        val current = getBlacklistFolders(context).toMutableList()
        val normalizedPath = folder.path.trimEnd('/')
        if (folder.bucketId != null && current.any { it.bucketId == folder.bucketId }) {
            return false
        }
        if (normalizedPath.isNotEmpty() && current.any { it.path.trimEnd('/').equals(normalizedPath, ignoreCase = true) }) {
            return false
        }
        current.add(folder)
        saveBlacklistFolders(context, current)
        return true
    }

    fun removeBlacklistFolder(context: Context, folderId: String) {
        val current = getBlacklistFolders(context).toMutableList()
        current.removeAll { it.id == folderId }
        saveBlacklistFolders(context, current)
    }

    fun removeBlacklistFolderByBucketId(context: Context, bucketId: Long) {
        val current = getBlacklistFolders(context).toMutableList()
        current.removeAll { it.bucketId == bucketId }
        saveBlacklistFolders(context, current)
    }

    fun ignoreFolder(context: Context, folderList: FolderList): Boolean {
        val folder = FilterFolder(
            path = folderList.path,
            name = folderList.name.ifBlank { folderList.path.substringAfterLast('/') },
            bucketId = folderList.id
        )
        return addBlacklistFolder(context, folder)
    }

    fun getExclusiveFolderUri(context: Context): String? {
        return context.getSharedPreferences("scan_config", Context.MODE_PRIVATE)
            .getString("exclusive_folder_uri", null)
    }

    fun setExclusiveFolderUri(context: Context, uri: String?) {
        context.getSharedPreferences("scan_config", Context.MODE_PRIVATE).edit {
            putString("exclusive_folder_uri", uri)
        }
    }

    fun getExclusiveFolderPath(context: Context): String? {
        val whitelist = getWhitelistFolders(context)
        if (whitelist.isNotEmpty()) {
            return whitelist.first().path
        }
        return context.getSharedPreferences("scan_config", Context.MODE_PRIVATE)
            .getString("exclusive_folder_path", null)
    }

    fun setExclusiveFolderPath(context: Context, path: String?) {
        context.getSharedPreferences("scan_config", Context.MODE_PRIVATE).edit {
            putString("exclusive_folder_path", path)
        }
    }

    fun isFirstScanSetupCompleted(context: Context): Boolean {
        return context.getSharedPreferences("scan_config", Context.MODE_PRIVATE)
            .getBoolean("first_scan_setup_completed", false)
    }

    fun setFirstScanSetupCompleted(context: Context, completed: Boolean) {
        context.getSharedPreferences("scan_config", Context.MODE_PRIVATE).edit {
            putBoolean("first_scan_setup_completed", completed)
        }
    }


    fun getCurrentLanguage(context: Context): String? {
        return context.getSharedPreferences("config", Context.MODE_PRIVATE)
            .getString("language", null)
    }

    fun setCurrentLanguage(context: Context, value: String) {
        context.getSharedPreferences("config", Context.MODE_PRIVATE).edit {
            putString("language", value)
        }
    }

    fun setAutoHandleAudioFocus(context: Context, enable: Boolean) {
        context.getSharedPreferences("config", Context.MODE_PRIVATE).edit(commit = true) {
            putBoolean("auto_handle_audio_focus", enable)
        }
    }

    fun getAutoHandleAudioFocus(context: Context): Boolean {
        return context.getSharedPreferences("config", Context.MODE_PRIVATE)
            .getBoolean("auto_handle_audio_focus", true)
    }


    fun setTrackCoverData(context: Context, coverPath: String) {
        context.getSharedPreferences("Cover", Context.MODE_PRIVATE).edit {
            putString("path", coverPath)
        }
    }

    fun getTrackCoverData(context: Context): String? {
        return context.getSharedPreferences("Cover", Context.MODE_PRIVATE).getString("path", "")
    }

    fun setWidgetBackground(context: Context, color: String, appWidgetId: Int? = null) {
        context.getSharedPreferences("config", Context.MODE_PRIVATE).edit(commit = true) {
            putString("widget_background", color)
            if (appWidgetId != null && appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                putString("widget_background_$appWidgetId", color)
            }
        }
    }

    @OptIn(ExperimentalStdlibApi::class)
    fun getWidgetBackground(context: Context, appWidgetId: Int? = null): String {
        val prefs = context.getSharedPreferences("config", Context.MODE_PRIVATE)
        val defaultColor = "#" + ContextCompat.getColor(context, R.color.light_blue_900).toHexString()
        if (appWidgetId != null && appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            val specific = prefs.getString("widget_background_$appWidgetId", null)
            if (specific != null) return specific
        }
        return prefs.getString("widget_background", defaultColor) ?: defaultColor
    }

    fun setWidgetTextContrast(context: Context, mode: String, appWidgetId: Int? = null) {
        context.getSharedPreferences("config", Context.MODE_PRIVATE).edit(commit = true) {
            putString("widget_text_contrast", mode)
            if (appWidgetId != null && appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                putString("widget_text_contrast_$appWidgetId", mode)
            }
        }
    }

    fun getWidgetTextContrast(context: Context, appWidgetId: Int? = null): String {
        val prefs = context.getSharedPreferences("config", Context.MODE_PRIVATE)
        if (appWidgetId != null && appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            val specific = prefs.getString("widget_text_contrast_$appWidgetId", null)
            if (specific != null) return specific
        }
        return prefs.getString("widget_text_contrast", "auto") ?: "auto"
    }

    fun removeWidgetConfig(context: Context, appWidgetId: Int) {
        context.getSharedPreferences("config", Context.MODE_PRIVATE).edit(commit = true) {
            remove("widget_background_$appWidgetId")
            remove("widget_text_contrast_$appWidgetId")
        }
    }

    fun setAutoDismissDicPop(context: Context, auto: Boolean) {
        context.getSharedPreferences("config", Context.MODE_PRIVATE).edit {
            putBoolean("auto_dismiss_dic_pop", auto)
        }
    }

    fun getAutoDismissDicPop(context: Context): Boolean {
        return context.getSharedPreferences("config", Context.MODE_PRIVATE)
            .getBoolean("auto_dismiss_dic_pop", false)
    }



    fun saveVideoSupportEnable(context: Context, value: Boolean) {
        if (!BuildConfig.SUPPORT_VIDEO) return
        context.getSharedPreferences("play_config", Context.MODE_PRIVATE).edit {
            putBoolean("video_support_enable", value)
        }
    }

    fun getVideoSupportEnable(context: Context): Boolean {
        if (!BuildConfig.SUPPORT_VIDEO) return false
        return context.getSharedPreferences("play_config", Context.MODE_PRIVATE)
            .getBoolean("video_support_enable", false)
    }

    fun saveDecoderMode(context: Context, mode: Int) {
        context.getSharedPreferences("play_config", Context.MODE_PRIVATE).edit {
            putInt("decoder_mode", mode)
        }
    }

    fun getDecoderMode(context: Context): Int {
        // Default: 1 (DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        // Software decoding (FFmpeg) fallback when hardware decoding cannot be used
        return context.getSharedPreferences("play_config", Context.MODE_PRIVATE)
            .getInt("decoder_mode", 1)
    }

    fun saveBitPerfectUsbEnabled(context: Context, value: Boolean) {
        context.getSharedPreferences("play_config", Context.MODE_PRIVATE).edit {
            putBoolean("bit_perfect_usb_enable", value)
        }
    }

    fun getBitPerfectUsbEnabled(context: Context): Boolean {
        return context.getSharedPreferences("play_config", Context.MODE_PRIVATE)
            .getBoolean("bit_perfect_usb_enable", false)
    }
}