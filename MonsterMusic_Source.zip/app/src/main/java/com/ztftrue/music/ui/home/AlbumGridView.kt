package com.ztftrue.music.ui.home

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.LibraryResult
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.ListenableFuture
import com.ztftrue.music.MusicViewModel
import com.ztftrue.music.R
import com.ztftrue.music.Router
import com.ztftrue.music.play.MediaItemUtils
import com.ztftrue.music.ui.public.AddMusicToPlayListDialog
import com.ztftrue.music.ui.public.AlphabetScroller
import com.ztftrue.music.ui.public.CreatePlayListDialog
import com.ztftrue.music.ui.public.generateItemFilters
import com.ztftrue.music.utils.DialogOperate
import com.ztftrue.music.utils.OperateType
import com.ztftrue.music.utils.PlayListType
import com.ztftrue.music.utils.ScrollDirectionType
import com.ztftrue.music.utils.SortUtils
import com.ztftrue.music.utils.Utils
import com.ztftrue.music.utils.model.AlbumList
import com.ztftrue.music.utils.model.ItemFilterModel
import kotlinx.coroutines.launch


@Composable
fun AlbumGridView(
    modifier: Modifier = Modifier,
    musicViewModel: MusicViewModel,
    navController: SnapshotStateList<Any>,
    albumListDefault: SnapshotStateList<AlbumList>? = null,
    type: PlayListType = PlayListType.Albums,
    scrollDirection: ScrollDirectionType? = null
) {
    val listState = rememberLazyGridState()
    var albumList = remember { mutableStateListOf<AlbumList>() }
    if (albumListDefault != null) {
        albumList = albumListDefault
    }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val sharedPreferences = remember {
        context.getSharedPreferences("list_indicator_config", Context.MODE_PRIVATE)
    }
    var showAlbumIndicator by remember {
        mutableStateOf(sharedPreferences.getBoolean("show_album_indicator", false))
    }
    DisposableEffect(Unit) {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { sp, key ->
            if (key == "show_album_indicator") {
                showAlbumIndicator = sp.getBoolean("show_album_indicator", false)
            }
        }
        sharedPreferences.registerOnSharedPreferenceChangeListener(listener)
        onDispose {
            sharedPreferences.unregisterOnSharedPreferenceChangeListener(listener)
        }
    }
    val showIndicatorValue = remember(musicViewModel.showIndicatorMap[PlayListType.Albums.name]) {
        musicViewModel.showIndicatorMap.getOrDefault(PlayListType.Albums.name, false)
    }
    val enableIndicator = showAlbumIndicator && showIndicatorValue

    val (itemFilterList, itemFilterMap) = remember(albumList.size, albumList.firstOrNull()?.id, enableIndicator) {
        if (enableIndicator) generateItemFilters(albumList) { it.name } else emptyList<ItemFilterModel>() to hashMapOf()
    }
    val listStateFilter = rememberLazyListState()
    var activeSection by remember { mutableStateOf("") }

    LaunchedEffect(listState, albumList.size) {
        snapshotFlow { listState.firstVisibleItemIndex }
            .collect { index ->
                if (index in albumList.indices) {
                    val section = SortUtils.getSectionLabel(albumList[index].name)
                    activeSection = section
                    itemFilterMap[section]?.selfIndex?.let { selfIndex ->
                        if (itemFilterList.size > 28) {
                            listStateFilter.scrollToItem(selfIndex)
                        }
                    }
                }
            }
    }
    LaunchedEffect(musicViewModel.refreshAlbum.value, albumListDefault) {
        if (albumListDefault == null) {
            albumList.clear()
            val futureResult: ListenableFuture<LibraryResult<ImmutableList<MediaItem>>>? =
                musicViewModel.browser?.getChildren("albums_root", 0, Integer.MAX_VALUE, null)
            futureResult?.addListener({
                try {
                    val result: LibraryResult<ImmutableList<MediaItem>>? = futureResult.get()
                    if (result == null || result.resultCode != LibraryResult.RESULT_SUCCESS) {
                        return@addListener
                    }
                    val albumMediaItems: List<MediaItem> = result.value ?: listOf()
                    val list = ArrayList<AlbumList>()
                    albumMediaItems.forEach { mediaItem ->
                        val album = AlbumList(
                            id = MediaItemUtils.getId(mediaItem),
                            name = mediaItem.mediaMetadata.title.toString(),
                            artist = mediaItem.mediaMetadata.artist.toString(),
                            firstYear = mediaItem.mediaMetadata.extras?.getString(
                                "album_first_year",
                                ""
                            ) ?: "",
                            lastYear = mediaItem.mediaMetadata.extras?.getString(
                                "album_last_year",
                                ""
                            ) ?: "",
                            trackNumber = mediaItem.mediaMetadata.totalTrackCount ?: 0,
                        )
                        list.add(album)
                    }
                    albumList.addAll(list)
                } catch (e: Exception) {
                    // 处理在获取结果过程中可能发生的异常 (如 ExecutionException)
                    Log.e("Client", "Failed to load albums", e)
                }
            }, ContextCompat.getMainExecutor(context))
        }
    }
    if (albumList.isEmpty()) {
        Column(modifier = Modifier.fillMaxSize()) {
            Text(
                text = stringResource(R.string.there_is_no_any_album_in_here),
                Modifier.padding(start = 10.dp),
                color = MaterialTheme.colorScheme.onBackground
            )
        }
        return
    }
    val backgroundModifier = Modifier
        .background(MaterialTheme.colorScheme.background)
        .fillMaxSize()
    when (scrollDirection) {
        ScrollDirectionType.LIST_VERTICAL -> {
        }

        ScrollDirectionType.GRID_HORIZONTAL -> {
            val rowListSate = rememberLazyListState()
            val windowInfo = LocalWindowInfo.current
            val density = LocalDensity.current
            val containerWidthDp = with(density) { windowInfo.containerSize.width.toDp() }
            val width = (containerWidthDp) / 2.8f
            LazyRow(
                contentPadding = PaddingValues(5.dp),
                state = rowListSate,
                modifier = modifier.then(backgroundModifier)
            ) {
                items(
                    count = albumList.size,
                    key = { index -> albumList[index].id }) { index ->
                    val item = albumList[index]
                    AlbumItemView(
                        item,
                        musicViewModel,
                        navController,
                        modifier = Modifier
                            .padding(5.dp)
                            .width(width),
                        type = type
                    )
                }
            }
        }

        else -> {
            Box(
                modifier = modifier
                    .background(MaterialTheme.colorScheme.background)
                    .fillMaxSize()
            ) {
                LazyVerticalGrid(
                    modifier = Modifier.fillMaxSize(),
                    columns = GridCells.Adaptive(140.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(
                        top = 5.dp,
                        bottom = 5.dp,
                        start = 5.dp,
                        end = if (enableIndicator && itemFilterList.size > 1) 36.dp else 5.dp
                    ),
                    state = listState
                ) {
                    items(
                        count = albumList.size,
                        key = { index -> albumList[index].id }) { index ->
                        val item = albumList[index]
                        AlbumItemView(
                            item,
                            musicViewModel,
                            navController,
                            modifier = Modifier.padding(5.dp),
                            type = type
                        )
                    }
                }

                if (enableIndicator && itemFilterList.size > 1) {
                    AlphabetScroller(
                        itemFilterList = itemFilterList,
                        activeSection = activeSection,
                        listStateFilter = listStateFilter,
                        onSectionSelected = { targetModel ->
                            activeSection = targetModel.name
                            scope.launch {
                                listState.scrollToItem(targetModel.index)
                            }
                        },
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(top = 8.dp, bottom = 8.dp, end = 2.dp)
                    )
                }
            }
        }
        // ScrollDirectionType.GRID_VERTICAL

    }
}


@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun AlbumItemView(
    item: AlbumList,
    musicViewModel: MusicViewModel,
    navController: SnapshotStateList<Any>,
    modifier: Modifier = Modifier,
    type: PlayListType = PlayListType.Albums
) {
    val number = item.trackNumber
    val context = LocalContext.current
    var showOperateDialog by remember { mutableStateOf(false) }
    var showAddPlayListDialog by remember { mutableStateOf(false) }
    var showCreatePlayListDialog by remember { mutableStateOf(false) }
    if (showOperateDialog) {
        AlbumsOperateDialog(
            musicViewModel,
            playList = item,
            onDismiss = {
                showOperateDialog = false
                when (it) {
                    OperateType.AddToPlaylist -> {
                        showAddPlayListDialog = true
                    }

                    OperateType.ShowArtist -> {
                        DialogOperate.openArtist(
                            context, item.artist,
                            musicViewModel.navController
                        )
                    }

                    else -> {
                        Utils.operateDialogDeal(it, item, musicViewModel)
                    }
                }
            },
        )
    }
    if (showAddPlayListDialog) {
        AddMusicToPlayListDialog(musicViewModel, null, onDismiss = { playListId, removeDuplicate ->
            showAddPlayListDialog = false
            if (playListId != null) {
                if (playListId == -1L) {
                    showCreatePlayListDialog = true
                } else {
                    Utils.addTracksToPlayList(
                        playListId,
                        context,
                        type,
                        item.id,
                        musicViewModel,
                        removeDuplicate
                    )
                }
            }
        })
    }
    if (showCreatePlayListDialog) {
        CreatePlayListDialog(onDismiss = {
            showCreatePlayListDialog = false
            if (it != null) {
                Utils.createPlayListAddTracks(it, context, type, item.id, musicViewModel, false)
            }
        })
    }

    val albumCoverModel by produceState<Any>(
        initialValue = R.drawable.songs_thumbnail_cover,
        key1 = item.id
    ) {
        value = musicViewModel.getAlbumCover(item.id, context)
    }
    // 优化4: 使用 derivedStateOf 监听播放状态
    // 只有当 isPlaying 的结果真正改变时，才会触发重组，而不是每次 ViewModel 变动都重组
    val isPlaying by remember(item.id) {
        derivedStateOf {
            item.id == musicViewModel.playListCurrent.value?.id &&
                    item.type == musicViewModel.playListCurrent.value?.type
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .combinedClickable(
                onLongClick = {
                    showOperateDialog = true
                }
            ) {
                navController.add(Router.PlayListView(item))
            }) {
        // 优化5: 替换 ConstraintLayout 为 Box
        // ConstraintLayout 在简单布局中性能开销较大，Box 足以应付覆盖层
        Box(modifier = Modifier.aspectRatio(1f)) {
            // 优化6: 使用 Coil 的 AsyncImage 代替 Image + rememberAsyncImagePainter
            // 并强制设置尺寸以减少内存占用
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(albumCoverModel)
                    .crossfade(true)
                    .size(200, 200) // 限制加载图片的尺寸，极大提升滑动流畅度
                    .build(),
                contentDescription = stringResource(id = R.string.album_cover),
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentScale = ContentScale.Crop
            )
            if (isPlaying) {
                // 播放指示器
                Image(
                    painter = painterResource(R.drawable.pause),
                    contentDescription = stringResource(id = R.string.playing),
                    modifier = Modifier
                        .align(Alignment.BottomEnd) // 使用 Box 的对齐方式
                        .padding(10.dp)
                        .size(30.dp)
                        .background(color = MaterialTheme.colorScheme.primary, shape = CircleShape),
                    colorFilter = ColorFilter.tint(color = MaterialTheme.colorScheme.onPrimary)
                )
            }
        }

        Column(
            modifier = Modifier
                .padding(10.dp)
        ) {
            Text(
                text = item.name,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.horizontalScroll(rememberScrollState(0)),
                maxLines = 1 // 建议限制行数
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically // 确保垂直居中
            ) {
                Text(
                    text = stringResource(
                        R.string.song,
                        number,
                        if (number <= 1L) "" else stringResource(id = R.string.s)
                    ),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall // 建议设置具体样式
                )
                IconButton(
                    modifier = Modifier.size(24.dp), // 调整点击区域大小
                    onClick = { showOperateDialog = true }
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = stringResource(R.string.operate_more_will_open_dialog),
                        modifier = Modifier.size(20.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }


        }

    }
}

@Composable
fun AlbumsOperateDialog(
    musicViewModel: MusicViewModel,
    playList: AlbumList,
    onDismiss: (value: OperateType) -> Unit
) {

    val onConfirmation = ({
        onDismiss(OperateType.No)
    })

    val color = MaterialTheme.colorScheme.onBackground


    Dialog(
        onDismissRequest = onConfirmation,
        properties = DialogProperties(
            usePlatformDefaultWidth = true, dismissOnBackPress = true,
            dismissOnClickOutside = true
        ),
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = MaterialTheme.colorScheme.background),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    color = MaterialTheme.colorScheme.onBackground,
                    text = stringResource(id = R.string.operate), modifier = Modifier
                        .padding(2.dp)
                )
                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(color = MaterialTheme.colorScheme.onBackground)
                )
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                ) {
                    items(1) {
                        if (!(musicViewModel.playListCurrent.value?.type?.equals(playList.type) == true
                                    && musicViewModel.playListCurrent.value?.id?.equals(playList.id) == true)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .padding(0.dp)
                                    .drawBehind {
                                        drawLine(
                                            color = color,
                                            start = Offset(0f, size.height - 1.dp.toPx()),
                                            end = Offset(size.width, size.height - 1.dp.toPx()),
                                            strokeWidth = 1.dp.toPx()
                                        )
                                    }
                                    .clickable {
                                        musicViewModel.playListCurrent.value = null
                                        onDismiss(OperateType.AddToQueue)
                                    },
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = stringResource(id = R.string.add_to_queue),
                                    modifier = Modifier.padding(start = 10.dp),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .padding(0.dp)
                                    .drawBehind {
                                        drawLine(
                                            color = color,
                                            start = Offset(0f, size.height - 1.dp.toPx()),
                                            end = Offset(size.width, size.height - 1.dp.toPx()),
                                            strokeWidth = 1.dp.toPx()
                                        )
                                    }
                                    .clickable {
                                        musicViewModel.playListCurrent.value = null
                                        onDismiss(OperateType.PlayNext)
                                    },
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = stringResource(id = R.string.play_next),
                                    modifier = Modifier.padding(start = 10.dp),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .padding(0.dp)
                                .drawBehind {
                                    drawLine(
                                        color = color,
                                        start = Offset(0f, size.height - 1.dp.toPx()),
                                        end = Offset(size.width, size.height - 1.dp.toPx()),
                                        strokeWidth = 1.dp.toPx()
                                    )
                                }
                                .clickable {
                                    onDismiss(OperateType.AddToPlaylist)
                                },
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = stringResource(id = R.string.add_to_playlist),
                                modifier = Modifier.padding(start = 10.dp),
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .padding(0.dp)
                                .drawBehind {
                                    drawLine(
                                        color = color,
                                        start = Offset(0f, size.height - 1.dp.toPx()),
                                        end = Offset(size.width, size.height - 1.dp.toPx()),
                                        strokeWidth = 1.dp.toPx()
                                    )
                                }
                                .clickable {
                                    onDismiss(OperateType.ShowArtist)
                                },
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = stringResource(id = R.string.artist, playList.artist),
                                modifier = Modifier.padding(start = 10.dp),
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                ) {
                    TextButton(
                        onClick = {
                            onConfirmation()
                        },
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(),
                    ) {
                        Text(
                            stringResource(R.string.cancel),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }
        }
    )
}
