package com.ztftrue.music

import org.junit.Test
import kotlin.math.roundToInt
import com.ztftrue.music.ui.play.DualKnobHelper

import org.junit.Assert.*
import com.ztftrue.music.utils.Utils
import com.ztftrue.music.utils.SortUtils
import com.ztftrue.music.sqlData.model.MusicItem
import com.ztftrue.music.play.AudioDataRepository
import kotlin.math.exp

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun lyricsCenteringDelta_isCorrect() {
        val viewportHeight = 1000
        val targetCenter = viewportHeight / 2 // 500
        val beforeContentPadding = 500 // halfHeight

        // Case 1: Item is below center on screen
        val itemOffsetBelow = 200
        val itemSize = 60
        val itemScreenCenterBelow = itemOffsetBelow + beforeContentPadding + itemSize / 2 // 200 + 500 + 30 = 730
        val deltaBelow = (itemScreenCenterBelow - targetCenter).toFloat() // +230
        assertEquals(230f, deltaBelow, 0.001f)
        // After scrolling forward by deltaBelow (+230px, items move up):
        val newOffsetBelow = itemOffsetBelow - deltaBelow.toInt() // 200 - 230 = -30
        assertEquals(targetCenter, newOffsetBelow + beforeContentPadding + itemSize / 2) // -30 + 500 + 30 = 500 (centered!)

        // Case 2: Item is above center on screen
        val itemOffsetAbove = -300
        val itemScreenCenterAbove = itemOffsetAbove + beforeContentPadding + itemSize / 2 // -300 + 500 + 30 = 230
        val deltaAbove = (itemScreenCenterAbove - targetCenter).toFloat() // -270
        assertEquals(-270f, deltaAbove, 0.001f)
        // After scrolling backward by deltaAbove (-270px, items move down):
        val newOffsetAbove = itemOffsetAbove - deltaAbove.toInt() // -300 - (-270) = -30
        assertEquals(targetCenter, newOffsetAbove + beforeContentPadding + itemSize / 2) // -30 + 500 + 30 = 500 (centered!)

        // Case 3: Item is already exactly centered (top of item at -30px relative to content start)
        val itemOffsetCentered = -30
        val itemScreenCenter = itemOffsetCentered + beforeContentPadding + itemSize / 2 // -30 + 500 + 30 = 500
        val deltaCentered = (itemScreenCenter - targetCenter).toFloat() // 0
        assertEquals(0f, deltaCentered, 0.001f)

        // Case 4: Item 0 at list top (offset = 0)
        val item0Offset = 0
        val item0ScreenCenter = item0Offset + beforeContentPadding + itemSize / 2 // 0 + 500 + 30 = 530
        val delta0 = (item0ScreenCenter - targetCenter).toFloat() // +30
        assertEquals(30f, delta0, 0.001f)
    }

    @Test
    fun lyricsDragFraction_targetIndexCalculation() {
        val totalCaptions = 50
        val availableHeight = 800f

        // Top edge: fraction 0 -> index 0
        val fractionTop = (0f / availableHeight).coerceIn(0f, 1f)
        val indexTop = (fractionTop * (totalCaptions - 1)).roundToInt().coerceIn(0, totalCaptions - 1)
        assertEquals(0, indexTop)

        // Middle: fraction 0.5 -> 24.5 -> index 25
        val fractionMid = (400f / availableHeight).coerceIn(0f, 1f)
        val indexMid = (fractionMid * (totalCaptions - 1)).roundToInt().coerceIn(0, totalCaptions - 1)
        assertEquals(25, indexMid)

        // Bottom edge: fraction 1 -> index 49
        val fractionBottom = (800f / availableHeight).coerceIn(0f, 1f)
        val indexBottom = (fractionBottom * (totalCaptions - 1)).roundToInt().coerceIn(0, totalCaptions - 1)
        assertEquals(49, indexBottom)

        // Beyond bounds: clamped to valid range
        val fractionOver = (1200f / availableHeight).coerceIn(0f, 1f)
        val indexOver = (fractionOver * (totalCaptions - 1)).roundToInt().coerceIn(0, totalCaptions - 1)
        assertEquals(49, indexOver)

        val fractionUnder = (-200f / availableHeight).coerceIn(0f, 1f)
        val indexUnder = (fractionUnder * (totalCaptions - 1)).roundToInt().coerceIn(0, totalCaptions - 1)
        assertEquals(0, indexUnder)
    }

    @Test
    fun lyricsArrowOffset_pointedItemCalculation() {
        val viewportHeight = 1000f
        val viewportCenterY = viewportHeight / 2f // 500f
        val beforeContentPadding = 500 // halfHeight

        data class MockItem(val index: Int, val offset: Int, val size: Int) {
            val screenCenter: Float get() = offset + beforeContentPadding + size / 2f
        }

        val visibleItems = listOf(
            MockItem(index = 10, offset = -180, size = 60), // screenCenter -180 + 500 + 30 = 350
            MockItem(index = 11, offset = -110, size = 60), // screenCenter -110 + 500 + 30 = 420
            MockItem(index = 12, offset = -30, size = 60),  // screenCenter -30 + 500 + 30 = 500 (middle)
            MockItem(index = 13, offset = 40, size = 60),   // screenCenter 40 + 500 + 30 = 570
            MockItem(index = 14, offset = 110, size = 60),  // screenCenter 110 + 500 + 30 = 640
        )

        // 1. Arrow at resting position (offset = 0):
        val arrowOffsetYAtRest = 0f
        val pointedYAtRest = viewportCenterY + arrowOffsetYAtRest // 500
        val closestAtRest = visibleItems.minByOrNull { kotlin.math.abs(it.screenCenter - pointedYAtRest) }
        assertNotNull(closestAtRest)
        assertEquals(12, closestAtRest!!.index) // points to center item

        // 2. Arrow dragged upwards by 80px (offset = -80):
        val arrowOffsetYUp = -80f
        val pointedYUp = viewportCenterY + arrowOffsetYUp // 420
        val closestUp = visibleItems.minByOrNull { kotlin.math.abs(it.screenCenter - pointedYUp) }
        assertNotNull(closestUp)
        assertEquals(11, closestUp!!.index) // points to item 11

        // 3. Arrow dragged downwards by 135px (offset = +135):
        val arrowOffsetYDown = 135f
        val pointedYDown = viewportCenterY + arrowOffsetYDown // 635 (nearest 640)
        val closestDown = visibleItems.minByOrNull { kotlin.math.abs(it.screenCenter - pointedYDown) }
        assertNotNull(closestDown)
        assertEquals(14, closestDown!!.index) // points to item 14
    }

    @Test
    fun activeLyricIndex_advancementLogic() {
        data class TestCaption(val start: Long, val end: Long = 0L)

        val captions = listOf(
            TestCaption(1000L, 5000L),  // Line 0: 1s - 5s
            TestCaption(6000L, 10000L), // Line 1: 6s - 10s
            TestCaption(12000L, 15000L) // Line 2: 12s - 15s
        )

        fun getLrcIndex(time: Float): Int {
            var cIndex = 0
            for (index in captions.size - 1 downTo 0) {
                if (time >= captions[index].start) {
                    cIndex = index
                    break
                }
            }
            return cIndex
        }

        // Before first lyric (e.g. 500ms): should show line 0 (ready/intro)
        assertEquals(0, getLrcIndex(500f))

        // Right at line 0 start (1000ms)
        assertEquals(0, getLrcIndex(1000f))

        // Middle of line 0 (3000ms)
        assertEquals(0, getLrcIndex(3000f))

        // Advances to line 1 (6000ms)
        assertEquals(1, getLrcIndex(6000f))

        // During line 1 (8000ms)
        assertEquals(1, getLrcIndex(8000f))

        // Between line 1 and line 2 (11000ms): still line 1
        assertEquals(1, getLrcIndex(11000f))

        // Advances to line 2 (12000ms)
        assertEquals(2, getLrcIndex(12000f))

        // Seeking to end of song (50000ms): last line (line 2)
        assertEquals(2, getLrcIndex(50000f))
    }

    @Test
    fun lyricsSelectionDismissal_onTapElsewhere() {
        var isSelected = true
        var isToolbarShown = true
        var showMenu = false
        var selectionEpoch = 0
        var word = "test"
        var selectedTag = "test"

        val dismissAllPopupsAndSelection = {
            isToolbarShown = false
            showMenu = false
            isSelected = false
            word = ""
            selectedTag = ""
            selectionEpoch++
        }

        fun onPointerTap(distance: Float, touchSlop: Float): Boolean {
            val isPopupOpen = isToolbarShown || isSelected || showMenu
            if (!isPopupOpen) return false
            if (distance <= touchSlop) {
                dismissAllPopupsAndSelection()
                return true
            }
            return false
        }

        // 1. Text is selected, user taps elsewhere (distance = 2px, touchSlop = 8px)
        val handled = onPointerTap(distance = 2f, touchSlop = 8f)
        assertTrue(handled)
        assertFalse(isSelected)
        assertFalse(isToolbarShown)
        assertFalse(showMenu)
        assertEquals("", word)
        assertEquals("", selectedTag)
        assertEquals(1, selectionEpoch)

        // 2. Now nothing is selected, user taps again
        val handledWhenEmpty = onPointerTap(distance = 2f, touchSlop = 8f)
        assertFalse(handledWhenEmpty)
        assertEquals(1, selectionEpoch) // No unnecessary resets

        // 3. User selects a word (dictionary popup open)
        showMenu = true
        selectedTag = "word"
        word = "word"
        val handledMenu = onPointerTap(distance = 3f, touchSlop = 8f)
        assertTrue(handledMenu)
        assertFalse(showMenu)
        assertEquals("", selectedTag)
        assertEquals(2, selectionEpoch)

        // 4. User drags/scrolls (distance = 45px > touchSlop = 8px) -> should not be treated as tap dismissal
        isSelected = true
        val handledDrag = onPointerTap(distance = 45f, touchSlop = 8f)
        assertFalse(handledDrag)
        assertTrue(isSelected) // Preserved for drag / scroll handler
    }

    @Test
    fun lyricsWordTap_opensDictionaryDirectlyEvenWhenPopupOpen() {
        var isSelected = true
        var isToolbarShown = true
        var showMenu = false
        var selectedWord = ""
        var selectionEpoch = 0

        val dismissAllPopupsAndSelection = {
            isToolbarShown = false
            showMenu = false
            isSelected = false
            selectedWord = ""
            selectionEpoch++
        }

        data class MockWord(val text: String, val start: Int, val end: Int)
        val words = listOf(
            MockWord("Hello", 0, 5),
            MockWord("world", 6, 11)
        )

        fun onWordTap(charOffset: Int, isConsumed: Boolean): Boolean {
            if (isConsumed) return false
            val wordInfo = words.find { charOffset in it.start until it.end }
                ?: words.find { charOffset in it.start..it.end }
            if (wordInfo == null || wordInfo.text.trim().isEmpty()) {
                if (isToolbarShown || isSelected || showMenu) {
                    dismissAllPopupsAndSelection()
                }
                return false
            }
            // Tap on valid word: close old toolbar and immediately open dictionary popup for this word
            isToolbarShown = false
            isSelected = false
            selectedWord = wordInfo.text.trim()
            showMenu = true
            return true // consumed
        }

        // 1. Initially, selection is active. Tap on word "world" (charOffset = 8)
        val consumed = onWordTap(charOffset = 8, isConsumed = false)
        assertTrue(consumed)
        assertTrue(showMenu)
        assertEquals("world", selectedWord)
        assertFalse(isToolbarShown)
        assertFalse(isSelected)

        // 2. Now dictionary popup is open for "world". Tap directly on another word "Hello" (charOffset = 2)
        val consumedSecond = onWordTap(charOffset = 2, isConsumed = false)
        assertTrue(consumedSecond)
        assertTrue(showMenu)
        assertEquals("Hello", selectedWord)

        // 3. Tap on blank space outside words (charOffset = 20)
        val consumedBlank = onWordTap(charOffset = 20, isConsumed = false)
        assertFalse(consumedBlank)
        assertFalse(showMenu)
        assertEquals("", selectedWord)
    }

    @Test
    fun lyricsDismissal_onExternalUiTouchTrigger() {
        var isSelected = true
        var isToolbarShown = true
        var showMenu = true
        var word = "test"
        var dismissTriggerCount = 0

        fun dismissAllPopupsAndSelection() {
            isToolbarShown = false
            showMenu = false
            isSelected = false
            word = ""
        }

        fun onDismissTrigger() {
            dismissTriggerCount++
            dismissAllPopupsAndSelection()
        }

        // Top bar or bottom bar touched or tab switched -> increments trigger
        onDismissTrigger()
        assertEquals(1, dismissTriggerCount)
        assertFalse(isSelected)
        assertFalse(isToolbarShown)
        assertFalse(showMenu)
        assertEquals("", word)
    }

    @Test
    fun dualKnob_decompositionAndRanges() {
        // Value 1.15f: Big knob 1.1f, small knob range 1.10f ~ 1.19f, small offset 5
        val h115 = DualKnobHelper.toTotalHundredths(1.15f)
        assertEquals(115, h115)
        assertEquals(1.1f, DualKnobHelper.getBigValue(h115), 0.001f)
        assertEquals(1.10f, DualKnobHelper.getSmallMin(h115), 0.001f)
        assertEquals(1.19f, DualKnobHelper.getSmallMax(h115), 0.001f)
        assertEquals(5, DualKnobHelper.getSmallOffset(h115))

        // Value 1.00f: Big knob 1.0f, small knob range 1.00f ~ 1.09f, small offset 0
        val h100 = DualKnobHelper.toTotalHundredths(1.00f)
        assertEquals(100, h100)
        assertEquals(1.0f, DualKnobHelper.getBigValue(h100), 0.001f)
        assertEquals(1.00f, DualKnobHelper.getSmallMin(h100), 0.001f)
        assertEquals(1.09f, DualKnobHelper.getSmallMax(h100), 0.001f)
        assertEquals(0, DualKnobHelper.getSmallOffset(h100))

        // Value 0.50f: Big knob 0.5f, small knob range 0.50f ~ 0.59f
        val h050 = DualKnobHelper.toTotalHundredths(0.50f)
        assertEquals(50, h050)
        assertEquals(0.5f, DualKnobHelper.getBigValue(h050), 0.001f)
        assertEquals(0.50f, DualKnobHelper.getSmallMin(h050), 0.001f)
        assertEquals(0.59f, DualKnobHelper.getSmallMax(h050), 0.001f)

        // Value 2.00f: Big knob 2.0f, small knob range 2.00f ~ 2.09f
        val h200 = DualKnobHelper.toTotalHundredths(2.00f)
        assertEquals(200, h200)
        assertEquals(2.0f, DualKnobHelper.getBigValue(h200), 0.001f)
        assertEquals(2.00f, DualKnobHelper.getSmallMin(h200), 0.001f)
        assertEquals(2.09f, DualKnobHelper.getSmallMax(h200), 0.001f)
    }

    @Test
    fun dualKnob_bigKnobStepAmount() {
        // "Change the pitch and speed by sliding it to a knob, and the change amount is 0.1 each time."
        val initial = 1.15f
        val steppedUp = DualKnobHelper.stepBig(initial, 1)
        assertEquals(1.25f, steppedUp, 0.001f)
        assertEquals(0.10f, steppedUp - initial, 0.001f)

        val steppedDown = DualKnobHelper.stepBig(initial, -1)
        assertEquals(1.05f, steppedDown, 0.001f)
        assertEquals(-0.10f, steppedDown - initial, 0.001f)

        // Stepping by 2 steps (+0.2)
        val steppedTwo = DualKnobHelper.stepBig(initial, 2)
        assertEquals(1.35f, steppedTwo, 0.001f)
    }

    @Test
    fun dualKnob_smallKnobStepAmountAndRangeCoupling() {
        // "Add a small knob next to it, and the change amount is 0.01 each time.
        // But the range is limited to one decimal place after the big knob.
        // For example, if the big knob is adjusted to 1.1, the adjustment range of the small knob is 1.10~1.19."
        val initial = 1.15f

        // Step up by 0.01
        val stepUp = DualKnobHelper.stepSmall(initial, 1)
        assertEquals(1.16f, stepUp, 0.001f)
        assertEquals(0.01f, stepUp - initial, 0.001f)

        // Step down by 0.01
        val stepDown = DualKnobHelper.stepSmall(initial, -1)
        assertEquals(1.14f, stepDown, 0.001f)
        assertEquals(-0.01f, stepDown - initial, 0.001f)

        // Upper bound restriction (1.19 max when big is 1.1)
        val atMax = 1.19f
        val tryOverMax = DualKnobHelper.stepSmall(atMax, 1)
        assertEquals(1.19f, tryOverMax, 0.001f) // Strictly clamped at 1.19, cannot jump to 1.20

        // Lower bound restriction (1.10 min when big is 1.1)
        val atMin = 1.10f
        val tryUnderMin = DualKnobHelper.stepSmall(atMin, -1)
        assertEquals(1.10f, tryUnderMin, 0.001f) // Strictly clamped at 1.10, cannot drop to 1.09
    }

    @Test
    fun dualKnob_boundaryClamping() {
        // Big knob clamping at MAX (2.0f)
        val atMaxBig = 2.05f
        val overMaxBig = DualKnobHelper.stepBig(atMaxBig, 1)
        assertEquals(2.05f, overMaxBig, 0.001f)

        // Big knob clamping at MIN (0.5f)
        val atMinBig = 0.55f
        val underMinBig = DualKnobHelper.stepBig(atMinBig, -1)
        assertEquals(0.55f, underMinBig, 0.001f)
    }

    @Test
    fun dualKnob_fullRangeContinuousStepping() {
        // Verify stepping from 1.0f all the way up to 2.0f (not stuck at 1.1)
        var v = 1.00f
        val expectedUp = listOf(1.10f, 1.20f, 1.30f, 1.40f, 1.50f, 1.60f, 1.70f, 1.80f, 1.90f, 2.00f)
        for (expected in expectedUp) {
            v = DualKnobHelper.stepBig(v, 1)
            assertEquals(expected, v, 0.001f)
        }
        // Further stepping up stays clamped at 2.00f
        v = DualKnobHelper.stepBig(v, 1)
        assertEquals(2.00f, v, 0.001f)

        // Verify stepping from 2.0f all the way down to 0.5f (not stuck at 0.9)
        val expectedDown = listOf(
            1.90f, 1.80f, 1.70f, 1.60f, 1.50f, 1.40f, 1.30f, 1.20f, 1.10f,
            1.00f, 0.90f, 0.80f, 0.70f, 0.60f, 0.50f
        )
        for (expected in expectedDown) {
            v = DualKnobHelper.stepBig(v, -1)
            assertEquals(expected, v, 0.001f)
        }
        // Further stepping down stays clamped at 0.50f
        v = DualKnobHelper.stepBig(v, -1)
        assertEquals(0.50f, v, 0.001f)
    }

    @Test
    fun fineSlider_stepCalculationsAndResolution() {
        // Coarse slider: range 0.5f..2.0f, steps = 14
        val coarseMin = 0.5f
        val coarseMax = 2.0f
        val coarseSteps = 14
        val coarseInterval = (coarseMax - coarseMin) / (coarseSteps + 1)
        assertEquals(0.1f, coarseInterval, 0.0001f)

        // Fine slider: range smallMin..smallMax (span 0.09f), steps = 8
        val fineSteps = 8
        for (tenths in 5..20) {
            val totalHundredths = tenths * 10
            val smallMin = DualKnobHelper.getSmallMin(totalHundredths)
            val smallMax = DualKnobHelper.getSmallMax(totalHundredths)
            val fineSpan = smallMax - smallMin
            assertEquals(0.09f, fineSpan, 0.0001f)

            val fineInterval = fineSpan / (fineSteps + 1)
            assertEquals(0.01f, fineInterval, 0.0001f)

            // Verify all 10 discrete steps from 0 to 9 hundredths
            for (step in 0..9) {
                val stepVal = (smallMin + step * fineInterval)
                val rounded = (stepVal * 100f).roundToInt() / 100f
                val expected = (tenths * 10 + step) / 100f
                assertEquals(expected, rounded, 0.0001f)
            }
        }
    }

    @Test
    fun fineSlider_rangeCouplingWithCoarseTenths() {
        // For coarse = 1.1x -> range is 1.10 ~ 1.19
        val h11 = DualKnobHelper.toTotalHundredths(1.1f)
        assertEquals(1.10f, DualKnobHelper.getSmallMin(h11), 0.0001f)
        assertEquals(1.19f, DualKnobHelper.getSmallMax(h11), 0.0001f)

        // For coarse = 0.5x -> range is 0.50 ~ 0.59
        val h05 = DualKnobHelper.toTotalHundredths(0.5f)
        assertEquals(0.50f, DualKnobHelper.getSmallMin(h05), 0.0001f)
        assertEquals(0.59f, DualKnobHelper.getSmallMax(h05), 0.0001f)

        // For coarse = 2.0x -> range is 2.00 ~ 2.09
        val h20 = DualKnobHelper.toTotalHundredths(2.0f)
        assertEquals(2.00f, DualKnobHelper.getSmallMin(h20), 0.0001f)
        assertEquals(2.09f, DualKnobHelper.getSmallMax(h20), 0.0001f)
    }

    @Test
    fun fineSlider_coarseOffsetRetention() {
        // When fine-tuning is enabled: coarse slider movement preserves the fine hundredths offset
        val initialPitch = 1.15f
        val pitchHundredths = DualKnobHelper.toTotalHundredths(initialPitch)
        val offset = DualKnobHelper.getSmallOffset(pitchHundredths)
        assertEquals(5, offset)

        // Drag coarse to 1.3:
        val targetCoarse = 1.3f
        val newBigTenths = (targetCoarse * 10f).roundToInt()
        val fineActiveNewPitch = (newBigTenths * 10 + offset) / 100f
        assertEquals(1.35f, fineActiveNewPitch, 0.0001f)

        // When fine-tuning is disabled: coarse slider snaps to tenths
        val fineInactiveNewPitch = newBigTenths / 10f
        assertEquals(1.30f, fineInactiveNewPitch, 0.0001f)
    }

    @Test
    fun visualizer_columnAndBandCalculations() {
        // Test column count calculation for various screen widths and column spacings
        val columnSpacing = 20f
        val portraitWidth = 1080f
        val portraitCols = maxOf(1, (portraitWidth / columnSpacing).toInt())
        assertEquals(54, portraitCols)

        val landscapeWidth = 2400f
        val landscapeCols = maxOf(1, (landscapeWidth / columnSpacing).toInt())
        assertEquals(120, landscapeCols)

        // Frequency band mapping for Matrix columns: 32 FFT frequency bands
        val freqBands = IntArray(landscapeCols) { c ->
            ((c.toFloat() / landscapeCols) * 32).toInt().coerceIn(0, 31)
        }
        // First column maps to band 0 (sub-bass)
        assertEquals(0, freqBands[0])
        // Last column maps to band 31 (high treble)
        assertEquals(31, freqBands[landscapeCols - 1])
        // Mid column maps to band 16 (midrange)
        assertEquals(16, freqBands[landscapeCols / 2])
    }

    @Test
    fun visualizer_spectrumPeakHoldPhysics() {
        // Physics verification of peak-hold dot behavior
        var smoothed = 0f
        var peak = 0f
        val smoothingFactor = 0.3f
        val gravity = 0.02f

        // Audio beat hits with high magnitude (0.8f)
        val hitEnergy = 0.8f
        smoothed += (hitEnergy - smoothed) * smoothingFactor
        if (smoothed > peak) peak = smoothed
        assertEquals(0.24f, smoothed, 0.001f)
        assertEquals(0.24f, peak, 0.001f)

        // Next frame, audio drops to silence
        smoothed += (0f - smoothed) * smoothingFactor
        peak = maxOf(smoothed, peak - gravity)
        assertEquals(0.168f, smoothed, 0.001f)
        assertEquals(0.22f, peak, 0.001f) // peak stayed higher than current bar, falling slowly with gravity
        assertTrue(peak > smoothed)
    }

    @Test
    fun audioDataRepository_zeroAllocationAndThreadSafety() {
        val testData = FloatArray(32) { (it + 1) * 0.03f }
        AudioDataRepository.postVisualizationData(testData)

        val destination = FloatArray(32)
        val success = AudioDataRepository.getLatestVisualizationData(destination)
        assertTrue("getLatestVisualizationData should return true when data is available", success)
        for (i in 0 until 32) {
            assertEquals("Band $i should match posted data", testData[i], destination[i], 0.0001f)
        }

        // Test clear
        AudioDataRepository.clearVisualizationData()
        val destAfterClear = FloatArray(32) { 1.0f }
        val successAfterClear = AudioDataRepository.getLatestVisualizationData(destAfterClear)
        assertFalse("getLatestVisualizationData should return false after clear", successAfterClear)
    }

    @Test
    fun audioDataRepository_staleDataExpiration() {
        val testData = FloatArray(32) { 0.5f }
        AudioDataRepository.postVisualizationData(testData)
        val destination = FloatArray(32)
        assertTrue(AudioDataRepository.getLatestVisualizationData(destination))

        // Wait for data to become stale (> 250ms)
        Thread.sleep(280)
        val successStale = AudioDataRepository.getLatestVisualizationData(destination)
        assertFalse("getLatestVisualizationData should return false when data is older than 250ms", successStale)
        assertEquals(0f, destination[0], 0.0001f)
    }

    @Test
    fun spectrumVisualizer_physics_smoothAttackAndPeakHold() {
        // Test exponential attack: A sudden impulse from 0.0 to 1.0 should NOT teleport to 1.0 in 1 frame
        var currentHeight = 0.0f
        val target = 1.0f
        val dt = 0.016f // 60 FPS frame (~16ms)

        val diff = target - currentHeight
        val attackSpeed = if (diff > 0.25f) 42f else 30f
        val attack = 1f - exp(-attackSpeed * dt)
        currentHeight += diff * attack

        // First frame should rise substantially (> 40%) but NOT teleport to 100% (eliminating stutter/jitter)
        assertTrue("First frame should be smoothly interpolated (> 0.40)", currentHeight > 0.40f)
        assertTrue("First frame should not snap instantly to 1.0 (< 0.85)", currentHeight < 0.85f)

        // Test peak hold duration: Peak must not fall while holdTimer > 0
        var peakHeight = 1.0f
        var peakVelocity = 0.0f
        var peakHoldTimer = 0.30f // 300ms hold timer

        // Simulate 5 frames of decay (80ms elapsed, hold timer still active)
        for (frame in 0 until 5) {
            currentHeight = maxOf(0f, currentHeight * exp(-4.2f * dt) - dt * 0.12f)
            if (currentHeight >= peakHeight) {
                peakHeight = currentHeight
                peakVelocity = 0f
                peakHoldTimer = 0.30f
            } else {
                if (peakHoldTimer > 0f) {
                    peakHoldTimer -= dt
                } else {
                    peakVelocity += dt * 3.6f
                    peakHeight = maxOf(0f, peakHeight - peakVelocity * dt)
                }
            }
            // During hold, peak stays exactly at 1.0f
            assertEquals("Peak should remain held at top during hold duration", 1.0f, peakHeight, 0.0001f)
        }
        assertTrue("Hold timer should still be positive after 80ms", peakHoldTimer > 0f)
    }

    @Test
    fun matrixRain_speedTracksFrequency() {
        val idleSpeed = 22f
        val peakSpeedBass = 680f
        val peakSpeedTreble = 880f

        fun computeSpeed(energy: Float, freqRatio: Float): Float {
            val peakSpeed = 680f + freqRatio * 200f
            val speedFactor = energy * energy * 0.35f + energy * 0.65f
            return idleSpeed + (peakSpeed - idleSpeed) * speedFactor
        }

        // 1. When silent, speed is idleSpeed
        val silentSpeed = computeSpeed(0.0f, 0.0f)
        assertEquals(22f, silentSpeed, 0.001f)

        // 2. Monotonic speed response: louder frequency band moves strictly faster
        val quietSpeed = computeSpeed(0.2f, 0.5f)
        val mediumSpeed = computeSpeed(0.5f, 0.5f)
        val loudSpeed = computeSpeed(0.8f, 0.5f)
        val peakSpeed = computeSpeed(1.0f, 0.5f)
        assertTrue(quietSpeed > silentSpeed)
        assertTrue(mediumSpeed > quietSpeed)
        assertTrue(loudSpeed > mediumSpeed)
        assertTrue(peakSpeed > loudSpeed)

        // 3. Peak speeds track frequency range:
        val bassPeak = computeSpeed(1.0f, 0.0f)
        val treblePeak = computeSpeed(1.0f, 1.0f)
        assertEquals(peakSpeedBass, bassPeak, 0.001f)
        assertEquals(peakSpeedTreble, treblePeak, 0.001f)
        assertTrue(treblePeak > bassPeak)

        // 4. Trail length (wavelength) tracks frequency inversely:
        // Bass columns have longer trails, treble columns have shorter crisp trails
        fun maxTrailForCol(freqRatio: Float): Int = (28 - freqRatio * 14).toInt()
        val bassTrailLen = maxTrailForCol(0.0f)
        val trebleTrailLen = maxTrailForCol(1.0f)
        assertEquals(28, bassTrailLen)
        assertEquals(14, trebleTrailLen)
        assertTrue(bassTrailLen > trebleTrailLen)
    }

    @Test
    fun exceptionFilter_identifiesHarmlessServiceUnbindException() {
        fun isHarmlessServiceUnbindException(e: Throwable): Boolean {
            var current: Throwable? = e
            while (current != null) {
                val msg = current.message ?: ""
                if (current is IllegalArgumentException && msg.contains("Service not registered")) {
                    return true
                }
                current = current.cause
            }
            return false
        }

        // Exact exception reported by user
        val userException = IllegalArgumentException(
            "Service not registered: androidx.media3.session.MediaControllerImplBase\$SessionServiceConnection@2a2f222"
        )
        assertTrue(isHarmlessServiceUnbindException(userException))

        // Wrapped in RuntimeException
        val wrappedException = RuntimeException("Wrapper", userException)
        assertTrue(isHarmlessServiceUnbindException(wrappedException))

        // Unrelated IllegalArgumentException should NOT be filtered
        val otherArgException = IllegalArgumentException("Invalid slider value: -1")
        assertFalse(isHarmlessServiceUnbindException(otherArgException))

        // Null pointer exception should NOT be filtered
        val npe = NullPointerException("Track item is null")
        assertFalse(isHarmlessServiceUnbindException(npe))
    }

    @Test
    fun audioPathHelper_formatsFormatNameCorrectly() {
        assertEquals("FLAC", com.ztftrue.music.utils.AudioPathHelper.formatFormatName("audio/flac", "/storage/test.flac", "FLAC 24 bits"))
        assertEquals("MP3", com.ztftrue.music.utils.AudioPathHelper.formatFormatName("audio/mpeg", "/storage/test.mp3", "MPEG-1 Layer 3"))
        assertEquals("AAC", com.ztftrue.music.utils.AudioPathHelper.formatFormatName("audio/mp4a-latm", "/storage/test.m4a", null))
        assertEquals("OPUS", com.ztftrue.music.utils.AudioPathHelper.formatFormatName("audio/opus", "/storage/test.opus", null))
        assertEquals("OGG", com.ztftrue.music.utils.AudioPathHelper.formatFormatName("audio/vorbis", "/storage/test.ogg", null))
        assertEquals("WAV", com.ztftrue.music.utils.AudioPathHelper.formatFormatName("audio/raw", "/storage/test.wav", null))
        assertEquals("DSD", com.ztftrue.music.utils.AudioPathHelper.formatFormatName(null, "/storage/test.dsf", null))
    }

    @Test
    fun audioPathHelper_resolvesDecoderNameCorrectly() {
        assertEquals("c2.android.flac.decoder", com.ztftrue.music.utils.AudioPathHelper.resolveDecoderName("audio/flac", "FLAC"))
        assertEquals("c2.android.mp3.decoder", com.ztftrue.music.utils.AudioPathHelper.resolveDecoderName("audio/mpeg", "MP3"))
        assertEquals("c2.android.aac.decoder", com.ztftrue.music.utils.AudioPathHelper.resolveDecoderName("audio/mp4a-latm", "AAC"))
        assertEquals("c2.android.opus.decoder", com.ztftrue.music.utils.AudioPathHelper.resolveDecoderName("audio/opus", "OPUS"))
        assertEquals("c2.android.vorbis.decoder", com.ztftrue.music.utils.AudioPathHelper.resolveDecoderName("audio/vorbis", "OGG"))
    }

    @Test
    fun audioPathHelper_formatsChannelsCorrectly() {
        assertEquals("1 (Mono)", com.ztftrue.music.utils.AudioPathHelper.formatChannels(1))
        assertEquals("2 (Stereo)", com.ztftrue.music.utils.AudioPathHelper.formatChannels(2))
        assertEquals("6 (5.1 Surround)", com.ztftrue.music.utils.AudioPathHelper.formatChannels(6))
        assertEquals("8 (7.1 Surround)", com.ztftrue.music.utils.AudioPathHelper.formatChannels(8))
    }

    @Test
    fun audioPathHelper_formatsBitrateCorrectly() {
        assertEquals("320 kbps", com.ztftrue.music.utils.AudioPathHelper.formatBitrate(320000L, null))
        assertEquals("2812 kbps", com.ztftrue.music.utils.AudioPathHelper.formatBitrate(2812000L, null))
        assertEquals("—", com.ztftrue.music.utils.AudioPathHelper.formatBitrate(0L, null))
        assertEquals("256 kbps", com.ztftrue.music.utils.AudioPathHelper.formatBitrate(-1L, "256"))
    }

    @Test
    fun audioPathHelper_formatsBitDepthCorrectly() {
        assertEquals("24-bit", com.ztftrue.music.utils.AudioPathHelper.formatBitDepth("24-bit", "FLAC", null))
        assertEquals("24-bit", com.ztftrue.music.utils.AudioPathHelper.formatBitDepth(null, "FLAC", null))
        assertEquals("16-bit", com.ztftrue.music.utils.AudioPathHelper.formatBitDepth(null, "MP3", null))
        assertEquals("32-bit Float", com.ztftrue.music.utils.AudioPathHelper.formatBitDepth(null, "WAV", "32-bit Float"))
    }

    @Test
    fun audioPathHelper_calculatesBuffersCorrectly() {
        assertEquals("2x (120ms, 11520 frames)", com.ztftrue.music.utils.AudioPathHelper.calculateBuffers(96000))
        assertEquals("2x (120ms, 5760 frames)", com.ztftrue.music.utils.AudioPathHelper.calculateBuffers(48000))
        assertEquals("2x (120ms, 5292 frames)", com.ztftrue.music.utils.AudioPathHelper.calculateBuffers(44100))
    }

    @Test
    fun auxr_defaultValuesAndEquality() {
        val auxr = com.ztftrue.music.sqlData.model.Auxr(
            id = 0,
            speed = 1f,
            pitch = 1f,
            echo = false,
            echoDelay = 0.2f,
            echoDecay = 0.5f,
            echoRevert = true,
            equalizer = false,
            equalizerBand = IntArray(10),
            equalizerQ = com.ztftrue.music.utils.Utils.Q,
            virtualizerEnabled = false,
            virtualizerStrength = 0,
            bassBoostEnabled = false,
            bassBoostStrength = 0,
            equalizerType = 0,
            selectedPreset = com.ztftrue.music.utils.Utils.custom,
            showPitchFine = false,
            showSpeedFine = false,
            delayEnabled = false,
            delayTime = 0.35f,
            delayFeedback = 0.4f,
            delayMix = 0.4f,
            reverbEnabled = false,
            reverbRoomSize = 0.5f,
            reverbDamping = 0.5f,
            reverbMix = 0.3f,
            chorusEnabled = false,
            chorusRate = 1.5f,
            chorusDepth = 0.5f,
            chorusMix = 0.5f,
            flangerEnabled = false,
            flangerRate = 0.5f,
            flangerDepth = 0.7f,
            flangerFeedback = 0.5f,
            flangerMix = 0.5f,
            polyphonyEnabled = false,
            polyphonySemitones = 0,
            polyphonyDetune = 0.0f,
            polyphonyMix = 0.5f
        )

        // Verify Equalizer defaults
        assertEquals(0, auxr.equalizerType)
        assertEquals("Custom", auxr.selectedPreset)
        assertEquals(false, auxr.equalizer)
        assertEquals(10, auxr.equalizerBand.size)

        // Verify Effect fine-tuning defaults
        assertEquals(false, auxr.showPitchFine)
        assertEquals(false, auxr.showSpeedFine)

        // Verify Advanced Effects defaults
        assertEquals(false, auxr.delayEnabled)
        assertEquals(0.35f, auxr.delayTime, 0.001f)
        assertEquals(0.4f, auxr.delayFeedback, 0.001f)
        assertEquals(0.4f, auxr.delayMix, 0.001f)

        assertEquals(false, auxr.reverbEnabled)
        assertEquals(0.5f, auxr.reverbRoomSize, 0.001f)
        assertEquals(0.5f, auxr.reverbDamping, 0.001f)
        assertEquals(0.3f, auxr.reverbMix, 0.001f)

        assertEquals(false, auxr.chorusEnabled)
        assertEquals(1.5f, auxr.chorusRate, 0.001f)
        assertEquals(0.5f, auxr.chorusDepth, 0.001f)
        assertEquals(0.5f, auxr.chorusMix, 0.001f)

        assertEquals(false, auxr.flangerEnabled)
        assertEquals(0.5f, auxr.flangerRate, 0.001f)
        assertEquals(0.7f, auxr.flangerDepth, 0.001f)
        assertEquals(0.5f, auxr.flangerFeedback, 0.001f)
        assertEquals(0.5f, auxr.flangerMix, 0.001f)

        assertEquals(false, auxr.polyphonyEnabled)
        assertEquals(0, auxr.polyphonySemitones)
        assertEquals(0.0f, auxr.polyphonyDetune, 0.001f)
        assertEquals(0.5f, auxr.polyphonyMix, 0.001f)

        // Verify Bass Boost defaults
        assertEquals(false, auxr.bassBoostEnabled)
        assertEquals(0, auxr.bassBoostStrength)

        // Verify equality and hash code
        val auxrCopy = auxr.copy(equalizerBand = auxr.equalizerBand.clone())
        assertEquals(auxr, auxrCopy)
        assertEquals(auxr.hashCode(), auxrCopy.hashCode())

        // Mutate fields and verify inequality
        auxrCopy.bassBoostEnabled = true
        assertNotEquals(auxr, auxrCopy)
        auxrCopy.bassBoostEnabled = false

        auxrCopy.bassBoostStrength = 500
        assertNotEquals(auxr, auxrCopy)
        auxrCopy.bassBoostStrength = 0

        auxrCopy.reverbEnabled = true
        assertNotEquals(auxr, auxrCopy)
        auxrCopy.reverbEnabled = false

        auxrCopy.selectedPreset = "Rock"
        assertNotEquals(auxr, auxrCopy)
        auxrCopy.selectedPreset = "Custom"

        auxrCopy.equalizerType = 1
        assertNotEquals(auxr, auxrCopy)
    }

    @Test
    fun bassBoost_scalingAndBiquadCoefficients() {
        // Test strength mapping: 0 to 1000 maps to 0.0 to 1.0, and 0.0 to +15.0 dB
        fun strengthToGainDb(strengthInt: Int): Float {
            val strengthNorm = (strengthInt / 1000f).coerceIn(0f, 1f)
            return strengthNorm * 15.0f
        }

        assertEquals(0.0f, strengthToGainDb(0), 0.001f)
        assertEquals(7.5f, strengthToGainDb(500), 0.001f)
        assertEquals(15.0f, strengthToGainDb(1000), 0.001f)
        assertEquals(0.0f, strengthToGainDb(-50), 0.001f)
        assertEquals(15.0f, strengthToGainDb(1500), 0.001f)

        // RBJ Low-Shelf coefficients verification for 90 Hz at 44.1 kHz, Q = 0.7071
        val sampleRate = 44100.0f
        val f0 = 90.0f
        val q = 0.7071f
        val gainDb = 12.0f
        val a = Math.pow(10.0, (gainDb / 40.0)).toFloat()
        val omega = (2.0 * Math.PI * f0 / sampleRate).toFloat()
        val sn = Math.sin(omega.toDouble()).toFloat()
        val cs = Math.cos(omega.toDouble()).toFloat()
        val alpha = sn / (2.0f * q)
        val beta = 2.0f * Math.sqrt(a.toDouble()).toFloat() * alpha

        val a0 = (a + 1.0f) + (a - 1.0f) * cs + beta
        val b0 = (a * ((a + 1.0f) - (a - 1.0f) * cs + beta)) / a0
        val b1 = (2.0f * a * ((a - 1.0f) - (a + 1.0f) * cs)) / a0
        val b2 = (a * ((a + 1.0f) - (a - 1.0f) * cs - beta)) / a0
        val a1 = (-2.0f * ((a - 1.0f) + (a + 1.0f) * cs)) / a0
        val a2 = ((a + 1.0f) + (a - 1.0f) * cs - beta) / a0

        // Filter must be stable: |a2| < 1, |a1| < 1 + a2
        assertTrue("Biquad filter must be stable: |a2| < 1", Math.abs(a2) < 1.0f)
        assertTrue("Biquad filter must be stable: |a1| < 1 + a2", Math.abs(a1) < (1.0f + a2))

        // DC gain (omega = 0, z = 1): H(1) = (b0 + b1 + b2) / (1 + a1 + a2)
        val dcGainLinear = (b0 + b1 + b2) / (1.0f + a1 + a2)
        val expectedDcGainLinear = Math.pow(10.0, (gainDb / 20.0)).toFloat()
        assertEquals(expectedDcGainLinear, dcGainLinear, 0.01f)

        // High-frequency gain (omega = pi, z = -1): H(-1) = (b0 - b1 + b2) / (1 - a1 + a2) should be 1.0 (0 dB)
        val hfGainLinear = (b0 - b1 + b2) / (1.0f - a1 + a2)
        assertEquals(1.0f, hfGainLinear, 0.01f)
    }

    @Test
    fun playConfig_trackEffectEnabledDefaultAndMutation() {
        val config = com.ztftrue.music.sqlData.model.PlayConfig(id = 1, repeatModel = 0)
        assertEquals(false, config.trackEffectEnabled)

        val configCopy = config.copy()
        assertEquals(config, configCopy)
        assertEquals(config.hashCode(), configCopy.hashCode())

        configCopy.trackEffectEnabled = true
        assertNotEquals(config, configCopy)
        assertNotEquals(config.hashCode(), configCopy.hashCode())
    }

    @Test
    fun playConfig_repeatModeUpdatePreservesTrackEffect() {
        // Simulates PlayService.onRepeatModeChanged
        val initialConfig = com.ztftrue.music.sqlData.model.PlayConfig(id = 0, repeatModel = 0, trackEffectEnabled = true)
        val newRepeatMode = 2 // Player.REPEAT_MODE_ONE

        // Update repeat mode while preserving trackEffectEnabled
        val updatedConfig = com.ztftrue.music.sqlData.model.PlayConfig(
            id = 0,
            repeatModel = newRepeatMode,
            trackEffectEnabled = initialConfig.trackEffectEnabled
        )

        assertEquals(0, updatedConfig.id)
        assertEquals(newRepeatMode, updatedConfig.repeatModel)
        assertTrue(updatedConfig.trackEffectEnabled)
    }

    @Test
    fun trackEffectEnabled_firstCheckBeforeReadingAux() {
        val globalAux = com.ztftrue.music.play.manager.AudioEffectManager.createDefaultAuxr(0L).copy(
            selectedPreset = "GlobalPreset",
            equalizer = true
        )
        val trackAux = com.ztftrue.music.play.manager.AudioEffectManager.createDefaultAuxr(100L).copy(
            selectedPreset = "TrackPreset",
            equalizer = false
        )

        // Case 1: trackEffectEnabled == true -> must load trackAux
        val trackEffectEnabled = true
        val currentTrackId = 100L
        val loadedAux1 = if (trackEffectEnabled && currentTrackId > 0) {
            trackAux
        } else {
            globalAux
        }
        assertEquals("TrackPreset", loadedAux1.selectedPreset)
        assertEquals(100L, loadedAux1.id)
        assertFalse(loadedAux1.equalizer)

        // Case 2: trackEffectEnabled == false -> must load globalAux
        val trackEffectDisabled = false
        val loadedAux2 = if (trackEffectDisabled && currentTrackId > 0) {
            trackAux
        } else {
            globalAux
        }
        assertEquals("GlobalPreset", loadedAux2.selectedPreset)
        assertEquals(0L, loadedAux2.id)
        assertTrue(loadedAux2.equalizer)
    }

    @Test
    fun auxr_perTrackCloningAndIsolation() {
        val globalAuxr = com.ztftrue.music.sqlData.model.Auxr(
            id = 0L,
            speed = 1f,
            pitch = 1f,
            echo = false,
            echoDelay = 0.2f,
            echoDecay = 0.5f,
            echoRevert = true,
            equalizer = false,
            equalizerBand = IntArray(10),
            equalizerQ = Utils.Q,
            selectedPreset = "Jazz"
        )
        // Clone for track 1001
        val track1001 = globalAuxr.copy(id = 1001L, equalizerBand = globalAuxr.equalizerBand.clone())
        assertEquals(1001L, track1001.id)
        assertEquals("Jazz", track1001.selectedPreset)

        // Modify track 1001 - global should remain untouched
        track1001.selectedPreset = "Rock"
        track1001.equalizerBand[0] = 5
        assertEquals("Rock", track1001.selectedPreset)
        assertEquals(5, track1001.equalizerBand[0])
        assertEquals("Jazz", globalAuxr.selectedPreset)
        assertEquals(0, globalAuxr.equalizerBand[0])
    }

    @Test
    fun audioEffectManager_createDefaultAuxr_hasProperDefaults() {
        val defaultAux = com.ztftrue.music.play.manager.AudioEffectManager.createDefaultAuxr(42L)
        assertEquals(42L, defaultAux.id)
        assertEquals(1f, defaultAux.speed, 0.001f)
        assertEquals(1f, defaultAux.pitch, 0.001f)
        assertFalse(defaultAux.equalizer)
        assertEquals(Utils.custom, defaultAux.selectedPreset)
        assertEquals(10, defaultAux.equalizerBand.size)
        assertTrue(defaultAux.equalizerBand.all { it == 0 })
        assertFalse(defaultAux.reverbEnabled)
        assertFalse(defaultAux.delayEnabled)
        assertFalse(defaultAux.echo)
        assertFalse(defaultAux.chorusEnabled)
        assertFalse(defaultAux.flangerEnabled)
        assertFalse(defaultAux.polyphonyEnabled)
        assertFalse(defaultAux.virtualizerEnabled)
    }

    @Test
    fun scanMode_constantsAndLogic() {
        assertEquals(0, com.ztftrue.music.utils.SharedPreferencesUtils.SCAN_MODE_ALL)
        assertEquals(1, com.ztftrue.music.utils.SharedPreferencesUtils.SCAN_MODE_FOLDER)
    }

    @Test
    fun exclusiveFolder_pathFilteringLogic() {
        val exclusiveFolder = "/storage/emulated/0/Music/Favorites"
        val normalized = exclusiveFolder.trimEnd('/')

        fun isTrackInFolder(filePath: String): Boolean {
            val itemDir = filePath.substringBeforeLast('/', "")
            return filePath.startsWith("$normalized/", ignoreCase = true) ||
                    itemDir.equals(normalized, ignoreCase = true)
        }

        // Direct child in folder
        assertTrue(isTrackInFolder("/storage/emulated/0/Music/Favorites/song.mp3"))
        // Nested subfolder
        assertTrue(isTrackInFolder("/storage/emulated/0/Music/Favorites/Rock/song.flac"))
        assertTrue(isTrackInFolder("/storage/emulated/0/Music/Favorites/Pop/2023/album/track.m4a"))
        // Case insensitive
        assertTrue(isTrackInFolder("/storage/emulated/0/music/favorites/song.mp3"))

        // Outside folder - completely different directory
        assertFalse(isTrackInFolder("/storage/emulated/0/Download/song.mp3"))
        assertFalse(isTrackInFolder("/storage/emulated/0/Podcasts/episode.mp3"))

        // Prefix collision: "Favorites" vs "FavoritesOther"
        assertFalse(isTrackInFolder("/storage/emulated/0/Music/FavoritesOther/song.mp3"))

        // Parent folder of the exclusive directory
        assertFalse(isTrackInFolder("/storage/emulated/0/Music/song.mp3"))
    }

    @Test
    fun pathResolution_primaryAndSdCardDocIds() {
        fun resolveDocId(docId: String, primaryDir: String, volumes: Map<String, String>): String? {
            val split = docId.split(":")
            val type = split[0]
            val relativePath = if (split.size > 1) split[1] else ""
            return if ("primary".equals(type, ignoreCase = true)) {
                if (relativePath.isNotEmpty()) "$primaryDir/$relativePath" else primaryDir
            } else {
                val volumePath = volumes[type]
                if (volumePath != null) {
                    if (relativePath.isNotEmpty()) "$volumePath/$relativePath" else volumePath
                } else {
                    if (relativePath.isNotEmpty()) "/storage/$type/$relativePath" else "/storage/$type"
                }
            }
        }

        val primaryStorage = "/storage/emulated/0"
        val sdVolumes = mapOf("1234-5678" to "/storage/1234-5678")

        // Primary storage music folder
        assertEquals("/storage/emulated/0/Music", resolveDocId("primary:Music", primaryStorage, sdVolumes))
        assertEquals("/storage/emulated/0/Music/Sub/song.mp3", resolveDocId("primary:Music/Sub/song.mp3", primaryStorage, sdVolumes))
        assertEquals("/storage/emulated/0", resolveDocId("primary:", primaryStorage, sdVolumes))

        // SD card music folder
        assertEquals("/storage/1234-5678/MyMusic", resolveDocId("1234-5678:MyMusic", primaryStorage, sdVolumes))
        assertEquals("/storage/1234-5678/MyMusic/song.flac", resolveDocId("1234-5678:MyMusic/song.flac", primaryStorage, sdVolumes))
    }

    @Test
    fun filterFolder_jsonSerialization() {
        val gson = com.google.gson.Gson()
        val type = object : com.google.gson.reflect.TypeToken<List<com.ztftrue.music.sqlData.model.FilterFolder>>() {}.type
        val originalList = listOf(
            com.ztftrue.music.sqlData.model.FilterFolder(
                id = "id-1",
                uri = "content://com.android.externalstorage.documents/tree/primary%3AMusic",
                path = "/storage/emulated/0/Music",
                name = "Music"
            ),
            com.ztftrue.music.sqlData.model.FilterFolder(
                id = "id-2",
                uri = null,
                path = "/storage/1234-5678/Audio",
                name = "Audio"
            )
        )

        val json = gson.toJson(originalList)
        assertNotNull(json)
        val deserialized: List<com.ztftrue.music.sqlData.model.FilterFolder> = gson.fromJson(json, type)
        assertEquals(2, deserialized.size)
        assertEquals("id-1", deserialized[0].id)
        assertEquals("/storage/emulated/0/Music", deserialized[0].path)
        assertEquals("Music", deserialized[0].name)
        assertEquals("id-2", deserialized[1].id)
        assertNull(deserialized[1].uri)
        assertEquals("/storage/1234-5678/Audio", deserialized[1].path)
    }

    @Test
    fun whitelistMode_multiFolderFilteringLogic() {
        val whitelistFolders = listOf(
            "/storage/emulated/0/Music",
            "/storage/1234-5678/Audio"
        ).map { it.trimEnd('/') }

        fun isTrackAllowed(trackPath: String, whitelist: List<String>): Boolean {
            if (whitelist.isEmpty()) return false
            return whitelist.any { folder ->
                trackPath.startsWith("$folder/", ignoreCase = true) ||
                trackPath.substringBeforeLast('/', "").equals(folder, ignoreCase = true)
            }
        }

        // Whitelisted folder 1
        assertTrue(isTrackAllowed("/storage/emulated/0/Music/song.mp3", whitelistFolders))
        assertTrue(isTrackAllowed("/storage/emulated/0/Music/Rock/track.flac", whitelistFolders))
        assertTrue(isTrackAllowed("/storage/emulated/0/Music/A/B/C/track.ogg", whitelistFolders))

        // Whitelisted folder 2 (SD card)
        assertTrue(isTrackAllowed("/storage/1234-5678/Audio/song.wav", whitelistFolders))
        assertTrue(isTrackAllowed("/storage/1234-5678/Audio/Classical/symphony.mp3", whitelistFolders))

        // Non-whitelisted paths
        assertFalse(isTrackAllowed("/storage/emulated/0/Download/song.mp3", whitelistFolders))
        assertFalse(isTrackAllowed("/storage/emulated/0/Ringtones/alarm.mp3", whitelistFolders))
        assertFalse(isTrackAllowed("/storage/emulated/0/MusicVideo/song.mp3", whitelistFolders))

        // Empty whitelist should disallow everything
        assertFalse(isTrackAllowed("/storage/emulated/0/Music/song.mp3", emptyList()))
    }

    @Test
    fun blacklistMode_multiFolderFilteringLogic() {
        val blacklistFolders = listOf(
            "/storage/emulated/0/Ringtones",
            "/storage/emulated/0/Android/data"
        ).map { it.trimEnd('/') }
        val ignoredBucketIds = setOf(9999L)

        fun isTrackExcluded(trackPath: String, bucketId: Long, blacklist: List<String>, ignoredBuckets: Set<Long>): Boolean {
            if (ignoredBuckets.contains(bucketId)) return true
            return blacklist.any { folder ->
                trackPath.startsWith("$folder/", ignoreCase = true) ||
                trackPath.substringBeforeLast('/', "").equals(folder, ignoreCase = true)
            }
        }

        // Blacklisted folder 1
        assertTrue(isTrackExcluded("/storage/emulated/0/Ringtones/ring.mp3", 100L, blacklistFolders, ignoredBucketIds))
        assertTrue(isTrackExcluded("/storage/emulated/0/Ringtones/Sub/bell.wav", 101L, blacklistFolders, ignoredBucketIds))

        // Blacklisted folder 2
        assertTrue(isTrackExcluded("/storage/emulated/0/Android/data/app/cache.m4a", 102L, blacklistFolders, ignoredBucketIds))

        // Ignored bucket ID
        assertTrue(isTrackExcluded("/storage/emulated/0/Recordings/rec.mp3", 9999L, blacklistFolders, ignoredBucketIds))

        // Allowed tracks
        assertFalse(isTrackExcluded("/storage/emulated/0/Music/song.mp3", 200L, blacklistFolders, ignoredBucketIds))
        assertFalse(isTrackExcluded("/storage/emulated/0/Download/song.mp3", 201L, blacklistFolders, ignoredBucketIds))
    }

    @Test
    fun filterFolder_withBucketIdSerialization() {
        val gson = com.google.gson.Gson()
        val type = object : com.google.gson.reflect.TypeToken<List<com.ztftrue.music.sqlData.model.FilterFolder>>() {}.type
        val originalList = listOf(
            com.ztftrue.music.sqlData.model.FilterFolder(
                id = "id-saf",
                uri = "content://saf/tree",
                path = "/storage/emulated/0/Podcasts",
                name = "Podcasts",
                bucketId = null
            ),
            com.ztftrue.music.sqlData.model.FilterFolder(
                id = "id-device",
                uri = null,
                path = "/storage/emulated/0/Ringtones",
                name = "Ringtones",
                bucketId = 123456789L
            )
        )

        val json = gson.toJson(originalList)
        val deserialized: List<com.ztftrue.music.sqlData.model.FilterFolder> = gson.fromJson(json, type)
        assertEquals(2, deserialized.size)
        assertNull(deserialized[0].bucketId)
        assertEquals(123456789L, deserialized[1].bucketId)
        assertEquals("Ringtones", deserialized[1].name)
        assertEquals("/storage/emulated/0/Ringtones", deserialized[1].path)
    }

    @Test
    fun blacklistAndIgnoreSync_synchronizationLogic() {
        val blacklist = mutableListOf(
            com.ztftrue.music.sqlData.model.FilterFolder(
                id = "id-1",
                path = "/storage/emulated/0/Audiobooks",
                name = "Audiobooks",
                bucketId = 1111L
            ),
            com.ztftrue.music.sqlData.model.FilterFolder(
                id = "id-2",
                path = "/storage/emulated/0/CustomExclude",
                name = "CustomExclude",
                bucketId = null
            )
        )

        // Generating ignore_folders string from blacklist
        fun getIgnoreFoldersString(folders: List<com.ztftrue.music.sqlData.model.FilterFolder>): String {
            return folders.mapNotNull { it.bucketId }.distinct().joinToString(",")
        }
        assertEquals("1111", getIgnoreFoldersString(blacklist))

        // Adding an item with bucketId
        val newItem = com.ztftrue.music.sqlData.model.FilterFolder(
            id = "id-3",
            path = "/storage/emulated/0/Notifications",
            name = "Notifications",
            bucketId = 2222L
        )
        blacklist.add(newItem)
        assertEquals("1111,2222", getIgnoreFoldersString(blacklist))

        // Removing item
        blacklist.removeIf { it.bucketId == 1111L }
        assertEquals("2222", getIgnoreFoldersString(blacklist))
    }

    @Test
    fun legacyIgnoreFoldersMigration_detectsMissingBucketIds() {
        val existingBlacklist = listOf(
            com.ztftrue.music.sqlData.model.FilterFolder(
                id = "id-1",
                path = "/storage/emulated/0/FolderA",
                name = "FolderA",
                bucketId = 100L
            )
        )
        val legacyIgnoreString = "100,200,300"

        val legacyIds = legacyIgnoreString.split(",").mapNotNull { it.trim().toLongOrNull() }
        val currentBucketIds = existingBlacklist.mapNotNull { it.bucketId }.toSet()
        val missingBucketIds = legacyIds.filter { !currentBucketIds.contains(it) }

        assertEquals(listOf(200L, 300L), missingBucketIds)
    }

    @Test
    fun searchTracks_matchesTitleAndArtist_andDeduplicates() {
        val tracksMap = LinkedHashMap<Long, com.ztftrue.music.sqlData.model.MusicItem>()
        fun createTrack(id: Long, title: String, artist: String): com.ztftrue.music.sqlData.model.MusicItem {
            return com.ztftrue.music.sqlData.model.MusicItem(
                tableId = null,
                id = id,
                name = title,
                path = "/storage/emulated/0/Music/$title.mp3",
                duration = 180000L,
                displayName = "$title.mp3",
                album = "Test Album",
                albumId = 1L,
                artist = artist,
                artistId = 10L,
                genre = "Pop",
                genreId = 100L,
                year = 2024,
                songNumber = 1
            )
        }

        val track1 = createTrack(1L, "Rolling in the Deep", "Adele")
        val track2 = createTrack(2L, "Someone Like You", "Adele")
        val track3 = createTrack(3L, "Shape of You", "Ed Sheeran")
        val track4 = createTrack(4L, "Perfect", "Ed Sheeran")
        val track5 = createTrack(5L, "Adele Song", "Other Singer")

        tracksMap[1L] = track1
        tracksMap[2L] = track2
        tracksMap[3L] = track3
        tracksMap[4L] = track4
        tracksMap[5L] = track5

        fun search(query: String?, map: LinkedHashMap<Long, com.ztftrue.music.sqlData.model.MusicItem>): List<com.ztftrue.music.sqlData.model.MusicItem> {
            if (query.isNullOrBlank()) return emptyList()
            val trimmed = query.trim()
            val seenIds = HashSet<Long>()
            val list = ArrayList<com.ztftrue.music.sqlData.model.MusicItem>()
            for (item in map.values) {
                if (!seenIds.contains(item.id)) {
                    if (item.name.contains(trimmed, ignoreCase = true) ||
                        item.artist.contains(trimmed, ignoreCase = true)
                    ) {
                        seenIds.add(item.id)
                        list.add(item)
                    }
                }
            }
            list.sortWith(compareBy(java.lang.String.CASE_INSENSITIVE_ORDER) { it.name })
            return list
        }

        // Test 1: Searching for artist "Adele" returns tracks by Adele as well as track with "Adele" in title
        val adeleResults = search("Adele", tracksMap)
        assertEquals(3, adeleResults.size)
        // Check alphabetical sorting by title
        assertEquals("Adele Song", adeleResults[0].name)
        assertEquals("Rolling in the Deep", adeleResults[1].name)
        assertEquals("Someone Like You", adeleResults[2].name)

        // Test 2: Case-insensitivity ("ed sheeran" in lowercase)
        val edResults = search("ed sheeran", tracksMap)
        assertEquals(2, edResults.size)
        assertEquals("Perfect", edResults[0].name)
        assertEquals("Shape of You", edResults[1].name)

        // Test 3: Deduplication: title and artist both matching query
        val doubleMatchTrack = createTrack(6L, "Chopin Nocturne", "Chopin")
        tracksMap[6L] = doubleMatchTrack
        val chopinResults = search("Chopin", tracksMap)
        assertEquals(1, chopinResults.size)
        assertEquals("Chopin Nocturne", chopinResults[0].name)

        // Test 4: Blank/empty query returns empty list
        assertTrue(search("", tracksMap).isEmpty())
        assertTrue(search("   ", tracksMap).isEmpty())
        assertTrue(search(null, tracksMap).isEmpty())
    }

    @Test
    fun musicFileParser_excludedMimeTypesAndExtensions() {
        val excludedMimes = com.ztftrue.music.utils.MusicFileParser.EXCLUDED_MIME_TYPES
        val excludedExtensions = com.ztftrue.music.utils.MusicFileParser.EXCLUDED_EXTENSIONS

        // Verify AMR, 3GP, and ringtone/midi formats are excluded
        assertTrue(excludedMimes.contains("audio/amr"))
        assertTrue(excludedMimes.contains("audio/amr-wb"))
        assertTrue(excludedMimes.contains("audio/3gpp"))
        assertTrue(excludedMimes.contains("audio/midi"))
        assertTrue(excludedMimes.contains("audio/basic"))

        // Verify standard music formats are NOT excluded
        assertFalse(excludedMimes.contains("audio/mpeg"))
        assertFalse(excludedMimes.contains("audio/mp3"))
        assertFalse(excludedMimes.contains("audio/flac"))
        assertFalse(excludedMimes.contains("audio/mp4"))
        assertFalse(excludedMimes.contains("audio/wav"))
        assertFalse(excludedMimes.contains("audio/ogg"))

        // Verify extensions
        assertTrue(excludedExtensions.contains("amr"))
        assertTrue(excludedExtensions.contains("3gp"))
        assertTrue(excludedExtensions.contains("3gpp"))
        assertTrue(excludedExtensions.contains("mid"))
        assertTrue(excludedExtensions.contains("midi"))
        assertTrue(excludedExtensions.contains("m4r"))

        assertFalse(excludedExtensions.contains("mp3"))
        assertFalse(excludedExtensions.contains("flac"))
        assertFalse(excludedExtensions.contains("m4a"))
        assertFalse(excludedExtensions.contains("wav"))
        assertFalse(excludedExtensions.contains("ogg"))
    }

    @Test
    fun musicFileParser_m3uMimeTypes() {
        val m3uMimes = com.ztftrue.music.utils.MusicFileParser.M3U_MIME_TYPES
        assertTrue(m3uMimes.contains("audio/x-mpegurl"))
        assertTrue(m3uMimes.contains("audio/mpegurl"))
        assertTrue(m3uMimes.contains("application/x-mpegurl"))
        assertTrue(m3uMimes.contains("application/vnd.apple.mpegurl"))

        assertFalse(m3uMimes.contains("audio/mpeg"))
        assertFalse(m3uMimes.contains("audio/flac"))
    }

    @Test
    fun musicFileParser_parseM3uLines_withExtInfAndVariousPaths() {
        val lines = sequenceOf(
            "#EXTM3U",
            "# Comment line to ignore",
            "",
            "#EXTINF:180,Artist One - Song Alpha",
            "track1.mp3",
            "#EXTINF:240.5,Song Beta Without Artist",
            "/absolute/storage/track2.flac",
            "#EXTINF:-1,Radio Stream",
            "https://stream.example.com/live.aac",
            "#EXTINF:120,Artist Three - Track Three",
            "file:///sdcard/Music/track3.ogg"
        )

        val tempDir = java.io.File("/mock/music/playlist")
        val items = com.ztftrue.music.utils.MusicFileParser.parseM3uLines(
            lines = lines,
            playlistDir = tempDir,
            libraryTracks = null
        )

        assertEquals(4, items.size)

        // Item 1: relative path resolved against playlistDir + EXTINF with artist and title
        val item1 = items[0]
        assertEquals("Song Alpha", item1.name)
        assertEquals("Artist One", item1.artist)
        assertEquals(180000L, item1.duration)
        assertEquals(java.io.File(tempDir, "track1.mp3").absolutePath, item1.path)

        // Item 2: absolute path + EXTINF with title only
        val item2 = items[1]
        assertEquals("Song Beta Without Artist", item2.name)
        assertEquals("<unknown>", item2.artist)
        assertEquals(240500L, item2.duration)
        assertEquals("/absolute/storage/track2.flac", item2.path)

        // Item 3: stream URL
        val item3 = items[2]
        assertEquals("Radio Stream", item3.name)
        assertEquals("https://stream.example.com/live.aac", item3.path)
        assertEquals("<stream>", item3.album)

        // Item 4: file:// path stripped
        val item4 = items[3]
        assertEquals("Track Three", item4.name)
        assertEquals("Artist Three", item4.artist)
        assertEquals(120000L, item4.duration)
        assertEquals("/sdcard/Music/track3.ogg", item4.path)
    }

    @Test
    fun musicFileParser_parseM3uLines_matchesLibraryTracks() {
        val libraryTrack1 = com.ztftrue.music.sqlData.model.MusicItem(
            tableId = 1L,
            id = 1001L,
            name = "Library Track 1",
            path = "/storage/emulated/0/Music/Album1/song1.mp3",
            duration = 200000L,
            displayName = "song1.mp3",
            album = "Best Album",
            albumId = 55L,
            artist = "Super Artist",
            artistId = 77L,
            genre = "Rock",
            genreId = 1L,
            year = 2024,
            songNumber = 1
        )

        val libraryTrack2 = com.ztftrue.music.sqlData.model.MusicItem(
            tableId = 2L,
            id = 1002L,
            name = "Library Track 2",
            path = "/storage/emulated/0/Music/Album2/song2.flac",
            duration = 310000L,
            displayName = "song2.flac",
            album = "Second Album",
            albumId = 56L,
            artist = "Another Artist",
            artistId = 78L,
            genre = "Pop",
            genreId = 2L,
            year = 2023,
            songNumber = 2
        )

        val library = listOf(libraryTrack1, libraryTrack2)

        // Playlist references track 1 by exact path, and track 2 by filename only
        val lines = sequenceOf(
            "#EXTM3U",
            "/storage/emulated/0/Music/Album1/song1.mp3",
            "song2.flac"
        )

        val items = com.ztftrue.music.utils.MusicFileParser.parseM3uLines(
            lines = lines,
            playlistDir = null,
            libraryTracks = library
        )

        assertEquals(2, items.size)
        // Verify matched to library tracks with complete metadata (IDs, album, artist)
        assertEquals(1001L, items[0].id)
        assertEquals("Library Track 1", items[0].name)
        assertEquals(77L, items[0].artistId)
        assertEquals(55L, items[0].albumId)

        assertEquals(1002L, items[1].id)
        assertEquals("Library Track 2", items[1].name)
        assertEquals(78L, items[1].artistId)
        assertEquals(56L, items[1].albumId)
    }

    @Test
    fun batchQueueOperations_orderingVerification() {
        val createTrack = { id: Long, name: String ->
            com.ztftrue.music.sqlData.model.MusicItem(
                tableId = null,
                id = id,
                name = name,
                path = "/storage/$name.mp3",
                duration = 1000L,
                displayName = "$name.mp3",
                album = "Album",
                albumId = 1L,
                artist = "Artist",
                artistId = 1L,
                genre = "",
                genreId = 0L,
                year = 2024,
                songNumber = 1
            )
        }

        val queue = ArrayList<com.ztftrue.music.sqlData.model.MusicItem>()
        queue.add(createTrack(1L, "Current 1"))
        queue.add(createTrack(2L, "Current 2"))
        queue.add(createTrack(3L, "Current 3"))

        val newTracks = listOf(
            createTrack(10L, "New M3U Track A"),
            createTrack(11L, "New M3U Track B")
        )

        // Test 1: Add to Queue (appends to end)
        val queueAppend = ArrayList(queue)
        queueAppend.addAll(newTracks)
        assertEquals(5, queueAppend.size)
        assertEquals(1L, queueAppend[0].id)
        assertEquals(2L, queueAppend[1].id)
        assertEquals(3L, queueAppend[2].id)
        assertEquals(10L, queueAppend[3].id)
        assertEquals(11L, queueAppend[4].id)

        // Test 2: Play Next (inserts after current index 1 -> position 2)
        val queuePlayNext = ArrayList(queue)
        val currentIndex = 1
        val insertPosition = currentIndex + 1
        queuePlayNext.addAll(insertPosition, newTracks)
        assertEquals(5, queuePlayNext.size)
        assertEquals(1L, queuePlayNext[0].id)
        assertEquals(2L, queuePlayNext[1].id)
        assertEquals(10L, queuePlayNext[2].id)
        assertEquals(11L, queuePlayNext[3].id)
        assertEquals(3L, queuePlayNext[4].id)

        // Test 3: Clear queue and play
        val queueClearAndPlay = ArrayList(queue)
        queueClearAndPlay.clear()
        queueClearAndPlay.addAll(newTracks)
        assertEquals(2, queueClearAndPlay.size)
        assertEquals(10L, queueClearAndPlay[0].id)
        assertEquals(11L, queueClearAndPlay[1].id)
    }

    @Test
    fun androidAuto_containerIdExtraction() {
        fun extractId(mediaId: String, typeName: String): Long? {
            if (mediaId.startsWith("${typeName}_track_")) {
                return mediaId.removePrefix("${typeName}_track_").toLongOrNull()
            }
            if (mediaId.startsWith("${typeName}@")) {
                return mediaId.removePrefix("${typeName}@").toLongOrNull()
            }
            return null
        }

        // Test Albums
        assertEquals(123L, extractId("Albums_track_123", "Albums"))
        assertEquals(123L, extractId("Albums@123", "Albums"))
        assertNull(extractId("Albums_track_abc", "Albums"))
        assertNull(extractId("Artists_track_123", "Albums"))

        // Test Artists
        assertEquals(456L, extractId("Artists_track_456", "Artists"))
        assertEquals(456L, extractId("Artists@456", "Artists"))

        // Test Playlists
        assertEquals(789L, extractId("PlayLists_track_789", "PlayLists"))
        assertEquals(789L, extractId("PlayLists@789", "PlayLists"))

        // Test Genres
        assertEquals(101L, extractId("Genres_track_101", "Genres"))
        assertEquals(101L, extractId("Genres@101", "Genres"))

        // Test Folders
        assertEquals(202L, extractId("Folders_track_202", "Folders"))
        assertEquals(202L, extractId("Folders@202", "Folders"))
    }

    @Test
    fun androidAuto_paginationLogic() {
        fun <T> applyPagination(items: List<T>, page: Int, pageSize: Int): List<T> {
            if (pageSize <= 0 || page < 0) {
                return items
            }
            val fromIndex = (page * pageSize).coerceAtMost(items.size)
            val toIndex = (fromIndex + pageSize).coerceAtMost(items.size)
            return items.subList(fromIndex, toIndex)
        }

        val items = (1..100).toList()

        // Page 0 with pageSize 20 -> 1..20
        val page0 = applyPagination(items, 0, 20)
        assertEquals(20, page0.size)
        assertEquals(1, page0.first())
        assertEquals(20, page0.last())

        // Page 4 with pageSize 20 -> 81..100
        val page4 = applyPagination(items, 4, 20)
        assertEquals(20, page4.size)
        assertEquals(81, page4.first())
        assertEquals(100, page4.last())

        // Page 5 with pageSize 20 -> out of bounds, returns empty
        val page5 = applyPagination(items, 5, 20)
        assertTrue(page5.isEmpty())

        // Non-positive pageSize returns all
        val allItems = applyPagination(items, 0, -1)
        assertEquals(100, allItems.size)
    }

    @Test
    fun isVideoPath_validation() {
        assertTrue(Utils.isVideoPath("movie.mp4"))
        assertTrue(Utils.isVideoPath("/storage/emulated/0/DCIM/Camera/VID_2026.MP4"))
        assertTrue(Utils.isVideoPath("sample.mkv"))
        assertTrue(Utils.isVideoPath("clip.webm"))
        assertTrue(Utils.isVideoPath("test.mov"))
        assertTrue(Utils.isVideoPath("video.avi"))
        assertTrue(Utils.isVideoPath("recording.3gp"))
        assertTrue(Utils.isVideoPath("stream.flv"))
        assertTrue(Utils.isVideoPath("video.m4v"))

        assertFalse(Utils.isVideoPath("song.mp3"))
        assertFalse(Utils.isVideoPath("audio.flac"))
        assertFalse(Utils.isVideoPath("track.wav"))
        assertFalse(Utils.isVideoPath("music.ogg"))
        assertFalse(Utils.isVideoPath("audio.m4a"))
        assertFalse(Utils.isVideoPath(""))
        assertFalse(Utils.isVideoPath(null))
        assertFalse(Utils.isVideoPath("no_extension"))
    }

    @Test
    fun videoIdMapping_bijectiveAndNegative() {
        fun encodeVideoId(rawVideoId: Long): Long = -(rawVideoId + 1L)
        fun decodeVideoId(musicId: Long): Long = (-musicId) - 1L

        val testIds = listOf(0L, 1L, 2L, 42L, 1000L, 123456789L, Long.MAX_VALUE - 1L)
        for (raw in testIds) {
            val encoded = encodeVideoId(raw)
            assertTrue("Encoded video ID must be negative", encoded < 0)
            val decoded = decodeVideoId(encoded)
            assertEquals("Decoded ID must match original raw video ID", raw, decoded)
        }
    }

    @Test
    fun videoFocus_stateCalculation() {
        fun computeIsFocused(isSelected: Boolean, isLifecycleActive: Boolean): Boolean {
            return isSelected && isLifecycleActive
        }

        assertTrue(computeIsFocused(isSelected = true, isLifecycleActive = true))
        assertFalse(computeIsFocused(isSelected = false, isLifecycleActive = true))
        assertFalse(computeIsFocused(isSelected = true, isLifecycleActive = false))
        assertFalse(computeIsFocused(isSelected = false, isLifecycleActive = false))
    }

    @Test
    fun mediaItemUtils_extractId_handlesAllFormats() {
        assertEquals(123L, com.ztftrue.music.play.MediaItemUtils.extractId("Folders_track_123"))
        assertEquals(456L, com.ztftrue.music.play.MediaItemUtils.extractId("Genres_track_456"))
        assertEquals(789L, com.ztftrue.music.play.MediaItemUtils.extractId("Albums_track_789"))
        assertEquals(101L, com.ztftrue.music.play.MediaItemUtils.extractId("Artists_track_101"))
        assertEquals(102L, com.ztftrue.music.play.MediaItemUtils.extractId("PlayLists_track_102"))
        assertEquals(123L, com.ztftrue.music.play.MediaItemUtils.extractId("Folders@123"))
        assertEquals(999L, com.ztftrue.music.play.MediaItemUtils.extractId("Genres_album_999"))
        assertEquals(123L, com.ztftrue.music.play.MediaItemUtils.extractId("123"))
        assertEquals(-456L, com.ztftrue.music.play.MediaItemUtils.extractId("-456"))
        assertNull(com.ztftrue.music.play.MediaItemUtils.extractId(""))
        assertNull(com.ztftrue.music.play.MediaItemUtils.extractId(null))
        assertNull(com.ztftrue.music.play.MediaItemUtils.extractId("albums_root"))
        assertNull(com.ztftrue.music.play.MediaItemUtils.extractId("folders_root"))
        assertNull(com.ztftrue.music.play.MediaItemUtils.extractId("genres_root"))
    }

    @Test
    fun videoTab_translateMapAndId_isCorrect() {
        assertEquals(R.string.tab_video, Utils.translateMap["Video"])
        assertEquals(4, com.ztftrue.music.ui.play.VideoID)
    }

    @Test
    fun isVideoTrack_detection_isCorrect() {
        assertTrue(Utils.isVideoPath("/storage/emulated/0/Music/sample.mp4"))
        assertTrue(Utils.isVideoPath("/storage/emulated/0/Music/sample.mkv"))
        assertTrue(Utils.isVideoPath("/storage/emulated/0/Music/sample.webm"))
        assertFalse(Utils.isVideoPath("/storage/emulated/0/Music/sample.mp3"))
        assertFalse(Utils.isVideoPath("/storage/emulated/0/Music/sample.flac"))
        assertFalse(Utils.isVideoPath(null))
    }

    @Test
    fun buildConfig_supportVideo_configuration() {
        val supportVideo: Boolean = BuildConfig.SUPPORT_VIDEO
        assertTrue(supportVideo == true || supportVideo == false)
    }

    @Test
    fun audioFileIO_isSupported_checksFormatsCorrectly() {
        assertFalse(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension("mkv"))
        assertFalse(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension("webm"))
        assertFalse(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension("avi"))
        assertFalse(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension("mp4v"))
        assertFalse(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension(".mkv"))
        assertFalse(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension(null))
        assertFalse(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension(""))

        assertTrue(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension("mp3"))
        assertTrue(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension("flac"))
        assertTrue(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension("m4a"))
        assertTrue(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension("ogg"))
        assertTrue(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension("wav"))
        assertTrue(org.jaudiotagger.audio.AudioFileIO.isSupportedExtension(".mp3"))
    }

    @Test
    fun testSortUtilsSectionLabels() {
        assertEquals("A", SortUtils.getSectionLabel("Apple"))
        assertEquals("B", SortUtils.getSectionLabel("banana"))
        assertEquals("L", SortUtils.getSectionLabel("(Live) Rock"))
        assertEquals("R", SortUtils.getSectionLabel("[Remix] Track"))
        assertEquals("#", SortUtils.getSectionLabel("123 Song"))
        assertEquals("#", SortUtils.getSectionLabel("!Special"))
        assertEquals("#", SortUtils.getSectionLabel(""))
        assertEquals("#", SortUtils.getSectionLabel(null))

        // Non-Western characters (specifically Chinese characters) keep the characters themselves
        assertEquals("啊", SortUtils.getSectionLabel("啊"))
        assertEquals("把", SortUtils.getSectionLabel("把"))
        assertEquals("陈", SortUtils.getSectionLabel("陈奕迅"))
        assertEquals("周", SortUtils.getSectionLabel("周杰伦"))

        // Japanese Kana
        assertEquals("あ", SortUtils.getSectionLabel("あさ"))
        assertEquals("さ", SortUtils.getSectionLabel("さくら"))
        assertEquals("ア", SortUtils.getSectionLabel("アサ"))
    }

    @Test
    fun testSortUtilsCompareStrings() {
        assertTrue(SortUtils.compareStrings("Apple", "Banana") < 0)
        assertTrue(SortUtils.compareStrings("Banana", "Apple") > 0)
        assertTrue(SortUtils.compareStrings("Apple", "Banana", ascending = false) > 0)

        // Numbers & symbols (#) come before Western letters in ascending
        assertTrue(SortUtils.compareStrings("123", "Apple") < 0)
        assertTrue(SortUtils.compareStrings("!Special", "Apple") < 0)

        // Western letters (A-Z) come before Chinese characters
        assertTrue(SortUtils.compareStrings("Zebra", "啊") < 0)
        assertTrue(SortUtils.compareStrings("Apple", "周杰伦") < 0)

        // Chinese characters arranged in Pinyin order
        assertTrue(SortUtils.compareStrings("啊", "把") < 0)
        assertTrue(SortUtils.compareStrings("把", "陈奕迅") < 0)
        assertTrue(SortUtils.compareStrings("陈奕迅", "周杰伦") < 0)

        // Chinese characters come before Japanese Kana
        assertTrue(SortUtils.compareStrings("周杰伦", "あさ") < 0)

        // Japanese Kana in Gojūon order
        assertTrue(SortUtils.compareStrings("あさ", "さくら") < 0)
    }

    @Test
    fun testSortUtilsSortTracks() {
        fun createItem(id: Long, name: String) = MusicItem(
            tableId = null,
            id = id,
            name = name,
            path = "/path/$id",
            duration = 100L,
            displayName = name,
            album = "Album",
            albumId = 1L,
            artist = "Artist",
            artistId = 1L,
            genre = "Genre",
            genreId = 1L,
            year = 2020,
            songNumber = id.toInt()
        )

        val tracks = mutableListOf(
            createItem(1, "123 Track"),
            createItem(2, "周杰伦 - 晴天"),
            createItem(3, "Apple Song"),
            createItem(4, "陈奕迅 - 十年"),
            createItem(5, "あさ"),
            createItem(6, "Zebra Song")
        )

        SortUtils.sortTracks(tracks, "TITLE ASC")
        val names = tracks.map { it.name }
        assertEquals("123 Track", names[0])
        assertEquals("Apple Song", names[1])
        assertEquals("Zebra Song", names[2])
        assertEquals("陈奕迅 - 十年", names[3])
        assertEquals("周杰伦 - 晴天", names[4])
        assertEquals("あさ", names[5])

        // DESC
        SortUtils.sortTracks(tracks, "TITLE DESC")
        val descNames = tracks.map { it.name }
        assertEquals(names.reversed(), descNames)
    }

    @Test
    fun audioExport_filenameSanitization() {
        val sanitize = com.ztftrue.music.utils.AudioExportEngine::sanitizeFilename

        assertEquals("Valid_Name", sanitize("Valid_Name"))
        assertEquals("Song ___Title_", sanitize("Song /:?Title*"))
        assertEquals("Song_With_Quotes_", sanitize("Song\"With<Quotes>"))
        assertEquals("Pipe_And_Backslash", sanitize("Pipe|And\\Backslash"))
        assertEquals("audio_processed", sanitize(""))
        assertEquals("audio_processed", sanitize("   "))
        assertEquals("audio_processed", sanitize("///"))
        assertEquals("My song", sanitize("  My song  "))
    }

    @Test
    fun audioExport_wavHeaderStructure() {
        val sampleRate = 44100
        val channels = 2
        val bitsPerSample = 16
        val pcmDataLength = 88200L // 1 second of 16-bit stereo PCM

        val header = com.ztftrue.music.utils.AudioExportEngine.WavWriter.createWavHeader(
            sampleRate = sampleRate,
            channels = channels,
            bitsPerSample = bitsPerSample,
            dataLength = pcmDataLength
        )

        assertEquals(44, header.size)

        // 1. "RIFF" chunk descriptor
        val riff = String(header, 0, 4, Charsets.US_ASCII)
        assertEquals("RIFF", riff)

        // ChunkSize (bytes 4..7) = 36 + pcmDataLength (Little Endian)
        val expectedChunkSize = (36 + pcmDataLength).toInt()
        val actualChunkSize = (header[4].toInt() and 0xFF) or
                ((header[5].toInt() and 0xFF) shl 8) or
                ((header[6].toInt() and 0xFF) shl 16) or
                ((header[7].toInt() and 0xFF) shl 24)
        assertEquals(expectedChunkSize, actualChunkSize)

        // Format: "WAVE"
        val wave = String(header, 8, 4, Charsets.US_ASCII)
        assertEquals("WAVE", wave)

        // 2. "fmt " sub-chunk
        val fmt = String(header, 12, 4, Charsets.US_ASCII)
        assertEquals("fmt ", fmt)

        val subchunk1Size = (header[16].toInt() and 0xFF) or
                ((header[17].toInt() and 0xFF) shl 8) or
                ((header[18].toInt() and 0xFF) shl 16) or
                ((header[19].toInt() and 0xFF) shl 24)
        assertEquals(16, subchunk1Size) // 16 for PCM

        val audioFormat = (header[20].toInt() and 0xFF) or
                ((header[21].toInt() and 0xFF) shl 8)
        assertEquals(1, audioFormat) // 1 = Linear PCM

        val numChannels = (header[22].toInt() and 0xFF) or
                ((header[23].toInt() and 0xFF) shl 8)
        assertEquals(channels, numChannels)

        val actualSampleRate = (header[24].toInt() and 0xFF) or
                ((header[25].toInt() and 0xFF) shl 8) or
                ((header[26].toInt() and 0xFF) shl 16) or
                ((header[27].toInt() and 0xFF) shl 24)
        assertEquals(sampleRate, actualSampleRate)

        val expectedByteRate = (sampleRate * channels * bitsPerSample) / 8 // 176400
        val actualByteRate = (header[28].toInt() and 0xFF) or
                ((header[29].toInt() and 0xFF) shl 8) or
                ((header[30].toInt() and 0xFF) shl 16) or
                ((header[31].toInt() and 0xFF) shl 24)
        assertEquals(expectedByteRate, actualByteRate)

        val expectedBlockAlign = (channels * bitsPerSample) / 8 // 4
        val actualBlockAlign = (header[32].toInt() and 0xFF) or
                ((header[33].toInt() and 0xFF) shl 8)
        assertEquals(expectedBlockAlign, actualBlockAlign)

        val actualBitsPerSample = (header[34].toInt() and 0xFF) or
                ((header[35].toInt() and 0xFF) shl 8)
        assertEquals(bitsPerSample, actualBitsPerSample)

        // 3. "data" sub-chunk
        val data = String(header, 36, 4, Charsets.US_ASCII)
        assertEquals("data", data)

        val subchunk2Size = (header[40].toInt() and 0xFF) or
                ((header[41].toInt() and 0xFF) shl 8) or
                ((header[42].toInt() and 0xFF) shl 16) or
                ((header[43].toInt() and 0xFF) shl 24)
        assertEquals(pcmDataLength.toInt(), subchunk2Size)
    }

    @Test
    fun audioExport_wavHeader48kHzMono() {
        val sampleRate = 48000
        val channels = 1
        val bitsPerSample = 16
        val pcmDataLength = 96000L

        val header = com.ztftrue.music.utils.AudioExportEngine.WavWriter.createWavHeader(
            sampleRate = sampleRate,
            channels = channels,
            bitsPerSample = bitsPerSample,
            dataLength = pcmDataLength
        )

        val numChannels = (header[22].toInt() and 0xFF) or ((header[23].toInt() and 0xFF) shl 8)
        assertEquals(1, numChannels)

        val actualSampleRate = (header[24].toInt() and 0xFF) or
                ((header[25].toInt() and 0xFF) shl 8) or
                ((header[26].toInt() and 0xFF) shl 16) or
                ((header[27].toInt() and 0xFF) shl 24)
        assertEquals(48000, actualSampleRate)

        val expectedByteRate = 48000 * 1 * 2 // 96000
        val actualByteRate = (header[28].toInt() and 0xFF) or
                ((header[29].toInt() and 0xFF) shl 8) or
                ((header[30].toInt() and 0xFF) shl 16) or
                ((header[31].toInt() and 0xFF) shl 24)
        assertEquals(expectedByteRate, actualByteRate)
    }

    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    @Test
    fun audioExport_processorPipelineFlushAndProcess() {
        val sonic = androidx.media3.common.audio.SonicAudioProcessor()
        sonic.setOutputSampleRateHz(48000)
        sonic.setSpeed(1.25f)
        sonic.setPitch(1.1f)

        val pipeline = com.ztftrue.music.utils.AudioExportEngine.ProcessorPipeline(listOf(sonic))
        val outputFormat = pipeline.configure(
            androidx.media3.common.audio.AudioProcessor.AudioFormat(
                96000,
                2,
                androidx.media3.common.C.ENCODING_PCM_16BIT
            )
        )
        assertEquals(48000, outputFormat.sampleRate)
        assertEquals(2, outputFormat.channelCount)

        // Generate synthetic stereo 16-bit PCM input data (1000 samples @ 96kHz = 4000 bytes)
        val inputBuffer = java.nio.ByteBuffer.allocateDirect(4000).order(java.nio.ByteOrder.nativeOrder())
        while (inputBuffer.hasRemaining()) {
            inputBuffer.putShort(1000)
        }
        inputBuffer.flip()

        var outputBytesCount = 0
        pipeline.process(inputBuffer) { chunk ->
            outputBytesCount += chunk.remaining()
        }

        pipeline.drainEndOfStream { chunk ->
            outputBytesCount += chunk.remaining()
        }

        assertTrue("Expected processed audio output from SonicAudioProcessor", outputBytesCount > 0)
        pipeline.reset()
    }

    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    @Test
    fun audioExport_sonicAudioProcessorNoNoise() {
        // Reproduce pitch = 0.9 effect as used by the user
        val sonic = androidx.media3.common.audio.SonicAudioProcessor()
        sonic.setPitch(0.9f)
        sonic.setSpeed(1.0f)

        val pipeline = com.ztftrue.music.utils.AudioExportEngine.ProcessorPipeline(listOf(sonic))
        val sampleRate = 48000
        val channels = 2
        val format = androidx.media3.common.audio.AudioProcessor.AudioFormat(
            sampleRate,
            channels,
            androidx.media3.common.C.ENCODING_PCM_16BIT
        )
        pipeline.configure(format)

        // Generate a smooth 440Hz sine wave (16-bit stereo PCM)
        val numFrames = 2400 // 50ms at 48kHz
        val byteCount = numFrames * channels * 2
        // Intentionally start with BIG_ENDIAN buffer to verify pipeline normalizes to native order
        val inputBuffer = java.nio.ByteBuffer.allocateDirect(byteCount).order(java.nio.ByteOrder.BIG_ENDIAN)
        for (i in 0 until numFrames) {
            val sampleVal = (kotlin.math.sin(2.0 * Math.PI * 440.0 * i / sampleRate) * 8000.0).toInt().toShort()
            // Write in native little-endian byte order as MediaExtractor does
            val lowByte = (sampleVal.toInt() and 0xFF).toByte()
            val highByte = ((sampleVal.toInt() shr 8) and 0xFF).toByte()
            inputBuffer.put(lowByte)
            inputBuffer.put(highByte)
            inputBuffer.put(lowByte)
            inputBuffer.put(highByte)
        }
        inputBuffer.flip()

        val outputSamples = mutableListOf<Short>()
        pipeline.process(inputBuffer) { chunk ->
            val chunkCopy = chunk.duplicate().order(java.nio.ByteOrder.nativeOrder())
            while (chunkCopy.remaining() >= 2) {
                outputSamples.add(chunkCopy.getShort())
            }
        }
        pipeline.drainEndOfStream { chunk ->
            val chunkCopy = chunk.duplicate().order(java.nio.ByteOrder.nativeOrder())
            while (chunkCopy.remaining() >= 2) {
                outputSamples.add(chunkCopy.getShort())
            }
        }

        assertTrue("Output samples should be generated", outputSamples.size > 100)

        // Verify that the output signal is smooth audio, NOT high-delta static noise
        var totalDelta = 0L
        for (i in 1 until outputSamples.size) {
            totalDelta += kotlin.math.abs(outputSamples[i].toInt() - outputSamples[i - 1].toInt())
        }
        val avgDelta = totalDelta.toDouble() / (outputSamples.size - 1)

        // Byte-swapped noise has average delta > 10000. Clean sine wave pitched down has avg delta < 1500.
        assertTrue(
            "Average sample delta ($avgDelta) indicates white noise/byte swapping instead of clean audio",
            avgDelta < 1500.0
        )
        pipeline.reset()
    }

    @Test
    fun ffmpeg_extensionClassesAvailable() {
        // Verify FfmpegAudioRenderer class is present in classpath
        val clazz = Class.forName("androidx.media3.decoder.ffmpeg.FfmpegAudioRenderer")
        assertNotNull("FfmpegAudioRenderer class should be found", clazz)

        // Verify constructor required by DefaultRenderersFactory reflection is present
        val constructor = clazz.getConstructor(
            android.os.Handler::class.java,
            androidx.media3.exoplayer.audio.AudioRendererEventListener::class.java,
            androidx.media3.exoplayer.audio.AudioSink::class.java
        )
        assertNotNull("Constructor matching (Handler, AudioRendererEventListener, AudioSink) must exist", constructor)
    }

    @Test
    fun defaultRenderersFactory_decoderFallbackAndExtensionMode() {
        // Verify DefaultRenderersFactory extension renderer mode constants
        assertEquals(0, androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
        assertEquals(1, androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        assertEquals(2, androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
    }

    @Test
    fun calculateInSampleSize_downsamplesCorrectly() {
        val options = android.graphics.BitmapFactory.Options()

        // Case 1: Image smaller than requested
        options.outWidth = 250
        options.outHeight = 250
        assertEquals(1, Utils.calculateInSampleSize(options, 500, 500))

        // Case 2: Image equal to requested
        options.outWidth = 500
        options.outHeight = 500
        assertEquals(1, Utils.calculateInSampleSize(options, 500, 500))

        // Case 3: Image 2x requested
        options.outWidth = 1000
        options.outHeight = 1000
        assertEquals(2, Utils.calculateInSampleSize(options, 500, 500))

        // Case 4: Image 4x requested
        options.outWidth = 2000
        options.outHeight = 2000
        assertEquals(4, Utils.calculateInSampleSize(options, 500, 500))

        // Case 5: Asymmetric dimensions (e.g. 4000x2000 to 500x500)
        options.outWidth = 4000
        options.outHeight = 2000
        assertEquals(4, Utils.calculateInSampleSize(options, 500, 500))
    }

    @Test
    fun decodeSampledBitmapFromByteArray_returnsNullOnInvalidData() {
        val invalidData = byteArrayOf(0, 1, 2, 3)
        val result = Utils.decodeSampledBitmapFromByteArray(invalidData, 0, invalidData.size, 100, 100)
        assertNull(result)
    }

    @Test
    fun safeFfmpegAudioRenderer_classAndMethodsAvailable() {
        val clazz = androidx.media3.decoder.ffmpeg.SafeFfmpegAudioRenderer::class.java
        assertNotNull(clazz)
        val constructor = clazz.getConstructor(
            android.os.Handler::class.java,
            androidx.media3.exoplayer.audio.AudioRendererEventListener::class.java,
            androidx.media3.exoplayer.audio.AudioSink::class.java
        )
        assertNotNull(constructor)
    }

    @Test
    fun safeFfmpegAudioRenderer_methodsAvailable() {
        val clazz = androidx.media3.decoder.ffmpeg.SafeFfmpegAudioRenderer::class.java
        val method = clazz.getDeclaredMethod("supportsFormatInternal", androidx.media3.common.Format::class.java)
        assertNotNull(method)
    }

    @Test
    fun nativeFfmpegFix_classAndMethodsAvailable() {
        val clazz = com.ztftrue.music.play.NativeFfmpegFix::class.java
        assertNotNull(clazz)
        val method0 = clazz.getMethod("installFix")
        assertNotNull(method0)
        val method1 = clazz.getMethod("installFix", android.content.Context::class.java)
        assertNotNull(method1)
    }

    @Test
    fun equalizerAudioProcessor_initializationAndPassthrough() {
        val processor = com.ztftrue.music.effects.EqualizerAudioProcessor()
        assertNotNull(processor)
    }

    @Test
    fun equalizerAudioProcessor_spatialAudioMethods() {
        val processor = com.ztftrue.music.effects.EqualizerAudioProcessor()
        processor.setSpatialEnabled(true)
        assertTrue(processor.virtualizerActive)
        processor.setSpatialStrength(750)
        assertEquals(0.75f, processor.virtualizerStrength, 0.001f)
        processor.setSpatialAudio(false, 0.2f)
        assertFalse(processor.virtualizerActive)
        assertEquals(0.2f, processor.virtualizerStrength, 0.001f)
    }

    @Test
    fun equalizerAudioProcessor_limiterResetAndEffectMethods() {
        val processor = com.ztftrue.music.effects.EqualizerAudioProcessor()
        // Default limiter envelope should be 1.0f
        assertEquals(1.0f, processor.getLimiterEnvelope(), 0.001f)

        // Reset limiter
        processor.resetLimiter()
        assertEquals(1.0f, processor.getLimiterEnvelope(), 0.001f)

        // Changing bass boost resets limiter
        processor.setBassBoost(true, 0.8f)
        processor.setBassBoost(false, 0.0f)

        // Changing other effects (virtualizer, reverb, chorus, flanger, polyphony, delay)
        processor.setVirtualizer(true, 0.5f)
        assertTrue(processor.virtualizerActive)
        assertEquals(0.5f, processor.virtualizerStrength, 0.001f)

        processor.setReverb(true, 0.6f, 0.4f, 0.3f)
        processor.setChorus(true, 1.2f, 0.4f, 0.5f)
        processor.setFlanger(true, 0.8f, 0.6f, 0.5f, 0.4f)
        processor.setPolyphony(true, 2, 5.0f, 0.5f)
        processor.setDelay(true, 0.4f, 0.3f, 0.2f)

        // EQ and Echo
        processor.setEqualizerActive(true)
        assertTrue(processor.isSetActive())
        processor.setEchoActive(true)
    }

    @Test
    fun generateItemFilters_singleWordOrLess_doesNotShow() {
        // Empty list
        val emptyResult = com.ztftrue.music.ui.public.generateItemFilters(emptyList<String>()) { it }
        assertTrue(emptyResult.first.isEmpty())
        assertTrue(emptyResult.second.isEmpty())

        // Single item (just has one word) -> do not show indicator
        val singleItemResult = com.ztftrue.music.ui.public.generateItemFilters(listOf("Song A")) { it }
        assertTrue(singleItemResult.first.isEmpty())
        assertTrue(singleItemResult.second.isEmpty())

        // Multiple items, but all share the same section label (e.g., all start with '#' or 'A')
        val allSameSectionResult = com.ztftrue.music.ui.public.generateItemFilters(
            listOf("1 - Track One", "2 - Track Two", "3 - Track Three")
        ) { it }
        assertTrue(allSameSectionResult.first.isEmpty())
        assertTrue(allSameSectionResult.second.isEmpty())

        val allLetterAResult = com.ztftrue.music.ui.public.generateItemFilters(
            listOf("Apple", "Ant", "Airplane", "Art")
        ) { it }
        assertTrue(allLetterAResult.first.isEmpty())
        assertTrue(allLetterAResult.second.isEmpty())

        // Multiple distinct sections -> show indicator
        val multiSectionResult = com.ztftrue.music.ui.public.generateItemFilters(
            listOf("Apple", "Banana", "Cat", "Dog")
        ) { it }
        assertEquals(4, multiSectionResult.first.size)
        assertEquals(listOf("A", "B", "C", "D"), multiSectionResult.first.map { it.name })
        assertEquals(0, multiSectionResult.first[0].index)
        assertEquals(1, multiSectionResult.first[1].index)
        assertEquals(2, multiSectionResult.first[2].index)
        assertEquals(3, multiSectionResult.first[3].index)
    }

    @Test
    fun equalizerAudioProcessor_bitPerfectModeBypass() {
        val processor = com.ztftrue.music.effects.EqualizerAudioProcessor()
        assertFalse(processor.bitPerfectMode)

        // When bit-perfect mode is activated
        processor.bitPerfectMode = true
        assertTrue(processor.bitPerfectMode)

        // isActive() must return false to bypass the entire pipeline
        assertFalse(processor.isActive())

        // configure() must return NOT_SET
        val format = androidx.media3.common.audio.AudioProcessor.AudioFormat(
            44100, 2, androidx.media3.common.C.ENCODING_PCM_16BIT
        )
        val configResult = processor.configure(format)
        assertEquals(androidx.media3.common.audio.AudioProcessor.AudioFormat.NOT_SET, configResult)
        assertFalse(processor.isActive())

        // Deactivating bit-perfect mode allows normal configuration
        processor.bitPerfectMode = false
        val normalConfig = processor.configure(format)
        assertEquals(44100, normalConfig.sampleRate)
        assertEquals(2, normalConfig.channelCount)
        assertTrue(processor.isActive())
    }

    @Test
    fun usbDacManager_deviceDetectionLogic() {
        // Null or non-sink device should be rejected
        assertFalse(com.ztftrue.music.play.manager.UsbDacManager.isUsbAudioOutputDevice(null))
    }

    @Test
    fun trackSort_songsUtils_trackNumberOrdering() {
        fun createItem(id: Long, name: String, songNumber: Int) = MusicItem(
            tableId = null,
            id = id,
            name = name,
            path = "/path/$id",
            duration = 100L,
            displayName = name,
            album = "Album",
            albumId = 1L,
            artist = "Artist",
            artistId = 1L,
            genre = "Genre",
            genreId = 1L,
            year = 2020,
            songNumber = songNumber
        )

        val list = arrayListOf(
            createItem(1, "Track 5", 5),
            createItem(2, "Track 2", 2),
            createItem(3, "Track 10", 10),
            createItem(4, "Track 1", 1),
            createItem(5, "Track 2 Alt", 2)
        )

        // Test ASC sort by track number
        val sortedAsc = com.ztftrue.music.utils.trackManager.SongsUtils.sortSongs(list, "track", "ASC")
        assertEquals(listOf(1, 2, 2, 5, 10), sortedAsc.map { it.songNumber })
        assertEquals("Track 1", sortedAsc[0].name)
        // Check tie-breaking by name: "Track 2" < "Track 2 Alt"
        assertEquals("Track 2", sortedAsc[1].name)
        assertEquals("Track 2 Alt", sortedAsc[2].name)

        // Test DESC sort by track number
        val sortedDesc = com.ztftrue.music.utils.trackManager.SongsUtils.sortSongs(list, "track", "DESC")
        assertEquals(listOf(10, 5, 2, 2, 1), sortedDesc.map { it.songNumber })
        assertEquals("Track 10", sortedDesc[0].name)
        assertEquals("Track 5", sortedDesc[1].name)
    }

    @Test
    fun trackSort_sortUtils_getTrackComparator_trackAndTitle() {
        fun createItem(id: Long, name: String, songNumber: Int, duration: Long) = MusicItem(
            tableId = null,
            id = id,
            name = name,
            path = "/path/$id",
            duration = duration,
            displayName = name,
            album = "Album",
            albumId = 1L,
            artist = "Artist",
            artistId = 1L,
            genre = "Genre",
            genreId = 1L,
            year = 2020,
            songNumber = songNumber
        )

        val itemA = createItem(1, "Alpha", 2, 120L)
        val itemB = createItem(2, "Beta", 1, 300L)
        val itemC = createItem(3, "Gamma", 3, 200L)

        val list = listOf(itemA, itemB, itemC)

        // Sort by track number ASC
        val trackAscComparator = SortUtils.getTrackComparator("track", true)
        val sortedByTrackAsc = list.sortedWith(trackAscComparator)
        assertEquals(listOf(itemB, itemA, itemC), sortedByTrackAsc)

        // Sort by track number DESC
        val trackDescComparator = SortUtils.getTrackComparator("track", false)
        val sortedByTrackDesc = list.sortedWith(trackDescComparator)
        assertEquals(listOf(itemC, itemA, itemB), sortedByTrackDesc)

        // Sort by title ASC
        val titleAscComparator = SortUtils.getTrackComparator("title", true)
        val sortedByTitleAsc = list.sortedWith(titleAscComparator)
        assertEquals(listOf(itemA, itemB, itemC), sortedByTitleAsc)

        // Sort by duration DESC
        val durationDescComparator = SortUtils.getTrackComparator("duration", false)
        val sortedByDurationDesc = list.sortedWith(durationDescComparator)
        assertEquals(listOf(itemB, itemC, itemA), sortedByDurationDesc)
    }

    @Test
    fun videoCover_diskCacheFilePathLogic() {
        val path1 = "/storage/emulated/0/Movies/sample1.mp4"
        val path2 = "/storage/emulated/0/Movies/sample2.mkv"
        val hash1 = kotlin.math.abs(path1.hashCode())
        val hash2 = kotlin.math.abs(path2.hashCode())

        assertNotEquals(hash1, hash2)
        assertTrue(hash1 >= 0)
        assertTrue(hash2 >= 0)
    }

    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    @Test
    fun defaultAudioEffects_allDisabled() {
        val defaultAuxr = com.ztftrue.music.play.manager.AudioEffectManager.createDefaultAuxr(0L)
        assertFalse("Equalizer should be disabled by default", defaultAuxr.equalizer)
        assertFalse("Echo should be disabled by default", defaultAuxr.echo)
        assertFalse("Bass boost should be disabled by default", defaultAuxr.bassBoostEnabled)
        assertEquals(0, defaultAuxr.bassBoostStrength)
        assertFalse("Virtualizer should be disabled by default", defaultAuxr.virtualizerEnabled)
        assertEquals(0, defaultAuxr.virtualizerStrength)
        assertFalse("Reverb should be disabled by default", defaultAuxr.reverbEnabled)
        assertFalse("Chorus should be disabled by default", defaultAuxr.chorusEnabled)
        assertFalse("Flanger should be disabled by default", defaultAuxr.flangerEnabled)
        assertFalse("Polyphony should be disabled by default", defaultAuxr.polyphonyEnabled)
        assertFalse("Delay should be disabled by default", defaultAuxr.delayEnabled)
        assertEquals("legacy_audio_effects_cleaned_v3", com.ztftrue.music.play.manager.AudioEffectManager.KEY_AUDIO_EFFECTS_CLEANED_V3)
    }
}